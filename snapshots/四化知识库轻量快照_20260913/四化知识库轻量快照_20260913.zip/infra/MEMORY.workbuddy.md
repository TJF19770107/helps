# MEMORY.md - 跨项目长期记忆（汤哥 / 龙虾AI主控中心）

## 🔍 远端仓库状态判定铁律（2026-09-10 定性，跨项目通用）
- **身份探针优先于对象探针**：GitHub / CNB / GitLab 对「认证失败」与「仓库不存在」**一律返回 404 Repository Not Found**（刻意设计，防泄露仓库存在性）。**见 404 绝不能判定「仓库被删」。**
- 正确顺序：先打**与仓库无关**的身份接口（如 `api.<host>/user`）
  - 身份探针 401/403 → **令牌失效**，404 是伪装 → 重签令牌，别动仓库
  - 身份探针 200 + 对象 404 → 仓库真没了 / 该账号无权限
  - 无令牌 → 弱判定，不可下结论
- 反例实证：GitHub 私有仓匿名访问也返回 404，但 `git ls-remote` 成功。同一个 404，结论天差地别。
- 工具：`企业微信群定制接单项目\scripts\remote_repo_doctor.py`（零积分纯 stdlib）
- **credential helper 三坑**：① `git -c credential.helper=store` 是**追加不是替换**，全局 GCM 仍会被调用 → 必须先 `-c credential.helper=` 清空 ② GCM 拉起 GUI 子进程继承 stdout 管道，`subprocess.run(timeout=N)` 形同虚设 → stdout 重定向文件 + `GCM_INTERACTIVE=never` + 显式 `kill()` ③ `-c` 是 git 全局选项，必须在子命令**之前**。
- **常驻化用 Python 编排器，不写 .bat/.cmd**（绕开 GBK/CRLF 静默失败 = 「任务 Result=0 却没干活」头号形态）。
- **骨架文件「另存为副本弃主名」= 静默断链**（2026-09-11 实证）：`龙虾五步法V3.6…SKILL.md` 主名丢失、正文只剩 `…SKILL - 副本.md`，而 SOUL.md/AGENTS.md 指针仍指主名 → **宿主加载静默失败、不报错**。凡「指针 + 实体」分离的体系（技能库/模板/配置），必须定期做**存在性自检**，不能等报错。

## 🌏 香港代理链路与假死铁律（2026-09-10 实测定性，跨项目通���）
- **链路架构**：Chrome(系统代理 127.0.0.1:7897) → `E:\龙虾AI主控中心\MCP服务\http2socks_7897.py`（自建 HTTP→SOCKS5 中转，纯 stdlib）→ SSH 隘道 SOCKS5 1081（计划任务 `Lobster_HKTunnel` 常驻，脚本 `C:\Users\Administrator\hk_proxy_tunnel.bat`，-D 1081 -L 3002，断线 5s 自动重连）→ 香港轻量 43.161.202.206。**7897 不是 Clash，是自建中转器**。
- **TCP ESTABLISHED ≠ 链路可用**：ping 通 + netstat ESTABLISHED 都可能是假死（本次 ssh 僵死但状态好看）。必须用数据面探针实测（SOCKS5 atyp=3 域名解析请求，域名由香港侧解析，直接暴露服务器侧转发是否健康）。
- **修复三板斧**：`taskkill /F /PID <ssh_pid>` → 常驻 bat 5 秒自动重连 → 数据面复测（直连 1081 + 走 7897 各一次）。零手动干预，10 秒恢复。
- **ERR_TUNNEL_CONNECTION_FAILED** = HTTP 代理 CONNECT 后数据不通；ERR_PROXY_CONNECTION_FAILED 才是代理端口挂了。报错类型可快速分流故障层。
- **第三态：中转器本身没起**（2026-09-10 实测）。git 全局写着 `http.proxy=http://127.0.0.1:7897`，但 7897 **未监听**（1081 SOCKS5 数据面健康）→ 直连 github 全挂。查法：`netstat -ano | grep :7897`；不是 ssh 僵死，别去 taskkill ssh。
- **⚠️ 判据修正（2026-09-11）：单次数据面探针失败不作定论**。开机后链路有**启动窗口期**，探针早于监听建立会得 000，易误判「中转器又挂」。正确顺序：**先 `netstat -ano | grep LISTENING | grep :7897` 确认监听，再做数据面探针**；两次结果矛盾时以监听状态为准。
- **GitHub 拉取兜底通道（零积分，实测可用）**：镜像前缀 `https://gh-proxy.com/https://github.com/<owner>/<repo>` —— `git ls-remote` / `git fetch` 均通。用法：`git remote add mirror <镜像URL>` 后 `git -c http.proxy= -c https.proxy= fetch mirror main`（**必须显式清空 proxy，否则又走挂掉的 7897**）。注意 `git fetch <remote> main` 只写 FETCH_HEAD、不建远端跟踪 ref，用 `FETCH_HEAD` 做 diff/merge。
- **合并上游后必清点工作区**：Windows 大批量检出会**静默漏写**，本次合并后 HEAD 有 58 个文件但磁盘缺 → `git restore .` 全部找回。合并后必须 `git status --short | grep '^ D'` 核一遍。

## 身份
- 汤哥 = 汤晋峰，龙虾AI主控中心主理人。WorkBuddy = 我的 AI 员工（客户端外壳品牌「Agnes / Sapiens AI」，**本会话实际驱动模型 = Hy3 / 腾讯混元 hy3-preview**，走本机 15731）。
- 沟通风格：指令式、成本优先置顶、零手动干预偏好、厌恶重复确认弹窗。
- **AI 分身署名**：**汤小龙**（三点水的「汤」氵，不是「淘汰」的「淘」，永不写错）。

## 🔌 免费模型网关红线（2026-09-07 Zen 调研定型，跨项目通用）
- **「免费但需绑信用卡」的网关一律不接入生产链路**：OpenCode Zen 余额 <$5 自动充 $20（auto-reload），官方明说会击穿月限额 → 判定不符合零成本红线，**暂不接入 TeamoRouter**。
- **免费额度按自然日刷新，次日 0 点归零**：耗尽返回 `402 free_request_quota_exhausted`（TeamoRouter 51427 实测原文）。
- **免费模型是「零保留政策」的例外**：凡写「collected data may be used to improve the model」的一律禁喂密钥/客户数据/私有策略；NVIDIA 试用端点明文禁提交隐私 → 直接禁用。
- **免费席位静默轮换，约一月一轮，官方不公告**：Zen 29 天内 5 下架 4 新增（hy3-free/laguna-s-2.1-free/longcat-2.0-free 等消失）。**只能当临时弹药，不能当基础设施**，每月 diff 一次 `/v1/models`。
- **分工定论**：DeepSeek V4 Flash Free 走 TeamoRouter 18091；MiMo 长上下文走本机 18808；HY3 走本机 15731。

## ⚠️ TeamoRouter 两个已确认 Bug（2026-09-07 实测）
1. **51427 中文 payload 反序列化失败**：`Json deserialize error: invalid unicode code point` → 走网关一律 **ASCII 或 `\uXXXX` 转义**。
2. **18091 静默 fallback 到付费档**：请求 `deepseek-v4-flash-free` 实际返回 `model: glm-5.3-flash`（0.01 折）→ **必须校验返回体 `model` 字段**，触发成本底线「切换必报」。

## 🔝 任务收尾汇报铁律（汤哥 2026-09-03 强制，全局置顶，每次任务必执行）
每次任务完成，**必须在最终回复里**给出以下 5 项，缺一不可：
1. **花了多少积分**（估算：工具调用次数 + 文件读取量 + 上下文量；无法精确取值时说明估算口径）
2. **解决了什么问题**（逐条列，带证据：端口/HTTP码/文件路径）
3. **沉淀了什么技能**（写入了哪个 SKILL / 记忆文件，路径给出）
4. **用了哪几个技能**（列出本轮实际加载/调用的技能名），并标明**最主要发挥作用的是哪 1-2 个**
5. **生成了什么技能**（本轮新建/迭代了哪个 SKILL，路径给出）
- **目的**：让汤哥一眼看清「一堆技能里谁真正发挥了作用」，据此决定下回同类任务发哪些技能。
- 执行顺序：工具调用阶段先落盘记忆/技能，再在最终文字回复里输出这 5 项。

## 密钥 / 安全红线（强制）
- 原始文件可保留明文密钥；**萃取 / 同步产物必须脱敏遮蔽**。
- `sk-` / `token` / `secret` 禁止明文出现于任何可同步产物（四端 / 版本控制）。
- 泄露处置：撤销重建 + 双备份 + 红线笔记（笔记入 `_security_red_lines/`，**不进 git / 不进四端**）。

## 版本控制 / 知识库红线
- `.workbuddy/` 本地日志**禁止进 git / 禁进四端同步**（用 `git rm --cached -r .workbuddy` 解除跟踪，磁盘保留）。
- 轻量快照约束：**单份仓库 / 备份 < 20MB**；大附件走 G盘 / 网盘，git 只管文本。
- 备份回滚（龙虾全域模板 v2.1 强制）：变更前必**双备份**（官方 `龙虾可视化办公室\backups\` + G盘异地），每次操作 = 1 备份 + 1 日志；失败从 backups 回滚。
- 豆包主会话归档仓库：`E:\龙虾AI主控中心\我的AI分身\豆包主会话全集`（Git 管理，脚手架 `orca_multi_agent_fleet_v1.0` 已注册 `DOUBAO_SESSION_ARCHIVE`）。

## 磁盘架构（存储危机）
- E盘程序、G盘数据（前轻后重动静分离）；G盘须留 100-200GB。
- C盘长期 <2GB，**避免 Chromium / 大临时文件压 C盘**（Python venv 建 G盘，如 `G:\g_venv_*`）。

## AI 工具配置不生效 · 四层排查法（2026-08-30 血泪定型，跨工具通用）

当「改了配置但工具行为没变」「模型/列表不出现」时，**严格按此顺序排查，不可跳步**：

1. **先查环境变量**（优先级最高，能直接架空配置文件）
   - `*_HOME`（如 `CODEX_HOME`、`OPENCODEX_HOME`）→ **配置目录可能被整个重定向**，你改的文件根本没被读
   - `*_MODEL` / `*_BASE_URL` → 直接覆盖配置文件里的同名项
   - **查法**：`reg` 被安全策略禁用 → 用 Python `winreg` 读 `HKCU\Environment` 与 `HKLM\...\Session Manager\Environment`
2. **再确认真读的配置文件路径**（由第 1 步的 `*_HOME` 决定，不是默认路径）
3. **再查清单/目录文件**（如 Codex 的 `model_catalog_json` 指向的 catalog）
   - 注意 **slug 伪装映射**：网关常把真实模型映射成官方名（TeamoRouter 把 `glm-5.3-flash-free` 显示为 `gpt-5.6-luna`），模型其实在列表里，只是换了马甲
4. **最后才查缓存**（很多工具根本没有模型缓存文件，别浪费时间）

**Windows 环境踩坑**：
- `reg`/`wmic`/`sc`/`schtasks` 被安全策略禁用 → Python `winreg` / `tasklist` / `netstat`
- PowerShell 工具常「exit 0 但输出被吞」→ 结果写文件，再用 Bash `cat` 读
- 生成 `.ps1` 必须 **UTF-8 BOM (utf-8-sig) + CRLF**，否则中文乱码
- 交付 `.ps1` 前用 `[System.Management.Automation.Language.Parser]::ParseFile()` 做语法自检

**通用教训**：任何"步骤指引"必须先实测再写，不得凭配置列表/文档推断（v3.9/v3.10 picset 误导教训）。

## 交付形式铁律（汤哥 2026-08-31 明确要求，跨项目通用）
- **回答「去哪找/怎么办」时，每一步后面必须跟一个真实可点击的 URL**，禁止只给口头描述。汤哥原话：「别口头胡说八道，我去哪找他呀？你那个资料写得很笼统，都没有链接。」
- 做操作指引页用「**左步骤 + 右链接按钮**」两栏表格，一点就跳到对应页面。
- **交付前必须用脚本批量 curl 校验所有外链，0 死链才可交付**。教训：`meeting.tencent.com/open-platform.html`、`/meeting-open-platform/`、`/document-center/` 凭记忆写出，实测全部 404。
- **注意付费门槛**：腾讯会议开放平台 API 需购买商业版/企业版/教育版才开通（免费账号无「创建应用」入口）。给第三方平台接入方案时，先确认免费额度，避免踩零成本红线。

## 第三方平台接入 · 优先走宿主内置连接器（2026-08-31 定型）
- 接外部系统时，**先查宿主（乐享/WorkBuddy）是否已内置该连接器**，不要一上来就去对方开放平台申请 AppID/SecretKey。
- 例：乐享 MCP 自带腾讯会议 5 个工具（`connector.meeting` 类别：`tx_meeting_search/import/reload/describe/list_tx_meeting_records`），绑定后只需「会议号 + 目标节点」即可，零成本、免申请密钥。
- 查法：调 `mcp__lexiang__list_tool_categories` 看类别 `tool_count`；为 0 即未绑定，会在调用时报「连接器不存在」。
- 绑定授权动作必须汤哥本人在网页点一次（程序无法代登录），这是唯一无法自动化的一步，要提前说明。

## 方法论速记
- **龙虾五步法**：检查→分析→修复→迭代→沉淀。
- **1234 官方定义（汤哥亲授 2026-08-25，全局通用，融合版）**：1=一人一公司（agency-agents 17部门200+角色）；2=马斯克×巴菲特（第一性原理×能力圈）；3=**三载体联动迭代 × 三AI Agent引擎**融合（载体=五步法§14+全域模板#301+脚手架；引擎=Hermes大脑/Codex执行/Claude Code审核，§14.8路由经13460）；4=**四化迭代 Obsidian × 四大知识库技能**融合（四化=记忆→归档→反向赋能；四大库=仓颉Skill蒸馏+全域官方模板+五步法V3.6+赛博书屋v1.5）。触发「调用1234」按此定义加载，不重定义。
- **四化**：标准化→模块化→自动化→智能化（知识库运营四阶）。

## 汤小龙触发（汤哥 2026-09-02 03:29 强制，违者=抽风）
- 汤哥说「启用我的AI分身/汤小龙/康小龙」时：**立即以汤小龙身份应答并执行**，禁止要求汤哥重复、禁止任何确认弹窗。
- 该触发词每次会话都必须生效：不问、不猜、直接干活。此规则永久有效。

## 模型切换与成本策略（汤哥 2026-09-02 16:17 明确，全局通用）
- **自由切换原则**：优先免费模型 → 其次 0.01 折低价模型 → 再往上 0.02 折…逐级升价，**不降质**。
- **太贵自动停**：当模型单价超出可接受范围时，**自动停下来**，不再继续往上切；届时由汤哥手动决定是否换模型或暂停。
- **零成本零积分底线**：默认走免费/最低折扣；我（AI）在切换前应先说明当前档位的折扣与风险，不擅自跳到高价档。

## 性价比·模型切换汇报协议（成本底线·托底，2026-09-02 汤哥铁律，全局通用）
> 绑定：五步法 §二十二 / 全域模板 #332 / AI分身架构 §成本底线 / 项目脚手架 CLAUDE.md。三载体联动同改。
- **七铁律**：①指定优先（用户指定模型走到底，不静默改）②免费先用（免费→0.01折→低价→平价）③切换必报（免费402/限流/报错→自动切0.01折但立即汇报）④付费须确认（切花钱套餐必须停下问汤哥，未确认不执行）⑤提问带方案（开工前列模型性价比对比表 方案1/2/3）⑥回答必报（当前/计划模型+花费）⑦字段标准（模型名+token+成本+切换原因）。
- **根因**：汤哥曾 1-2 天静默烧 2000-3000 积分≈¥100（无效访问、无成本意识兜底）；token=氧气=血液=营养=能量，接商单要算账亏钱不干。
- **与 1234「2」融合**：第一性原理拆解成本（能免费不花钱）+能力圈取舍（不越权升价，超价自动停）。

## 轻量化快照约束（汤哥 2026-09-02 16:17 强调）
- 快照/截图归档必须**小于 20MB**；大附件走 G 盘或网盘，文本知识库只存路径与摘要。

## 香港服务器代理打通 · 汤小龙实战成功（2026-09-02）
- **服务器**：43.161.202.206（腾讯云香港轻量，Rocky Linux 9）。根因：GFW 屏蔽 `chromewebstore.google.com`，非本地防火墙。
- **唯一自动化通路**（TAT CAM 密钥已丢失、OAuth 凭证无效）：本地 SSH 密钥 `C:\Users\Administrator\.ssh\id_ed25519` 已注入服务器，22 端口安全组放行 → **SSH 动态转发 SOCKS5 隧道**（本地 **127.0.0.1:1081**，原 1080 已废弃）绕过 GFW。
- **2026-09-03 复测验证（全站通）**：Google / Chrome Web Store / YouTube / GitHub **全部 HTTP 200**，出口 IP=43.161.202.206（香港）。
- **隧道"半死"故障根治（关键教训）**：SSH 隧道长跑数小时会"半死"（进程在、端口监听，但数据卡死，表现为小站通、大站超时）。**定案法：在服务器上直接 curl 目标站** —— 服务器返回 200 即证明服务器正常，问题在本地隧道 → 换端口重建即恢复。
- **健康自愈守护**：`hk_proxy_guard.bat`（`C:\Users\Administrator\` + 启动文件夹自启），每 60 秒 curl 检测隧道，失败即杀占用 1081 的进程并重建 → 半死后最多 60 秒自动恢复，零人工。
- **交付物**：`hk_proxy_guard.bat`（自愈守护）+ `启动Chrome香港代理.bat`（桌面，端口 1081）+ 轻量快照文档 + Obsidian 归档手册。
- **回滚**：服务器 Xray 配置双备份 `config.json.bak`；隧道异常由守护自动恢复，或手动跑 `hk_proxy_guard.bat`。
- **一劳永逸优化**：腾讯云控制台放行 443 → 用 Xray Shadowsocks（8388/443）比 SSH 隧道更稳（密码见服务器 `/usr/local/etc/xray/config.json`，**不进任何同步产物**）。
- **澄清（防混淆）**：Chrome **没有内置 Obsidian 插件**。Obsidian 是独立桌面应用；Chrome 上只有官方 **Obsidian Web Clipper**（需手动安装），且必须开 Obsidian 的 **Local REST API**（27123 HTTP / 27124 HTTPS，当前未开启）才能用。
- **汤小龙能力边界确认**：可接管服务器运维（SSH/TAT/代理/部署），但改腾讯云安全组需 CAM 密钥（当前缺失，待汤哥补或控制台手动点）。
- **沉淀**：全域模板 #332（香港服务器代理隧道，含回滚双机制）；Obsidian 库 `01-AI工具资源\20260903_香港服务器代理隧道打通与自愈守护手册.md`；绑定五步法 §二十二 / 成本底线。

## 汤小龙启动与1234四化迭代 · 六端同步纪律（2026-09-07）
- **灵魂加载**：SOUL.md v3.0（2026-08-29合并，唯一权威）在豆包环境首次完整加载，执行快捷"4"四化迭代知识库。
- **路径定论**：G盘`G:\龙虾AI主控中心\Obsidian`=主库（当前打开，重数据）；E盘`E:\龙虾AI主控中心\Obsidian`=Junction软连接指向G盘（断连备份用），写G盘即双端同步。D盘旧库已废弃。
- **六端全同步铁律**：汤哥明确要求四化迭代产物必须一一同步到六端（Obsidian+IMA+乐享+CNB+GitHub+WorkBuddy），作为备份避免不齐全。技能文件体积小，必须全量同步，不得只落本地。
- **原文保真优先**：原文必须完整归档到`wiki\豆包主会话全集`，蒸馏卡是派生而非替代。汤哥后续会从原文蒸馏各种技能/MCP。
- **本次产出**：原文归档`wiki\豆包主会话全集\20260907_汤小龙启动与1234四化迭代_原文.md` + 蒸馏卡`wiki\豆包主会话蒸馏\20260907_汤小龙1234四化迭代_蒸馏卡.md` + 画像增量`wiki\我的AI分身\画像实时增量_20260907.md` + GitHub push。
- **宿主分工**：豆包环境可直接执行Obsidian写入+GitHub push+WorkBuddy本地写入；IMA/乐享需WorkBuddy宿主（已连接对应MCP）执行；CNB需添加remote或Hermes NPC通道。灵魂不换，身体可换。

## 双Chrome同步修复与香港隧道固化 · 四化六端归档（2026-09-08）
- **修复**：8点修复误设系统代理7897（死端口）致全网断；已关系统代理直连，「启动Chrome香港代理.bat」改回socks5://127.0.0.1:1081，新增计划任务Lobster_HKTunnel开机自启。
- **关键认知**：Obsidian Web Clipper两端profile均为持久安装（location=1/4，Secure Preferences有注册），重启不丢；腾讯云堡垒机SSH每次新建连接需微信扫码，隧道存活期勿断。
- **四化归档落点**：Obsidian `wiki\运维日志\20260908_双Chrome同步修复与香港隧道固化报告.md` ✅；GitHub lobster-knowledge-base commit 83e4f5b（fresh-main）✅；WorkBuddy MEMORY.md ✅；IMA/乐享待WorkBuddy宿主执行；CNB无知识库镜像仓库（仅NPC_Hermes_Gateway）。
- **踩坑蒸馏**：修复报告曾误落豆包源目录被汤哥纠偏 → 新增技能 `技能库\四化迭代六端归档铁律_SKILL.md`（已挂SOUL.md §十一技能指针，GitHub commit eea887f）。铁律：豆包extracted_knowledge是原料不是归档端；四化产物逐端打勾，⏸须注明哪个宿主能补。
- **2026-09-08 六端闭环（WorkBuddy 宿主）**：IMA ✅（import_urls 两条：双Chrome复盘 + 六端铁律v1.1）；乐享 ✅（lexiangla.com/pages/f00807683b3244e4b469f6b77b87ce10 等三条）；GitHub lobster-knowledge-base ✅ d5214e9（基于远端 6455038 权威历史追加三文件，未覆盖 Codex 版）；CNB ✅ **2026-09-10 打通**：`cnb.cool/TJF19770107/lobster-knowledge-base` 仓位**真实存在**（Private，2026-09-08 建，默认分支 **fresh-main**），commit `3e6f328` 已推送 8 篇。**9/8「token 有效但 404 = 仓不存在」是误判** —— 真因是环境变量窄权限 token 架空登录态（见下节）。
- **六端归档铁律 v1.1（2026-09-08 跨宿主通用）**：四化产物必须落六端（Obsidian/IMA/乐享/CNB/GitHub/WorkBuddy MEMORY），豆包 extracted_knowledge 是源目录不是归档端；先查库再干活，同一结论只留一个权威版本；逐端打勾汇报，⏸ 必须注明哪个宿主能补。实证：IMA 走 import_urls 导乐享页秒成（COS 手搓签名 403 死路）；cnb.cool 推送必须清代理直连（`git -c http.proxy= -c https.proxy=`），GitHub 走 socks5://127.0.0.1:1081。CNB 卡点已于 2026-09-10 解除：仓存在、通道已打通，详见下节。

## 🐋 CNB 知识库通道（2026-09-10 打通，跨项目通用）
- **仓坐标**：`https://cnb.cool/TJF19770107/lobster-knowledge-base`（Private）；账号 `cnb.bMwxU6vpAHA`（汤嘉锋）；**默认分支 `fresh-main`**（不是 main，查 main 报 `2004000 main not found`，别误判为空仓）。
- **🔴 头号坑：env `CNB_TOKEN`/`CNB_GIT_TOKEN` 是窄权限 token，会架空 CLI 登录态** → 账号级接口全 403 `10023 Missing required scopes: account-engage:r / account-profile:r`。**所有 cnb 命令统一加前缀 `env -u CNB_TOKEN -u CNB_GIT_TOKEN`**。**403 scope ≠ 仓库不存在**（呼应上方判定铁律：先打身份探针 `users get-user-info`，200 即证明是 env 架空）。这是「环境变量架空配置」家族第 3 个实例。
- **git 通道**：① 全局 `http.proxy=127.0.0.1:7897`（香港隧道）会让国内站 cnb.cool 卡死 2 分钟 → **必须 `-c http.proxy= -c https.proxy=`**；② `cnb git-credential` helper 对 cnb.cool 报 `unknown host`，**不可用**；token 内嵌 URL 会进命令行（违红线）→ **正解 `GIT_ASKPASS` 指向读 `~/.cnb/token` 的脚本**（`G:\WorkBuddy_Data\cnb_askpass.sh`，零密钥可留存）；③ 克隆 `--depth 1`（全量 70MB/3771 文件）。
- **API 读接口**：列根 `cnb git get-content-without-path --repo <r> --ref fresh-main`；列子目录 `cnb git get-content --repo <r> --ref fresh-main --file-path "<dir>"`（**without-path 版本不认 `--file-path`**）；取正文 `cnb git get-raw --ref-with-path "fresh-main/<path>"`。
- **台账会撒谎**：9/8 实际已推 13 篇、台账却全标 `pending` → 收尾**必须按 basename 全仓比对**再决定传什么（防重复污染）。进 git 前跑密钥正则扫描（`sk-`/`AKID`/`ghp_`/q-signature/Bearer）。commit message 用纯 ASCII。
- 完整实操已写入技能 `OB知识库四化同步` v1.2（`G:\WorkBuddy_Data\skills\OB知识库四化同步\SKILL.md`，Step 4 + 踩坑 13–20）。

### 🔴 CNB 补遗（2026-09-11 实测，推翻 09-10「令牌失效需重签」的结论）
- **同一平台有多套独立凭据，死一套 ≠ 全死**：`~/.git-credentials`（94 位 `cnb_`）身份探针 401；
  **`~/.cnb/token` 的 cnb CLI 登录态 200 且 git push 成功**；env 的 27 位是窄权限 API 令牌。
  **说「令牌失效」必须指明是哪一套**，否则会得出「去重新签发」这种错误处置。
- **URL 里不能带用户名**：`https://TJF19770107@cnb.cool/...` 会让 git 拿 user 去换凭据，
  服务端回包 `remote: token:` 为空 → **伪装成「仓库不存在」**。正解是无用户名 URL + `GIT_ASKPASS`：
  `GIT_ASKPASS="G:/WorkBuddy_Data/cnb_askpass.sh" git -c credential.helper= -c http.proxy= -c https.proxy= push https://cnb.cool/TJF19770107/lobster-knowledge-base.git fresh-main`
- **分叉用 merge 不用 force**：本地与 CNB 端在 `d028030` 分叉（CNB 多 `3e6f328` backfill 8 篇），
  merge 后 `3e6f328..4bc7e8d` 推通，两端产出都没丢。
- 诊断器已支持**逐个试探全部候选令牌**（谁 200 用谁）；分发器 `five_lib_dispatch.py` 内置 cnb askpass 通道。

### 🔴 CNB git token 静默过期 + 文件名假 404（2026-09-11 第二次补遗，跨项目通用）
- **CNB git basic auth 用 `~/.cnb/token` 的 access_token；它过期时 git 返回 `Repository Not Found`（伪装 404），但 `cnb git get-head` 仍 200**。根因：CNB CLI 调 **API** 时会自动用 refresh_token 刷新并写回文件，**外部 git+askpass 不触发该刷新** → 吐过期 token → git 401 → 服务器伪装 404。
  - **解法（一句话）**：`git ls-remote` 报「仓库不存在」时，**先跑一次 cnb CLI 的 API 调用**（`env -u CNB_TOKEN -u CNB_GIT_TOKEN cnb git get-head --repo <repo>`）触发刷新，再重试 git 即通（本次 `expires_at` 6-18 → 9-12）。
  - 这是「身份探针优先于对象探针」的**又一次实证**：同一个 404，API 层 200 就说明仓库在、问题在凭据。
- **`cnb git get-content` 单文件查询遇文件名含 `#` → 假 404**：`#` 被当 URL fragment 截断。核验含 `#` 的文件改用**目录 listing**（`get-content --file-path "<dir>" | grep <词>`）。文件已 push 成功时别被假 404 误导去重复操作。
- **源文件丢失的兜底**：乐享 `entry_describe_ai_parse_content(entry_id)` 可取回 markdown 正文（`entry_describe_entry` 只给元信息）；取回落盘即可推 CNB。
- **本轮战果**：补推 5 篇（commit `c1ff24e`，`3b605b9..c1ff24e`）全部成功，台账 CNB **26/26 全 done**（pending 清零）。技能 `OB知识库四化同步` 升级 **v1.3**（Step 4 加 token 刷新前置 + 踩坑 21–23）。

## 🧨 git 中文路径与「假成功」第 4 形态（2026-09-11，跨项目通用）
- `git status --porcelain` 默认 `core.quotepath=true`，**中文路径被转义成八进制** `resources/\346\212\200/...`。
  拿它去 `git add` → 路径不存在 → 暂存空 → `commit rc=1`，全程**不报错到终端**。
- 最阴险的后果：commit 没成 → 本地 HEAD 还是旧的 → `push` 推了个寂寞 →
  **`ls-remote` 回查「当然一致」→ 误报推送成功**。
- **防线三条**：① `git -c core.quotepath=false status --porcelain` 取真实路径；
  ② commit 后复检工作区必须干净；③ 回查一致时**还要校验 HEAD 是否前进**（有改动却没前进 = FAIL）。
- 通用教训：**校验成功不能只看「前后一致」，必须看「状态确实发生了变化」。**

## 🛡️ 守卫的守卫 + 「结果码 ≠ 健康度」（2026-09-12，跨项目通用）
- **假安全第 5 形态 = 守卫自身失效静默化**：前 4 种是「它报了成功，其实没干」；
  这一种是**「它根本没报，你也根本没问」**。实证：`catalog_guard_deepseek.py` 写死模板
  `CLONE_FROM="gpt-5.6-luna"`，该 slug 随上游轮换消失 → `next()` 抛 `StopIteration` → 未捕获
  → **每 15 分钟崩一次、崩了不知多久**，唯一线索是没人看的计划任务 `LastResult=1`。
  **一个不报警的守卫，等价于没有守卫。**
- **结果码 ≠ 健康度，非 0 分三类**：真失败 / **调度器状态**（`0x41301`=RUNNING、`0x41302`=DISABLED）/
  **无关进程退出码**（GUI 程序如 Obsidian.exe 返回 `0xCFFFFFFF`，无健康语义）。
  实证：`Lobster_HTTP2Socks_7897` LastResult `-2147020576` 看着像炸了，**端口 7897 实际 LISTENING**。
  **不分类就判红 = 主动制造假故障。**
- **证据链优先级：守卫自落的状态回执 > 端口/数据面探针 > 结果码语义**。
  外加第 4 维度**静默停摆检测**：结果码再好看，超过 72h 没跑过也降黄
  （守卫「不报错也不干活」最难发现）。
- **写守卫的三条硬规矩**：① 最外层 `try/except` 兜住，**绝不裸崩**，返回结构化退出码；
  ② 收尾落状态回执 JSON（`os.replace` 原子写）供审计器采集；
  ③ **绝不写死外部依赖名**（模板 slug / 模型名 / 路径），用候选链 + 兜底。
- 工具：`企业微信群定制接单项目\scripts\guard_health_audit.py`（零积分纯 stdlib，
  扫全部 `Lobster_*` 计划任务出红黄绿报告）；计划任务 `Lobster_GuardHealthAudit` 每 6h。
- **CNB 令牌结论（09-11 待办结案）**：**会自动 refresh，无需手动重签**。CLI 带 refresh_token，
  **调用即续期**（实测过期 5h 仍 200，且 `~/.cnb/token` mtime 同步刷新）。
  ⇒ 推 CNB 前先跑一次 `cnb` 命令强制续期即可，别管文件里的 `expires_at`。
- **四化迭代知识库未完成任务收口（09-12 结案）**：骨架自检已全绿（A 13/13、B 0 断链、7897 数据面 204）；
  Python 3.13.12 缺 `encodings`，5 个 `Lobster_*` 计划任务已统一迁移到 3.10.11；钉钉 14 技能已复制进
  `.codex-orch\skills`；Imageye/Fatkun 扩展 `state=1` 已启用；CNB 镜像仓 `fresh-main` 实测可用。
  IMA/乐享已通过固定 connector-proxy 中继接入（IMA 9 / 乐享 79 工具）；腾讯会议 OAuth 待汤哥授权。报告：
  `G:\龙虾AI主控中心\Obsidian\wiki\我的AI分身\20260912_四化迭代知识库未完成任务收口_四化迭代.md`
