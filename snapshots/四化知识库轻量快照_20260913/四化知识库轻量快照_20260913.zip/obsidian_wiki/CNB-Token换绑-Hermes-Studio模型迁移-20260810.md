---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_b9801622942b11f1bcfc525400e6dd8f
    ReservedCode1: n1LO5g5NSGR6trAKkM7bH1BsU0fkpp+VtJ3qehUcZEjsw+J2JvVEcm1bf8Y4hQh9PDSSMzyQOdopYITQUsetEe1wnV2BmIfD4DhM0KXV2ZWaWx7vtV3UwkccnFLIOb93P5V8mA7ioWHTcuW6Bsq3CCnLidayKUweI8pJ5pnLqRalzFnVFeKNuU69KwA=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_b9801622942b11f1bcfc525400e6dd8f
    ReservedCode2: n1LO5g5NSGR6trAKkM7bH1BsU0fkpp+VtJ3qehUcZEjsw+J2JvVEcm1bf8Y4hQh9PDSSMzyQOdopYITQUsetEe1wnV2BmIfD4DhM0KXV2ZWaWx7vtV3UwkccnFLIOb93P5V8mA7ioWHTcuW6Bsq3CCnLidayKUweI8pJ5pnLqRalzFnVFeKNuU69KwA=
---



---
tags: [CNB, Hermes-Studio, Token, 模型迁移, deepseek-v4-flash]
date: 2026-08-10
protocol: "#298"
---

# CNB Token换绑与Hermes Studio模型迁移联调报告

## 一、任务背景

Hermes Studio全局及房间Agent模型已从Xiaomi MiMo迁移至CNB免费deepseek-v4-flash。运行时config.yaml（`C:\Users\Administrator\.hermes\config.yaml`）model段已配置provider=cnb-codebuddy、default=deepseek-v4-flash。

2026-08-10发现CNB_TOKEN过期（errcode:16），用户提供新Token：`3VZT1978ZS8pYcuI2fZElbXXxBH`。

## 二、验证结果

### 2.1 API连通性测试

| 项目 | 值 |
|------|-----|
| 端点 | https://api.cnb.cool/TJF19770107/orca-jiedan/-/ai/chat/completions |
| Token | 3VZT1978ZS8pYcuI2fZElbXXxBH |
| 模型 | deepseek-v4-flash |
| 返回 | errcode:403 errmsg:[NO_RIGHT]OpenAPI only allowed in pipeline |

### 2.2 结论

- **Token有效**：非过期（errcode:16），认证层通过
- **权限不足**：授权层403，Token仅限CNB Pipeline内部使用
- **根因**：创建Token时未勾选OpenAPI权限范围
- **影响**：config.yaml已就绪，但Hermes Studio无法通过该Token发起API调用

## 三、配置变更

### config.yaml 修改

| 位置 | 旧值 | 新值 |
|------|------|------|
| model.api_key | cnb_7AuNZi... | 3VZT1978ZS8p... |
| custom_providers[cnb-codebuddy].api_key | cnb_7AuNZi... | 3VZT1978ZS8p... |

### 脚手架同步

`orca_multi_agent_fleet_v1.0` 全局搜索 → 无旧Token残留。

## 四、四化分析

### 智能化
- 自动检测Token过期（errcode:16），提示用户刷新
- 自动识别新Token权限问题（403 vs 16），区分认证失败与授权失败

### 定制化
- config.yaml三Provider并行：cnb-codebuddy（Pipeline）/ deepseek-official（直连）/ xiaomimimo（MiMo）
- 新旧不删，支持回退

### 全自动化
- 批量替换config.yaml全部Token引用点
- 脚手架目录自动巡检旧Token残留
- 全域模板自动追加协议编号

### 自我净化
- 旧Token `cnb_7AuNZiWS1f10VGYBOsgQgMygpDA` 已从配置中清除
- 无残留引用，全量替换

## 五、成本复盘

- 工具调用：6次（API测试1 + config读取1 + 脚手架搜索1 + python替换1 + 模板读取2）
- 全部零积分本地操作
- 性价比：高（无需外部API）

## 六、待办

1. [ ] 用户在CNB平台创建具备OpenAPI权限的新Token
2. [ ] Token就绪后执行Hermes Studio实际对话验证
3. [ ] 验证通过后考虑停用xiaomimimo20260612（需用户确认）
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
