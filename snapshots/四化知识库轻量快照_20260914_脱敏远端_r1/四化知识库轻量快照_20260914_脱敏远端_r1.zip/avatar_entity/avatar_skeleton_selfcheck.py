#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
avatar_skeleton_selfcheck.py · 汤小龙骨架自检
================================================
三类检查（零依赖，纯标准库）：
  A. 骨架文件存在性  —— 灵魂/框架/技能库主文件是否在位
  B. 指针可达性      —— SOUL.md / AGENTS.md 里反引号路径是否真能落地（抓「静默断链」）
  C. 运行时健康      —— 代理链路（先看监听，再探数据面）+ 可选 CDP 端口

触发：启动我的AI分身（自动）/ 「骨架自检」/ 「分身自检」
用法：
  python avatar_skeleton_selfcheck.py            # 完整报告
  python avatar_skeleton_selfcheck.py --quiet    # 只报问题（启动时用）
  python avatar_skeleton_selfcheck.py --json out.json
退出码：0 = 全绿；1 = 有问题
"""
import os
import re
import sys
import json
import socket
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
WU = os.path.dirname(os.path.dirname(HERE))          # lobster_task_standard_workflow_v3.0\
LIB = os.path.dirname(WU)                            # 技能库\
AIROOT = os.path.dirname(LIB)                        # 我的AI分身\

DRIVE_LIB = os.path.splitdrive(LIB)[0] or "E:"       # 技能库所在盘

# ---------- A. 骨架清单 ----------
def skeleton_items():
    return [
        ("灵魂 SOUL.md",                os.path.join(HERE, "SOUL.md")),
        ("框架身 AGENTS.md",            os.path.join(HERE, "AGENTS.md")),
        ("技能索引.md",                 os.path.join(HERE, "技能索引.md")),
        ("内置技能 self-evolution-loop", os.path.join(HERE, "技能", "self-evolution-loop", "SKILL.md")),
        ("龙虾五步法 V3.6",             os.path.join(WU, "龙虾五步法V3.6·PR#21闭环版（成本优先置顶）SKILL.md")),
        ("全域官方模板-最终版",          os.path.join(WU, "龙虾全域官方模板-最终版.md")),
        ("1234 定义卡",                 os.path.join(WU, "20260825_1234快捷体系_官方定义卡.md")),
        ("四化迭代六端归档铁律",         os.path.join(LIB, "四化迭代六端归档铁律_SKILL.md")),
        ("仓颉Skill知识蒸馏",            os.path.join(WU, "仓颉Skill知识蒸馏技能.md")),
        ("赛博书屋 v1.5",               os.path.join(WU, "赛博书屋（Cyber Book House）v1.5SKILL.md")),
        ("角色库路由 router",            os.path.join(r"G:\WorkBuddy_Data\skills", "agency-agents-router", "SKILL.md")),
        ("角色索引 roles_index.tsv",     os.path.join(r"G:\WorkBuddy_Data\skills", "agency-agents-router", "references", "roles_index.tsv")),
        ("角色库根 agency-agents",       os.path.join(LIB, "agency-agents")),
    ]


# ---------- B. 指针扫描 ----------
HOME = os.path.expandvars(r"%USERPROFILE%")

# 明确可判定的路径前缀（带盘符 / 技能库 / 我的AI分身 / 分身实体 / Obsidian）
PATHY = re.compile(r"^([A-Za-z]:[\\/]|技能库[\\/]|我的AI分身[\\/]|AI分身实体[\\/]|Obsidian[\\/])")
EXT = re.compile(r"\.(md|py|json|tsv|toml|yaml|bat|ps1|cmd|txt|db|ini)$", re.I)
# 噪声过滤器：占位符 / 通配 / URL / host:port / 空格斜杠 / 省略号 / 纯变量名
NOISE = re.compile(r"(\{|\}|<|>|\*|https?://|^[\w\.\-]+:\d| / |\.\.\.|^[A-Z_]+( / |$)|^[A-Z_]+$)")


def _norm(raw):
    return raw.replace("/", os.sep)


def is_checkable(raw):
    if NOISE.search(raw):
        return False
    if not (PATHY.match(raw) or (("\\" in raw or "/" in raw) and EXT.search(raw))):
        return False
    # 纯文件名（无路径分隔符）无法判定基准，跳过
    if "\\" not in raw and "/" not in raw:
        return False
    return True


def obsidian_root():
    """Obsidian 主库真实位置（G 盘优先；E 盘为历史位置）"""
    for c in (r"G:\龙虾AI主控中心\Obsidian", r"E:\龙虾AI主控中心\Obsidian"):
        if os.path.isdir(c):
            return c
    return r"G:\龙虾AI主控中心\Obsidian"


def resolve(raw):
    """解析成绝对路径；返回 (path, how)。基准按首段判定，不一律套分身根。"""
    p = _norm(raw).rstrip(os.sep)
    if re.match(r"^[A-Za-z]:", p):
        return p, "绝对"
    # 父级相对：..\xxx 以分身实体目录为基准
    if p.startswith(".." + os.sep) or p == "..":
        return os.path.normpath(os.path.join(HERE, p)), "实体目录相对(父级)"
    seg = p.split(os.sep)[0]
    if seg == "技能库":
        return os.path.join(LIB, *p.split(os.sep)[1:]), "技能库相对"
    if seg == "我的AI分身":
        return os.path.join(AIROOT, *p.split(os.sep)[1:]), "分身根相对"
    if seg == "AI分身实体":
        return os.path.join(HERE, *p.split(os.sep)[1:]), "实体目录相对"
    if seg == "Obsidian":
        return os.path.join(obsidian_root(), *p.split(os.sep)[1:]), "Obsidian主库相对"
    if seg.startswith("."):                       # .codex / .agents / .codex-orch → 用户目录
        return os.path.join(HOME, *p.split(os.sep)), "用户目录相对"
    return None, "无法判定"


def extract_pointer_paths(md_path):
    """从 md 里抽反引号路径（只留可判定的）"""
    try:
        text = open(md_path, encoding="utf-8", errors="ignore").read()
    except Exception:
        return []
    found = set()
    for m in re.finditer(r"`([^`\n]{4,300})`", text):
        raw = m.group(1).strip()
        if is_checkable(raw):
            found.add(raw)
    return sorted(found)


def pointer_check():
    rows, skipped = [], 0
    for name in ("SOUL.md", "AGENTS.md", "技能索引.md"):
        md = os.path.join(HERE, name)
        for raw in extract_pointer_paths(md):
            path, how = resolve(raw)
            if path is None:
                skipped += 1
                continue
            rows.append({
                "from": name, "raw": raw, "resolved": path, "how": how,
                "exists": os.path.exists(path),
                "is_dir": os.path.isdir(path),
            })
    return rows, skipped


# ---------- C. 运行时健康 ----------
def listening(port, host="127.0.0.1", timeout=1.5):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except Exception:
        return False
    finally:
        s.close()


def socks5_probe(port, host="www.google.com", dst=443, timeout=8):
    """原生 SOCKS5 数据面探针（atyp=3 域名透传，由远端解析）—— 铁律法，零依赖"""
    t0 = datetime.datetime.now()
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect(("127.0.0.1", port))
        s.sendall(b"\x05\x01\x00")
        if s.recv(2) != b"\x05\x00":
            return {"ok": False, "err": "握手失败"}
        hb = host.encode("idna")
        s.sendall(b"\x05\x01\x00\x03" + bytes([len(hb)]) + hb + dst.to_bytes(2, "big"))
        r = s.recv(4)
        if len(r) < 4 or r[1] != 0:
            code = r[1] if len(r) > 1 else -1
            return {"ok": False, "err": "CONNECT 拒绝 code=%d" % code}
        dt = (datetime.datetime.now() - t0).total_seconds()
        return {"ok": True, "code": "socks5-ok", "sec": round(dt, 3)}
    except Exception as e:
        return {"ok": False, "err": type(e).__name__}
    finally:
        s.close()


def http_probe(port, timeout=8):
    """走 HTTP 中转器取 generate_204"""
    import urllib.request
    t0 = datetime.datetime.now()
    try:
        op = urllib.request.build_opener(urllib.request.ProxyHandler(
            {"http": "http://127.0.0.1:%d" % port, "https": "http://127.0.0.1:%d" % port}))
        with op.open("https://www.google.com/generate_204", timeout=timeout) as r:
            code = r.status
        dt = (datetime.datetime.now() - t0).total_seconds()
        return {"ok": code in (200, 204), "code": code, "sec": round(dt, 3)}
    except Exception as e:
        return {"ok": False, "code": None, "err": type(e).__name__}


def runtime_check(cdp_ports=(9222, 9223), deep=False):
    """铁律：先看监听，再做数据面探针；未监听就不探（避免误判为「又挂了」）"""
    res = {}
    for label, port in (("7897 中转器", 7897), ("1081 SSH隧道", 1081)):
        lis = listening(port)
        item = {"listening": lis, "probe": None, "probe_mode": "deep" if deep else "quick"}
        if lis and deep:
            item["probe"] = http_probe(port) if port == 7897 else socks5_probe(port)
        elif lis:
            # 快模式：只对 7897 做一次轻探（1081 不单独探，铁律：走 7897 通即隧道通）
            if port == 7897:
                item["probe"] = http_probe(port, timeout=6)
        res[label] = item
    res["CDP 端口"] = {str(p): listening(p) for p in cdp_ports}
    return res


# ---------- 主流程 ----------
def run(quiet=False, deep=False, json_out=None):
    """可复用入口：返回 result dict。启动链直接 import 调 run(quiet=True)。"""
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    problems = []

    # A
    skel = []
    for label, path in skeleton_items():
        ok = os.path.exists(path)
        skel.append({"label": label, "path": path, "ok": ok})
        if not ok:
            problems.append("骨架缺失: %s -> %s" % (label, path))

    # B
    ptr, skipped = pointer_check()
    broken_ptr = [r for r in ptr if not r["exists"]]
    for r in broken_ptr:
        problems.append("指针断链: [%s] `%s` -> %s" % (r["from"], r["raw"], r["resolved"]))

    # C
    rt = runtime_check(deep=deep)
    for label, item in rt.items():
        if label == "CDP 端口":
            continue
        if not item["listening"]:
            problems.append("运行时: %s 未监听" % label)
        elif item["probe"] and not item["probe"]["ok"]:
            problems.append("运行时: %s 监听正常但数据面不通(先看监听已排除端口未起)" % label)

    # 输出
    if not quiet:
        print("=" * 58)
        print("  汤小龙 · 骨架自检  %s" % ts)
        print("=" * 58)
        print("\n[A] 骨架文件存在性  %d/%d" % (sum(1 for x in skel if x["ok"]), len(skel)))
        if not quiet:
            for x in skel:
                print("   %s %s" % ("✅" if x["ok"] else "❌", x["label"]))
        print("\n[B] 指针可达性  %d 条可判定 / %d 条断链（另有 %d 条无法判定基准，已跳过）" % (len(ptr), len(broken_ptr), skipped))
        for r in broken_ptr[:20]:
            print("   ❌ [%s] %s -> %s" % (r["from"], r["raw"], r["resolved"]))
        print("\n[C] 运行时健康")
        for label, item in rt.items():
            if label == "CDP 端口":
                continue
            lis = "✅ 监听" if item["listening"] else "❌ 未监听"
            pr = ""
            if item["probe"]:
                pr = " ｜ 数据面 %s%s" % ("✅" if item["probe"]["ok"] else "❌",
                                        (" %s" % item["probe"].get("code")) if item["probe"].get("code") else
                                        (" %s" % item["probe"].get("err", "")))
            print("   %s %s%s" % (lis, label, pr))
        cdp = ", ".join("%s=%s" % (k, "开" if v else "关") for k, v in rt["CDP 端口"].items())
        print("   ℹ️ CDP 端口: %s" % cdp)
    else:
        if problems:
            print("[骨架自检] ⚠️ 发现 %d 个问题：" % len(problems))
            for p in problems:
                print("   - " + p)
        else:
            print("[骨架自检] ✅ 骨架/指针/运行时 全绿")

    result = {
        "ts": ts, "ok": not problems, "problems": problems,
        "skeleton": skel, "pointers": ptr, "runtime": rt,
    }
    if json_out:
        try:
            with open(json_out, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            if not quiet:
                print("\nJSON -> %s" % json_out)
        except Exception as e:
            print("写 JSON 失败: %s" % e)

    return result


def main():
    quiet = "--quiet" in sys.argv
    deep = "--deep" in sys.argv
    json_out = None
    if "--json" in sys.argv:
        i = sys.argv.index("--json")
        if i + 1 < len(sys.argv):
            json_out = sys.argv[i + 1]
    res = run(quiet=quiet, deep=deep, json_out=json_out)
    return 0 if res["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
