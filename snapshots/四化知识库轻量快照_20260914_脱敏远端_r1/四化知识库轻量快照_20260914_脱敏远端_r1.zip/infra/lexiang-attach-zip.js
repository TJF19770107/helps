#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const RELAY_URL = "http://127.0.0.1:58721/mcp";

async function mcpCall(tool, args, sessionId) {
  const res = await fetch(RELAY_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      accept: "application/json, text/event-stream",
      ...(sessionId ? { "mcp-session-id": sessionId } : {}),
    },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: sessionId ? 2 : 1,
      method: sessionId ? "tools/call" : "initialize",
      params: sessionId
        ? { name: tool, arguments: args }
        : {
            protocolVersion: "2024-11-05",
            capabilities: {},
            clientInfo: { name: "tangxiaolong-lexiang-attach", version: "1.0" },
          },
    }),
  });

  const text = await res.text();
  const dataLine = text.split(/\r?\n/).find((line) => line.startsWith("data: "));
  if (!dataLine) throw new Error(`No MCP response: HTTP ${res.status} ${text.slice(0, 500)}`);
  const data = JSON.parse(dataLine.slice(6));
  if (data.error) throw new Error(JSON.stringify(data.error));

  const content = data.result?.content;
  const innerText = Array.isArray(content) ? content[0]?.text : content?.text;
  let inner = null;
  if (innerText) {
    try {
      inner = JSON.parse(innerText);
    } catch {
      throw new Error(`Non-JSON tool result: ${String(innerText).slice(0, 800)}`);
    }
  }
  return { sid: res.headers.get("mcp-session-id"), inner };
}

async function main() {
  const entryId = process.argv[2];
  const zipFile = process.argv[3];
  if (!entryId || !zipFile) {
    console.error("usage: node lexiang-attach-zip.js <entry_id> <zip>");
    process.exit(2);
  }

  const stat = fs.statSync(zipFile);
  const init = await mcpCall("noop", {}, null);
  const apply = await mcpCall(
    "lexiang_block_apply_block_attachment_upload",
    {
      entry_id: entryId,
      name: path.basename(zipFile),
      size: String(stat.size),
      mime_type: "application/zip",
    },
    init.sid
  );

  const sessionId = apply.inner?.data?.session_id;
  const uploadUrl = apply.inner?.data?.upload_url;
  if (!sessionId || !uploadUrl) {
    throw new Error(`attachment apply returned unexpected payload: ${JSON.stringify(apply.inner)}`);
  }

  const put = await fetch(uploadUrl, {
    method: "PUT",
    headers: { "content-type": "application/zip" },
    body: fs.readFileSync(zipFile),
  });
  if (!put.ok) {
    throw new Error(`Lexiang attachment PUT failed HTTP ${put.status}: ${(await put.text()).slice(0, 500)}`);
  }

  const create = await mcpCall(
    "lexiang_block_create_block_descendant",
    {
      entry_id: entryId,
      descendant: [
        {
          block_type: "attachment",
          attachment: {
            session_id: sessionId,
            view_type: "card",
          },
        },
      ],
    },
    init.sid
  );

  console.log(JSON.stringify({ ok: true, entry_id: entryId, session_id: sessionId, create: create.inner }, null, 2));
}

main().catch((err) => {
  console.error(err.stack || err.message);
  process.exit(1);
});
