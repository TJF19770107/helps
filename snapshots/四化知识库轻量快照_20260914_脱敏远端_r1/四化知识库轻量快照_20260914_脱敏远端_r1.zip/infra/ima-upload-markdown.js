#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const RELAY_URL = "http://127.0.0.1:58721/mcp";

async function mcpCall(tool, args, sessionId) {
  const res = await fetch(RELAY_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      accept: "application/json, text/event-stream",
      ...(sessionId ? { "mcp-session-id": sessionId } : {}),
    },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: sessionId ? 2 : 1,
      method: sessionId ? "tools/call" : "initialize",
      params: sessionId
        ? { name: tool, arguments: args }
        : {
            protocolVersion: "2024-11-05",
            capabilities: {},
            clientInfo: { name: "tangxiaolong-ima-upload", version: "1.0" },
          },
    }),
  });

  const text = await res.text();
  const dataLine = text.split(/\r?\n/).find((line) => line.startsWith("data: "));
  if (!dataLine) throw new Error(`No MCP response: HTTP ${res.status} ${text.slice(0, 500)}`);
  const data = JSON.parse(dataLine.slice(6));
  if (data.error) throw new Error(JSON.stringify(data.error));

  const content = data.result?.content;
  const innerText = Array.isArray(content) ? content[0]?.text : content?.text;
  return {
    sid: res.headers.get("mcp-session-id"),
    data,
    inner: innerText ? JSON.parse(innerText) : null,
  };
}

function hmacHex(key, data) {
  return crypto.createHmac("sha1", key).update(data).digest("hex");
}

function sha1Hex(data) {
  return crypto.createHash("sha1").update(data).digest("hex");
}

function cosPutUrl(cred, key) {
  const host = `${cred.bucket_name}.cos.${cred.region}.myqcloud.com`;
  const keyTime = `${cred.start_time};${cred.expired_time}`;
  const httpString = `put\n/${key}\n\nhost=${host}&x-cos-security-token=${cred.token}\n`;
  const stringToSign = `sha1\n${keyTime}\n${sha1Hex(httpString)}\n`;
  const signKey = hmacHex(cred.secret_key, keyTime);
  const signature = hmacHex(signKey, stringToSign);
  const encodedKey = encodeURIComponent(key).replace(/%2F/g, "/");
  const query = new URLSearchParams({
    "q-sign-algorithm": "sha1",
    "q-ak": cred.secret_id,
    "q-sign-time": keyTime,
    "q-key-time": keyTime,
    "q-header-list": "host;x-cos-security-token",
    "q-url-param-list": "",
    "q-signature": signature,
  });
  return `https://${host}/${encodedKey}?${query.toString()}`;
}

async function main() {
  const file = process.argv[2];
  const knowledgeBaseId = process.argv[3];
  if (!file || !knowledgeBaseId) {
    console.error("usage: node ima-upload-markdown.js <file.md> <knowledge_base_id>");
    process.exit(2);
  }

  const ext = path.extname(file).toLowerCase();
  if (ext !== ".md" && ext !== ".markdown") {
    throw new Error("This uploader currently supports markdown only.");
  }

  const stat = fs.statSync(file);
  const init = await mcpCall("noop", {}, null);
  const create = await mcpCall(
    "ima-mcp_create_media",
    {
      content_type: "text/markdown",
      file_ext: "md",
      file_name: path.basename(file),
      file_size: stat.size,
      knowledge_base_id: knowledgeBaseId,
    },
    init.sid
  );

  if (!create.inner?.media_id || !create.inner?.cos_credential) {
    throw new Error(`create_media returned unexpected payload: ${JSON.stringify(create.inner)}`);
  }

  const mediaId = create.inner.media_id;
  const cred = create.inner.cos_credential;
  const key = String(cred.cos_key).trim().replace(/^\/+/, "");
  const url = cosPutUrl(cred, key);
  const body = fs.readFileSync(file);
  const put = await fetch(url, {
    method: "PUT",
    headers: {
      "content-type": "text/markdown",
      "x-cos-security-token": cred.token,
    },
    body,
  });

  if (!put.ok) {
    const errorText = await put.text();
    throw new Error(`COS PUT failed HTTP ${put.status}: ${errorText.slice(0, 500)}`);
  }

  const add = await mcpCall(
    "ima-mcp_add_knowledge",
    {
      knowledge_base_id: knowledgeBaseId,
      media_id: mediaId,
      duplicate_name_strategy: "DUPLICATE_NAME_STRATEGY_REPLACE",
    },
    init.sid
  );

  console.log(
    JSON.stringify(
      {
        ok: true,
        file: path.basename(file),
        size: stat.size,
        media_id: mediaId,
        add_knowledge: add.inner,
      },
      null,
      2
    )
  );
}

main().catch((err) => {
  console.error(err.stack || err.message);
  process.exit(1);
});
