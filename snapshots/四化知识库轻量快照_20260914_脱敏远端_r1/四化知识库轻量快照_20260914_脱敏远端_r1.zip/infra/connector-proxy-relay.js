#!/usr/bin/env node
"use strict";

const http = require("http");
const { execFileSync } = require("child_process");

const LISTEN_HOST = "127.0.0.1";
const LISTEN_PORT = 58721;
const REFRESH_MS = 5000;

let target = null;
let lastLog = "";

function log(message) {
  const line = `[${new Date().toISOString()}] ${message}`;
  if (line !== lastLog) {
    console.log(line);
    lastLog = line;
  }
}

function discoverTarget() {
  const ps = [
    "Get-CimInstance Win32_Process",
    "| Where-Object { $_.ExecutablePath -like 'D:\\WorkBuddy\\*' -and $_.CommandLine -match 'connector-proxy' }",
    "| Select-Object -First 1 -ExpandProperty CommandLine",
  ].join(" ");

  let commandLine = "";
  try {
    commandLine = execFileSync(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-Command", ps],
      { encoding: "utf8", windowsHide: true, timeout: 8000 }
    ).trim();
  } catch (_) {
    return null;
  }

  const urlMatch = commandLine.match(/http:\/\/127\.0\.0\.1:(\d+)\/mcp/);
  const tokenMatch = commandLine.match(/Bearer\s+([^"\\\s]+)/);
  if (!urlMatch || !tokenMatch) return null;

  return {
    port: Number(urlMatch[1]),
    token: tokenMatch[1],
  };
}

function refreshTarget() {
  try {
    const next = discoverTarget();
    if (next) {
      if (!target || target.port !== next.port || target.token !== next.token) {
        log(`connector-proxy target ${next.port}`);
      }
      target = next;
    }
  } catch (err) {
    log(`discover failed: ${err.message}`);
  }
}

refreshTarget();
setInterval(refreshTarget, REFRESH_MS).unref();

const server = http.createServer((req, res) => {
  if (!target) refreshTarget();
  if (!target) {
    res.writeHead(503, { "content-type": "text/plain; charset=utf-8" });
    res.end("WorkBuddy connector-proxy target not found");
    return;
  }

  const headers = { ...req.headers };
  headers.host = `127.0.0.1:${target.port}`;
  headers.authorization = `Bearer ${target.token}`;

  const proxyReq = http.request(
    {
      hostname: "127.0.0.1",
      port: target.port,
      path: req.url,
      method: req.method,
      headers,
    },
    (proxyRes) => {
      if (proxyRes.statusCode === 401) refreshTarget();
      res.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
      proxyRes.pipe(res);
    }
  );

  proxyReq.on("error", (err) => {
    refreshTarget();
    if (!res.headersSent) {
      res.writeHead(502, { "content-type": "text/plain; charset=utf-8" });
    }
    res.end(`connector-proxy relay error: ${err.message}`);
  });

  req.pipe(proxyReq);
});

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    log(`port ${LISTEN_PORT} already in use; relay already running`);
    process.exit(0);
  }
  log(`server error: ${err.message}`);
  process.exit(1);
});

server.listen(LISTEN_PORT, LISTEN_HOST, () => {
  log(`listening on http://${LISTEN_HOST}:${LISTEN_PORT}/mcp`);
});
