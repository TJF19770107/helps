#!/usr/bin/env node
"use strict";

const URL = "http://127.0.0.1:58721/mcp";

async function post(body, headers = {}) {
  const res = await fetch(URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      accept: "application/json, text/event-stream",
      ...headers,
    },
    body: JSON.stringify(body),
  });

  const text = await res.text();
  const sid = res.headers.get("mcp-session-id");
  const dataLine = text.split(/\r?\n/).find((line) => line.startsWith("data: "));
  if (!dataLine) {
    throw new Error(`No MCP data response. HTTP ${res.status}: ${text.slice(0, 500)}`);
  }
  return { sid, data: JSON.parse(dataLine.slice(6)) };
}

async function main() {
  const tool = process.argv[2];
  const args = JSON.parse(process.argv[3] || "{}");
  if (!tool) {
    console.error("usage: node connector-proxy-call.js <tool> '<json-args>'");
    process.exit(2);
  }

  const init = await post({
    jsonrpc: "2.0",
    id: 1,
    method: "initialize",
    params: {
      protocolVersion: "2024-11-05",
      capabilities: {},
      clientInfo: { name: "tangxiaolong-mcp-call", version: "1.0" },
    },
  });

  if (init.data.error) {
    throw new Error(JSON.stringify(init.data.error));
  }

  const call = await post(
    {
      jsonrpc: "2.0",
      id: 2,
      method: "tools/call",
      params: { name: tool, arguments: args },
    },
    { "mcp-session-id": init.sid }
  );

  console.log(JSON.stringify(call.data, null, 2));
}

main().catch((err) => {
  console.error(err.stack || err.message);
  process.exit(1);
});
