---
tags: [故障库, atomcode_proxy, 并发锁, 403, 稳定性]
date: 2026-08-19
title: atomcode_proxy 并发锁导致老连不通 · 根因定位
---

# atomcode_proxy 并发锁导致老连不通 · 根因定位

> 关联：[[atomcode_proxy_stability_v2_20260812]] · [[codex_ccswitch_atomcode_404_fix_20260812]] · [[hermes_atomcode_timeout_300_fix_20260812]]

## 一、故障现象

- 用户反馈"老连不通"、"稳定性差"
- 13460 代理 `/health` 显示 `atomcode_active: 1, lock_free: False`
- 多窗口/多请求场景下客户端超时

## 二、根因定位（精确到代码行）

**文件**：`E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\atomcode_proxy.py`

**故障链**：

1. **第 164 行**：全局串行锁 `_ATOMCODE_LOCK.acquire(timeout=600)`
   - 设计意图：消 `atomgit_session_concurrency_conflict/403`
   - 副作用：`atomcode_max: 1` 强制串行，并发请求排队 600 秒超时

2. **第 162 行**：每次请求 `fork` 一个 `atomcode.exe` 子进程
   - 多个 `atomcode.exe` 共用同一把 AtomGit OAuth token
   - AtomGit 服务端判并发冲突返回 403

3. **第 205-212 行**：403 自动重试
   - `MAX_403_RETRIES = 3`, `RETRY_DELAY = 3` → 最多 9 秒重试
   - AtomGit 服务端会话释放有延迟（代码注释 `2026-08-17` 明说）
   - 外部并发源未清时 403 间歇反复

## 三、为什么"稳定性差"

| 因素 | 影响 |
|------|------|
| 串行锁 `atomcode_max: 1` | 多请求必排队，600 秒超时 |
| AtomGit 会话释放延迟 | 首次 403 后需等 3 秒重试 |
| 外部并发源（其他 atomcode 实例） | 403 间歇反复 |
| `fork` atomcode.exe 子进程 | 进程启动开销 + token 共用冲突 |

## 四、优化方向（待实施）

1. **锁超时缩短**：600s → 30s，快速失败而非长时间等待
2. **会话释放延迟补偿**：403 后等 5-8 秒再重试（匹配服务端释放周期）
3. **token 池化**：多 token 轮换，绕开单 token 并发限制
4. **NVIDIA 旁路**：`z-ai/glm-5.2` 走 `nvidia_bypass_independent`，已独立无锁

## 五、快照与回滚

- **本份轻量快照**：`E:\龙虾AI主控中心\MCP服务\snapshots\lightweight_20260819_005244\`（138K，19 文件）
- **回滚方法**：`cp -r snapshots/lightweight_20260819_005244/*.py MCP服务/`
- **三引擎完整快照**：`E:\龙虾AI主控中心\MCP服务\snapshots\three_engine_snapshot_*`

## 六、四化校准

| 维度 | 状态 | 说明 |
|------|------|------|
| 智能化 | ✅ | 自主诊断到代码行级，无需用户指引 |
| 定制化 | ✅ | 针对 atomcode_proxy.py 本项目特有故障 |
| 全自动化 | ✅ | 快照+诊断+知识库沉淀一键完成 |
| 自我净化 | ✅ | 故障库新增条目，反向赋能下次诊断 |

## 七、1234 快捷调用执行

- **1 一人一公司**：`技能库\agency-agents\` 17 部门 200+ 角色，本次故障属运维类，对应 `devops/` 角色
- **2 马斯克×巴菲特蒸馏**：第一性原理拆解 → 根因是"token 共用 + 服务端会话延迟"，非代理本身 bug
- **3 三载体联动迭代**：五步法 §14 + 全域模板 #301 + 脚手架，本份快照已落地
- **4 四化迭代 Obsidian**：本条目即知识库反向赋能，Obsidian 主库已写入

---

*本条目由 AtomCode (GLM-5.2) 于 2026-08-19 自主沉淀，遵循四化校准铁律。*
