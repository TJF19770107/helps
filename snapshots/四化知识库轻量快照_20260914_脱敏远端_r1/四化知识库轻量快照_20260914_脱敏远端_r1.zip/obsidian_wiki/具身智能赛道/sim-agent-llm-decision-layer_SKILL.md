---
name: sim-agent-llm-decision-layer
description: 给仿真/机器人 Agent 接入「LLM 决策层 + 免费本地网关」的可复用范式（自然语言→结构化航点/动作，网关不可用自动回退规则策略），并配纯标准库/MuJoCo 双物理后端。触发词：仿真Agent、LLM决策层、无人机Agent、机器人Agent、航点规划、具身智能Demo、gateway决策层、car/robot Agent。
version: 1.2
agent_created: true
updated: 2026-09-14
source: AI具身智能赛道 T003-v2（2026-09-10 原始）；v1.1=car 迁移验证；v1.2=人形迁移验证 + 网关别名二次实测
---

# 仿真 Agent · LLM 决策层范式（v1.0）

> 一句话：**决策交给 LLM（自然语言→JSON 计划），动作交给物理层（PD 控制），两者解耦、任一层可独立替换**；全程只打本地免费网关，**零积分**。

## 一、适用场景
- 无人机 / 无人车 / 机器人 / 集群 Agent 的**最简可跑 Demo 起步**
- 需要「自然语言任务 → 结构化动作计划」的任何具身/仿真任务
- 想复用现有免费网关（TeamoRouter 18091 / 51427 等）而不烧钱的场景

## 二、三层架构（照抄即可）

```
L3 任务编排  run_mission(mission) → policy.plan() → 航点 → 物理层执行 → 汇报 dict
L2 决策层    LLMPolicy（免费网关，同族前缀校验，失败自动回退） | RulePolicy（离线兜底）
L1 物理层    PhysicsLiteDrone（纯标准库，四旋翼点质量+PD）| MuJoCoDrone（MJCF+freejoint）
```

模块拆分铁律：**`llm_decision`、`physics backend`、`mission runner` 三段物理隔离**，换物理后端不动决策层，换网关不动物理层。

## 三、L1 物理层（两个后端）

### 3.1 lite 后端（纯标准库，零依赖，默认）
- 点质量模型：`az = thrust - g`，线性阻力 `-k*v`，`dt=0.05`
- 三个控制基元：`hover(z)` / `goto_xy(target, cruise_z)` / `land()`
- 速度梯形律：`want_v = sqrt(2*a_max*dist)`，避免过冲
- **降落必须加水平阻尼刹车**：`acc = -2.0 * v_xy`（否则落地漂移，实测 1.5m→0.5m）

### 3.2 MuJoCo 后端（可选，CPU 可跑）
- 安装隔离：`pip install --target G:/g_venv_mujoco mujoco`（**装 G 盘，不压 C/E 盘**），运行时 `PYTHONPATH=G:/g_venv_mujoco MUJOCO_GL=disable`
- MJCF 最小模型：`<option gravity="0 0 -9.81" timestep="0.05"/>` + `<geom type="plane">` 地面 + `<body><freejoint/><geom type="sphere" size="0.1" mass="1.0"/></body>`
- 驱动力：`data.xfrc_applied[bid][:3] = [fx, fy, fz]` 每步写一次后 `mj_step`

### ⚠️ 双后端两个必踩坑（实测）
1. **双重计重力**：MuJoCo 引擎自带重力，`xfrc_applied` 必须喂**全量推力**。若沿用 lite 的 `thrust-g` 净力习惯 → 合力向下、无人机压地飞不起来（现象：z 卡在 0.09 不动）。诊断法：裸跑 `mj_step` 打印 `qvel` 增量，反推实际合力。
2. **触地判定阈值**：球体半径 r 时，球心停在 z≈r，落地判据用 `z <= r + 0.02`，**不能用 z<=0**。

## 四、L2 决策层（核心，可跨项目复用）

```
LLMPolicy(base_url="http://127.0.0.1:18091", model="deepseek-v4-flash-free")
  ├─ prompt 要求「Reply ONLY with JSON: {"waypoints": [[x,y,z],...]}」
  ├─ 截取首个 { 到末个 } 再 json.loads（容忍模型加解释文字）
  └─ 任何异常 → RulePolicy 兜底，绝不阻塞仿真
```

### 4.1 网关纪律（汤哥红线，必须内建）
| 纪律 | 做法 |
|---|---|
| 只用免费 | 只打本地网关端口，禁付费 API；默认 `deepseek-v4-flash-free` |
| **切换必报（校验 model）** | 读返回体 `data["model"]`，与请求模型做**同族前缀**比对，不符则抛错并回退 |
| 中文坑规避 | prompt 一律 **ASCII**（51427 曾中文 payload 反序列化失败） |
| 回退不阻塞 | 网关 402/超时/改名 → 立即用 RulePolicy，`last_backend` 标记供汇报 |

### 4.2 ⭐ 实测关键结论：`-free` 别名会「同族改名」，≠ fallback 付费
```
请求 model: deepseek-v4-flash-free
实际返回:   deepseek-v4-flash-ga-260731   ← 同族免费，不是付费档！（2026-09-10 实测）
实际返回:   deepseek-v4-flash-0731        ← 又一种同族别名（2026-09-14 二次实测）
```
**别名会变（ga-260731 / 0731 …），但族名不变。** 校验规则：`family = 请求模型.rsplit("-free",1)[0]`（= `deepseek-v4-flash`），`返回.model.startswith(family)` 即通过。
早期写成「返回串必须含 free」会**误杀正常免费响应**（本技能踩过一次）。

### 4.3 网关探活（上任务前先探）
```
GET http://127.0.0.1:<port>/v1/models   # 200 = 可用
试用端口：18091(TeamoRouter) / 51427 / 15731(HY3) / 18808(MiMo)
```

## 五、测试与验证（离线优先）
- `unittest` 纯离线：物理层（到达/落地/不穿地）+ 决策层（把 base_url 指向死端口 `127.0.0.1:9`，断言回退到 rule）
- 实跑命令：`python drone_llm_agent.py --backend lite|mujoco --mission "patrol the area"`
- 验收口径：`all_reached=True` + `landed=True` + 测试全绿

## 六、与龙虾舰队协作（落卡铁律）
1. 任务卡走 `fleet_exchange/`：`incoming/ → doing/ → done/`，卡内 `## 结果` 段填产出/验证/遗留
2. 交付必附三行：`✅ 已完成 / 📁 结果路径 / 🔁 可回滚`
3. 旧脚本**保留不动**（模块化洁癖），新能力另起文件（如 v1 `drone_agent.py` → v2 `drone_llm_agent.py`）
4. 关键坑同步 `SHARED_MEMORY.md`

## 七、迁移到 car / robot Agent（复用清单）
| 改什么 | 怎么改 |
|---|---|
| 物理模型 | 换 MJCF（轮式加关节、人形加肢体），PD 基元换成 `drive`/`walk` |
| 决策输出 | JSON 从 `waypoints` 换成 `actions`/`path`，prompt 示例同步改 |
| 其余全部 | 网关纪律、回退、校验、落卡、测试——**原样照抄** |

### 7.1 ✅ 已验证：car_agent 迁移（2026-09-13，任务卡 20260913_181500_1）
- 只改**两处**即跑通：物理层换差速运动学/MJCF，JSON 由 `waypoints` 改 `actions:[[v,omega,duration],...]`；其余（网关纪律、回退、同族前缀校验、离线测试、落卡）**零改动复用**
- 证据：`simulation_demo/car_agent/car_llm_agent.py`，测试 6/6 通过；lite 与 MuJoCo 双后端实跑轨迹同量级

### 7.2 轮式/地面体新增三坑（实测）
1. **接触摩擦是双方 geom 逐元素取 max**：MuJoCo 中只把底盘摩擦调低无效，**地面 plane 必须同设**，否则 μ=1.0 把车"焊死"（现象：xfrc 已生效但位移≈0、ncon=4）
2. **时间步与 DT 对齐**：模型 timestep=0.01 时，每个控制步需**子步循环 5 次**（5×0.01=0.05）对齐模块 DT，否则仿真时间与动作时长不符
3. **摩擦太低会打滑失真**：μ=0.05 时单动作漂移 13m（远超速度上限）；地球面标定值建议 μ=0.25 + 推力增益 120（质量 24kg）+ 偏航增益 60
- 诊断套路（两坑通用）：**裸跑 mj_step 打印 qpos/qvel/ncon 增量**，反推真实合力与接触数——比臆测快得多

### 7.4 ✅ 已验证：robot_agent 迁移（2026-09-14，任务卡 20260914_005300_1）
- **actions 契约三种载体零改动复用**（无人机 waypoints → 车/人形 actions `[[v,ω,时长]]`）→ 契约跨载体通用得证
- 证据：`simulation_demo/robot_agent/robot_llm_agent.py`，测试 6/6；lite 侧 LLM 决策层真实生效（网关返回 `deepseek-v4-flash-0731`）；MuJoCo 侧重心稳定 0.895（目标 0.9）

### 7.5 人形/腿足体三坑（实测）
1. **平衡控制器刚度过高 + 足地接触 → `QACC Nan/Inf` 失稳**（机器人被甩到 z=59m）：kp 由 400 降到 100，时间步细化到 0.005
2. **freejoint 无关节限位**：俯仰/横滚必须靠**姿态稳定 PD**（`tx=-kp*roll-kd*wx`）主动回正，否则一受扰就翻倒（实测重心掉到 0.366）
3. **腿足参与接触会与控制器持续耦合失稳** → 稳定版采用「平衡悬停抽象」：腿仅视觉（contype=0），重心由高度 PD 托举
- 平衡控制器最小实现：`fz = m*g + kp*(目标高度 - z) - kd*vz`，叠加姿态 PD 回正

### 7.3 已知局限（诚实标注）
- 轮式用 skid-steer 抽象（freejoint + xfrc，无真轮关节）→ 转向精度较运动学模型弱约 20%；高保真需加铰链关节 + 轮胎侧向摩擦
- 人形用**平衡悬停抽象**（无足地接触力学）→ 单动作位移偏小、无步态；高保真需真关节 + 步态相位控制
- **主验证路径建议：lite 运动学**（离线可回归、结果确定）；MuJoCo 后端用于验证「物理层可替换」，不作为精度基准
- 网关离线时 LLM 决策路径无证据，仅验证了回退路径（属预设行为，但不算 LLM 实测）

## 八、四化映射
- **标准化**：本 SKILL 为「仿真 Agent 接 LLM 决策层」唯一范式
- **模块化**：决策层/物理层/编排层三段可插拔（lite↔MuJoCo 一键切换）
- **自动化**：`--backend`+回退机制使全链路可无人值守跑通
- **智能化**：LLM 自主把自然语言任务解析为结构化动作计划

*来源：AI具身智能赛道 T003-v2 实测萃取（2026-09-10 开发 / 2026-09-13 沉淀）。零外部付费 API。*
