---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_3593794e931a11f1bcfc525400e6dd8f
    ReservedCode1: S90XbmpS/f5Oh0A5qJ0IVAk4/5TR/Ghh8IqWu/YZKs/9JpHX/cgXcjcgEvogowYAHLqrEv/X58+vJwYL2w4BVlK4OMLi1otpyzxr/WOANnRaobYbXoRuu9hWClbbSAElpydDV5YCisng9dOAYfWLi+uykTzyC1PGP7NBWsGijBDkVaRGguk0/PUX1EQ=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_3593794e931a11f1bcfc525400e6dd8f
    ReservedCode2: S90XbmpS/f5Oh0A5qJ0IVAk4/5TR/Ghh8IqWu/YZKs/9JpHX/cgXcjcgEvogowYAHLqrEv/X58+vJwYL2w4BVlK4OMLi1otpyzxr/WOANnRaobYbXoRuu9hWClbbSAElpydDV5YCisng9dOAYfWLi+uykTzyC1PGP7NBWsGijBDkVaRGguk0/PUX1EQ=
---



# 自我学习记录（SelfLearn Record）

> 系统自主学习过程的完整记录。
> 每一条学习都是：AgentReach采集 → 赛博书屋洗练 → 仓颉蒸馏 → 技能入库。

---

## 学习条目

### 2026-08-08 | gh CLI 认证流程

- **来源**：GitHub 官方文档 + 社区踩坑
- **方法**：AgentReach 全网搜索 "gh auth login Windows headless" → 赛博书屋提取关键步骤 → 仓颉蒸馏为 gh_auth_helper.bat
- **关键发现**：
  - `gh auth login --with-token` 支持管道输入，头部环境变量方案
  - Token 需要 `repo`, `workflow`, `read:org` 权限
  - SSO 授权需要在 Token 设置页面单独操作
- **踩坑**：
  - `Bad credentials` → Token 过期或权限不足
  - `gh auth status` 返回 "not logged in" 但 Token 已设置 → 检查 `~/.config/gh/hosts.yml`
- **产出**：`orca/self-evolve/gh_auth_helper.bat`

### 2026-08-08 | Windows schtasks 定时任务

- **来源**：Microsoft 官方文档 + 社区最佳实践
- **方法**：自学 schtasks /create 参数体系，结合 cnb_sync.bat 已有逻辑
- **关键发现**：
  - `/sc minute /mo 30` 最短间隔 30 分钟（非 1 分钟）
  - `/rl HIGHEST` 需要管理员权限执行
  - robocopy `/MIR` 会删除目标多余文件，需确认路径正确
- **踩坑**：
  - schtasks 路径含空格需加引号
  - robocopy 返回码 >=8 为错误
- **产出**：`orca/self-evolve/g_drive_sync.bat`

### 2026-08-08 | Cookie 持久化方案

- **来源**：爬虫社区 + 安全最佳实践
- **方法**：研究浏览器 Cookie 存储格式 → 设计加密索引方案
- **关键发现**：
  - 小红书 Cookie 有效期通常 7-30 天
  - 抖音 Cookie 有效期与设备指纹绑定
  - AES-256-GCM 为推荐加密方案
- **踩坑**：
  - `LOBSTER_ENC_KEY` 未设置时降级为 hash 索引（不存明文）
  - 频率控制必须在调用方做，而非 Cookie 层
- **产出**：`orca/self-evolve/cookie_injector.py`

### 2026-08-08 | 一键自我进化全链路设计

- **来源**：龙虾五步法 + 仓颉蒸馏 + 赛博书屋整合
- **方法**：将 AgentReach → 赛博书屋 → 仓颉 → 全域模板 抽象为可复用的四阶段管道
- **关键发现**：
  - 四阶段（炼精化气→炼气化神→炼神还虚→炼虚合道）天然映射到采集→洗练→蒸馏→注册
  - 阶段间产物独立可检，支持断点续跑
  - 技能注册需同时修改「技能生态系统·软链接注册表」和「触发关键词映射」
- **产出**：`orca/self-evolve/self_evolve.py`

---

## 学习方法论

| 环节 | 工具 | 说明 |
|------|------|------|
| 搜 | AgentReach | GitHub/B站/知乎/小红书/抖音/通用网页 六源并行 |
| 洗 | 赛博书屋 | Marius 统一解析，产出知识卡片 |
| 蒸 | 仓颉 | RIA-TV++ 五阶段蒸馏，产出 SKILL.md |
| 合 | 龙虾五步法 | 注册到技能生态 + 触发词映射 + 全域模板 |

## 已积累知识点

- [x] GitHub CLI 无头认证
- [x] Windows schtasks 定时任务
- [x] 爬虫 Cookie 持久化/加密/降级
- [x] robocopy 三端同步
- [x] 自我进化管道抽象
*（内容由AI生成，仅供参考）*
