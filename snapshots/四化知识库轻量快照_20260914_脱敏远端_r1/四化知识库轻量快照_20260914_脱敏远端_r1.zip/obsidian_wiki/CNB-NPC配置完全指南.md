# CNB NPC 配置完全指南

## NPC 体系架构

CNB 平台 NPC 分为四类：

| 类型 | 示例 | 配置方式 | 费用 |
|------|------|----------|------|
| 系统 NPC | @CodeBuddy | 零配置，全局可用 | 免费 |
| 仓库默认 NPC | @codex（自定义） | `.cnb/settings.yml` | 免费 |
| 社区 NPC | @npc/open-code、@npc/DeepSeek-TUI | star 仓库即可 | 免费 |
| 自定义 NPC | 自己创建的角色 | `.cnb/settings.yml` + `.cnb.yml` | 免费 |

## 为什么之前 @npc/codex 和 @npc/claude-code 不响应

**它们不是 CNB 系统 NPC！** 教程中提到的 @npc/codex 和 @npc/claude-code 是示例角色名，需要在仓库中自行创建。未创建时 NPC 不存在，自然无响应。

## 社区已有免费 NPC（直接可用）

| NPC | 用途 |
|-----|------|
| @npc/open-code | OpenCode 编码助手 |
| @npc/DeepSeek-TUI | DeepSeek 终端交互 |
| @npc/mtga | 以鹅传鹅（通用NPC） |
| @npc/pai | π（随机调用其他NPC） |
| @npc/eee | 鹅鹅鹅（开发中） |
| @Bring/AGI/OpenClaw | 通用智能体 |

使用方式：在 CNB 任意仓库搜索对应 NPC 仓库 → 点星标 → 在 Issue 中 @npc/open-code 即可调用。

## 自定义 NPC 两步配置法（零成本）

### 第一步：创建 `.cnb/settings.yml`

```yaml
npc:
  roles:
    - name: codex
      prompt: |
        # 角色定义
        你是 Codex，代码工程师。
        ## 核心能力
        - Python 脚本编写
        - 代码审查
```

### 第二步：创建 `.cnb.yml`

```yaml
.npc_task: &npc_task
  stages:
    - name: npc respond

codex:
  issue.comment@npc: *npc_task
  pull_request.comment@npc: *npc_task
```

不指定 image 时，CNB 自动使用免费默认镜像 `default-npc-agent`。

### 第三步：推送并验证

```bash
git add .cnb/settings.yml .cnb.yml
git commit -m "feat: 配置 codex 和 claude-code NPC"
git push
```

然后在 Issue 评论中 @codex 或 @claude-code 即可触发。

## 五大仓库 NPC 配置状态

| 仓库 | NPC | 状态 |
|------|-----|------|
| orca-jiedan | @codex、@claude-code | ✅ 已配置 |
| orca-wangpan | @codex、@claude-code | ⏳ 待配置 |
| orca-xianyu | @codex、@claude-code | ⏳ 待配置 |
| orca-quant-jiasheng | @codex、@claude-code | ⏳ 待配置 |
| orca-quant-binance | @codex、@claude-code | ⏳ 待配置 |

## 记录时间
2026-08-06

---
*来源：https://cnb.cool/set/npc-playground 官方文档*
