---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_11c6ae398ff411f1bec3525400826444
    ReservedCode1: Bh/4scSgrdlEzL9DwNlUn10bQ6HKOUp1qyCH2POCQOoFz3HC8qtHwZrOli3rjJX9FIivB7bgFPGbq9JoaymtJ5Om2IHvfWDYTEY9N7LLdVEnR5NxbE+uvSy8DoGcoV84g/UwR12PCNez75YrP9MlxS4poeNJOq/VoKiTdS4KCAfzlaYW3sB7Av/CZ+A=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_11c6ae398ff411f1bec3525400826444
    ReservedCode2: Bh/4scSgrdlEzL9DwNlUn10bQ6HKOUp1qyCH2POCQOoFz3HC8qtHwZrOli3rjJX9FIivB7bgFPGbq9JoaymtJ5Om2IHvfWDYTEY9N7LLdVEnR5NxbE+uvSy8DoGcoV84g/UwR12PCNez75YrP9MlxS4poeNJOq/VoKiTdS4KCAfzlaYW3sB7Av/CZ+A=
---

# Orca 多智能体舰队调度编排方案 v1.0

> 调度者：Marvis | 模型：MIMO V2.5 Pro | 日期：2026-08-04
> 零积分·零成本 | 龙虾五步法 V3.0 四化版

---

## 一、架构总览

```
┌─────────────────────────────────────────────────────────┐
│                    Marvis（调度层）                        │
│  意图识别 → 任务拆解 → Agent派发 → 结果汇总 → 四化沉淀     │
└──────┬──────────────┬──────────────┬────────────────────┘
       │              │              │
       ▼              ▼              ▼
┌──────────┐  ┌──────────┐  ┌──────────────┐
│ Hermes   │  │  Codex   │  │ Claude Code  │
│ 大脑层   │→│ 执行层   │→│  审核层       │
│ 9120/8642│  │ 57319/21 │  │  CLI v2.1.211│
└──────────┘  └──────────┘  └──────────────┘
       ▲                                    │
       └────────── 反馈迭代 ────────────────┘
```

## 二、三层工作流

### Phase 1: Hermes 大脑层（规划）
- 输入：用户终极目标
- 输出：任务拆解方案、执行步骤、风险预判
- 接入方式：
  - **桌面版**：`hermes.exe desktop` → PID 52672/71100（已启动）
  - **可莉 CLI**：CCGUI opencodeEnabled=true → model "opencode/mimo-v2.5-free"

### Phase 2: Codex 执行层（编码）
- 输入：Hermes 输出的执行方案
- 输出：代码实现、配置文件、测试用例
- 接入方式：
  - **桌面版**：Codex CLI `I:\npm\codex.cmd` → `C:\Users\Administrator\AppData\Local\OpenAI\Codex\bin\3f4fb8cdd344abc7\codex.exe`
  - **可莉 CLI**：CCGUI codexBin 已绑定（settings.json 修复）

### Phase 3: Claude Code 审核层（审查）
- 输入：Codex 产出的代码
- 输出：审核意见、优化建议、质量报告
- 接入方式：
  - **桌面版**：`E:\龙虾AI主控中心\我的AI分身\ClaudeCode\AnthropicClaude\claude.exe` v1.8555.0
  - **可莉 CLI**：CCGUI claudeBin 已绑定 `I:\npm\claude.cmd` → v2.1.211

## 三、端口矩阵（修复后）

| 端口 | 组件 | 状态 | 用途 |
|------|------|------|------|
| 15721 | MIMO V2.5 Pro | 🟢 LISTENING | Anthropic→MIMO协议转换，`/v1/messages` 200 OK |
| 15730 | Codex Tool Proxy | 🟢 LISTENING | Codex工具代理，cc-switch守护 |
| 8642 | Hermes Gateway | 🟢 LISTENING | Hermes WebSocket网关 |
| 9120 | Hermes TUI | ⬜ 按需 | GUI层，通过desktop子命令间接访问 |
| 11434 | Ollama DS | ⬜ 未安装 | 可用DeepSeek官方API替代（零本地占用） |

**MIMO V2.5 Pro 测试结果**：
```bash
curl http://localhost:15721/v1/messages → 200 OK
✅ 模型可用至 2026-08-14
```

## 四、Git 双实例工作区

```
G:\Orca\projects\
├── config/                  (main, fc51ec1) - 配置管理
├── gstack/                  (main, 675717e) - 通用技术栈
├── cangjie-skill/           (main, 55e4b70) - 知识蒸馏技能
├── lobster_templates/       (非Git备份)    - 全域模板
└── README.md
```

**双实例接入方式**：

| 引擎 | 桌面版入口 | CLI/可莉入口 | Git仓库 |
|------|-----------|-------------|---------|
| Hermes | `hermes.exe desktop` | CCGUI opencodeEnabled | `G:\Orca\projects\*` |
| Codex | Codex Desktop GUI | `I:\npm\codex.cmd` | `G:\Orca\projects\*` |
| Claude Code | Claude Desktop v1.8555.0 | `I:\npm\claude.cmd` | `G:\Orca\projects\*` |

## 五、Marvis 调度规则

### 5.1 路线选择

```
用户指令
  ├─ 文件/文档/Git → file-agent
  ├─ 系统/端口/进程 → computer-agent
  ├─ App启动/桌面版 → app-agent
  ├─ 网页/浏览 → browser
  └─ 深度研究 → search-agent
```

### 5.2 编排流程

1. **Marvis 接收目标** → Step1 炼精化气（意图识别）
2. **Marvis 拆解为子任务** → Step2 炼气化神（能力映射）
3. **Marvis 并行派发** → file-agent + computer-agent + app-agent
4. **结果汇聚** → Marvis 整合输出
5. **四化沉淀** → 写入 Obsidian 知识库

### 5.3 零成本约束

| 资源 | 方案 | 费用 |
|------|------|------|
| MIMO V2.5 Pro | 本地代理 15721 | 免费至 2026-08-14 |
| DeepSeek | 官方 API + CNB 云原生 | $5 额度 + 免费至 2026-12 |
| Codex CLI | 本地可执行文件 | 免费 |
| Claude Code | 本地 CLI v2.1.211 | 免费（npx绕区域限制） |
| 文件/系统操作 | Marvis 内置工具 | 零成本 |

## 六、一键命令速查

| 命令 | 效果 |
|------|------|
| `python anthropic_proxy_15721.py` | 启动 MIMO 15721 |
| `python codex_tool_proxy.py` | 启动 Codex 代理 15730 |
| `hermes.exe desktop` | 启动 Hermes 桌面版 |
| `hermes.exe gateway` | 启动 Hermes Gateway 8642 |
| `I:\npm\codex.cmd` | Codex CLI |
| `I:\npm\claude.cmd` | Claude Code CLI |

---

**文档生成**：Marvis 调度编排 | 龙虾五步法 V3.0 四化版
**版本控制**：v1.0 | 2026-08-04
*（内容由AI生成，仅供参考）*
