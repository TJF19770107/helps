---
title: 汤小龙宿主MCP技能继承清单
date: 2026-08-31
category: capability-index
source: local-scan
status: active
sensitivity: internal
---

# 汤小龙 · 宿主MCP技能继承清单

> 自动生成：2026-08-31 00:08:57（零积分纯本地扫描）
> 用途：启动汤小龙时自动刷新；汤小龙可依据本清单直接调用宿主全部 MCP/插件/技能。

## 配置文件：`C:\Users\Administrator/.codex/config.toml`

- MCP 服务器（27 个）：memory、sequential-thinking、time、context7、brave-search、desktop-automation、doubao-proxy、filesystem、github、hermes-agent、lobster-claude、lobster-codex、lobster-codex-claude-bridge、lobster-netdisk-search、memos、ollama-local、openclaw-gateway、playwright、postgres、vibe-trading、wechat-video-browser、xiaohongshu-browser、lobster-hermes-mcp-server、lobster-hermes-to-claude、lobster-hermes-to-codex、fetch、node_repl
- 插件（0 个）：（无）

## 配置文件：`C:\Users\Administrator/.codex-orch/config.toml`

- MCP 服务器（27 个）：memory、sequential-thinking、time、context7、brave-search、desktop-automation、doubao-proxy、filesystem、github、hermes-agent、lobster-claude、lobster-codex、lobster-codex-claude-bridge、lobster-netdisk-search、memos、ollama-local、openclaw-gateway、playwright、postgres、vibe-trading、wechat-video-browser、xiaohongshu-browser、lobster-hermes-mcp-server、lobster-hermes-to-claude、lobster-hermes-to-codex、fetch、node_repl
- 插件（4 个）：browser@openai-bundled、canva@openai-curated、figma@openai-curated、github@openai-curated

## 配置文件：`C:\Users\Administrator/.codex-hermes/config.toml`

- MCP 服务器（27 个）：memory、sequential-thinking、time、context7、brave-search、desktop-automation、doubao-proxy、filesystem、github、hermes-agent、lobster-claude、lobster-codex、lobster-codex-claude-bridge、lobster-netdisk-search、memos、ollama-local、openclaw-gateway、playwright、postgres、vibe-trading、wechat-video-browser、xiaohongshu-browser、lobster-hermes-mcp-server、lobster-hermes-to-claude、lobster-hermes-to-codex、fetch、node_repl
- 插件（0 个）：（无）

## 技能目录扫描

- `C:\Users\Administrator/.codex/skills` → 95 个 SKILL.md
- `C:\Users\Administrator/.codex-orch/skills` → 1 个 SKILL.md
- `C:\Users\Administrator/.agents/skills` → 11 个 SKILL.md
- `G:\WorkBuddy_Data\skills` → 59 个 SKILL.md
- `C:\Users\Administrator/.claude/skills` → 25 个 SKILL.md
- `C:\Users\Administrator\.marvis\skills\market` → 119 个 SKILL.md
- `C:\Users\Administrator\.marvis\skills\custom` → 0 个 SKILL.md
- `C:\Users\Administrator\.openclaw\skills` → 23 个 SKILL.md

**MCP 合计（去重）：27 个 ｜ 技能合计：333 个**

## Claude Code 宿主继承：`C:\Users\Administrator/.claude.json`

- MCP（32 个）：doubao-proxy、node_repl、4fe2f8e5-4a8d-4545-85e0-a63e3844641b、lobster-hermes-mcp-server、lobster-hermes-to-claude、87c1f46b-b75d-4574-b6e6-500beee38f8d、github、memos、lobster-netdisk-search、fetch、brave-search、lobster-codex、vibe-trading、bd9afc79-668c-4f80-a23f-c098ce96e518、postgres、lobster-hermes-to-codex、hermes-agent、wechat-video-browser、desktop-automation、context7、time、sequential-thinking、4d10506c-e670-4db6-9a0c-6bb06ff090ae、lobster-claude、3bacabfd-cc63-4a40-970d-a7f3fdd57439、openclaw-gateway、ollama-local、lobster-codex-claude-bridge、memory、xiaohongshu-browser、filesystem、playwright
- 其中 doubao-proxy（端口 18000）= 豆包宿主能力桥接通道，豆包的对话/文档/抓取能力经此 MCP 被汤小龙继承

## WorkBuddy 宿主继承

- WorkBuddy 即本桌面 Codex 宿主：`~/.codex-orch/config.toml` 的 MCP + plugins 即 WorkBuddy 原生能力，已并入上方扫描
- WorkBuddy 技能库 `G:\WorkBuddy_Data\skills` 已并入上方技能目录扫描

## 动态继承机制

- 每次启动汤小龙自动刷新本清单；另有计划任务 Lobster_AvatarCapabilitySync 定时刷新，实现动态继承

## 追加宿主继承（Marvis / OpenClaw / OpenCodex / DeepSeek Harness）

- **Marvis**（`C:\Users\Administrator\.marvis`）：MCP 配置 8 个（cc_switch_import、import_1_brave、import_2_netdisk、import_3_xiaohongshu、import_4_wechat_video、import_5_desktop_automation、import_report、mcp_servers_all）；skills/market + custom 已并入上方技能扫描
- **OpenClaw**（`C:\Users\Administrator\.openclaw\openclaw.json`）：大脑提供方 2 个（freellmapi、ollama）；skills 23 个已并入技能扫描
- **OpenCodex**（`C:\Users\Administrator/.codex-orch/opencodex.config.toml`）：Codex 运行时提供方/模型目录已登记，接入 18091 免费通道
- **DeepSeek Harness**：提供方配置映射表位于 `docs\DeepSeekHarness_Provider配置界面字段一一对应映射表_20260818.md`，免费大脑 deepseek-v4-flash-free（CNB/TeamoRouter）已作为汤小龙默认推理层接入

## 运行时挂载注册（by-host → 汤小龙技能注册表）

- `agents`：注册 11 个技能（源：E:\龙虾AI主控中心\我的AI分身\技能库\by-host\agents）
- `claude`：注册 25 个技能（源：E:\龙虾AI主控中心\我的AI分身\技能库\by-host\claude）
- `codex`：注册 95 个技能（源：E:\龙虾AI主控中心\我的AI分身\技能库\by-host\codex）
- `marvis`：注册 119 个技能（源：E:\龙虾AI主控中心\我的AI分身\技能库\by-host\marvis）
- `openclaw`：注册 23 个技能（源：E:\龙虾AI主控中心\我的AI分身\技能库\by-host\openclaw）
- `workbuddy`：注册 59 个技能（源：E:\龙虾AI主控中心\我的AI分身\技能库\by-host\workbuddy）
**运行时注册技能合计：332 个 → `技能注册表.json`（启动汤小龙时加载）**
