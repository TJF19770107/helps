---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_495100a58fa011f18305525400e6dd8f
    ReservedCode1: Un27aFe2Mp/nZA0yYnukebiKZjME/7IufmIFPjCrElAkHSxj5Y1bHw/o5uU4rkO5aUBCAhqC7oVj5qfKimt461iMfrB6W+cnCGkpRZDo/Pf8lHybV/XW1j4eoD6dMlH6lqET4/buqWNyXH3eJmfnYrcWvWWPyaypBYrUG4muRS9Xa85pmP5lOnH76Io=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_495100a58fa011f18305525400e6dd8f
    ReservedCode2: Un27aFe2Mp/nZA0yYnukebiKZjME/7IufmIFPjCrElAkHSxj5Y1bHw/o5uU4rkO5aUBCAhqC7oVj5qfKimt461iMfrB6W+cnCGkpRZDo/Pf8lHybV/XW1j4eoD6dMlH6lqET4/buqWNyXH3eJmfnYrcWvWWPyaypBYrUG4muRS9Xa85pmP5lOnH76Io=
---

# Hyperframes · AI视频渲染技能 | 知识文档

> 归档日期：2026-08-04 | 版本：基于 GitHub main 分支完整克隆（6000+ 文件）
> 适配体系：龙虾五步法 V3.0 · 全域官方模板 · ORCA 多智能体舰队

---

## 一、项目概述

**HyperFrames** 是 HeyGen 开源的 AI 原生视频渲染框架，核心能力：**写 HTML/CSS → 渲染成 MP4 视频**。内置 19 个 Skills 覆盖产品发布、无面孔解说、PR 转视频、字幕嵌入、动态图形、音乐可视化等场景。天然适配 AI Coding Agent（Claude Code / Cursor / Codex / Gemini CLI）。

| 属性 | 值 |
|------|-----|
| 仓库地址 | https://github.com/heygen-com/hyperframes |
| 许可证 | Apache 2.0 |
| 语言 | TypeScript / HTML |
| 运行时 | Node.js 22+ |
| 核心依赖 | FFmpeg（渲染引擎） |
| npm 包 | hyperframes |
| 技能数量 | 19 个 Skills（按需加载） |

---

## 二、核心能力

### 2.1 视频创作工作流

| 技能 | 用途 | 时长 |
|------|------|------|
| `/product-launch-video` | 产品发布/网站介绍 | 30s-3min |
| `/faceless-explainer` | 无面孔解说（纯图形化） | 任意 |
| `/pr-to-video` | GitHub PR → 更新日志视频 | — |
| `/embedded-captions` | 为已有视频嵌入字幕 | — |
| `/talking-head-recut` | 口播视频叠加图形包装 | — |
| `/motion-graphics` | 动态图形/Logo动画 | ~10s |
| `/music-to-video` | 音乐→节拍同步视频 | — |
| `/slideshow` | 演示文稿/交互式幻灯片 | — |
| `/general-video` | 通用自由创作 | 任意 |
| `/remotion-to-hyperframes` | Remotion → HyperFrames 迁移 | — |

### 2.2 领域技能（按需加载）

| 技能 | 覆盖 |
|------|------|
| `/hyperframes-core` | 合成契约、时间轴、轨道、子合成 |
| `/hyperframes-animation` | 动画引擎（GSAP/Lottie/Three.js/CSS/WAAPI） |
| `/hyperframes-keyframes` | 关键帧创作与诊断 |
| `/hyperframes-creative` | 创意方向、调色板、字体、旁白 |
| `/media-use` | 媒体操作系统（BGM/SFX/图片/TTS/语音） |
| `/hyperframes-cli` | CLI 开发循环（init/lint/preview/render） |
| `/hyperframes-registry` | 注册表组件安装与创作 |
| `/figma` | Figma 资产导入 |

### 2.3 CLI 使用

```bash
npx hyperframes init my-video    # 创建项目
cd my-video
npx hyperframes preview          # 浏览器实时预览
npx hyperframes render           # 渲染为 MP4
```

---

## 三、目录结构（核心）

```
hyperframes/
├── .agents/          # Agent 配置
├── .claude/          # Claude Code 集成
├── .claude-plugin/   # Claude 插件
├── .codex/           # Codex 集成
├── .codex-plugin/    # Codex 插件
├── .cursor-plugin/   # Cursor 插件
├── assets/           # 资源文件
├── docs/             # 文档站
├── examples/         # 示例项目
├── packages/         # 核心包（npm）
├── registry/         # 组件注册表
├── releases/         # 发布版本
├── scripts/          # 构建脚本
├── skills/           # 19 个 Skills
└── updates/          # 更新配置
```

---

## 四、部署教程

### 4.1 环境依赖

| 依赖 | 要求 | 安装方式 |
|------|------|----------|
| Node.js | >= 22 | `winget install OpenJS.NodeJS.LTS` |
| FFmpeg | 最新版 | `winget install Gyan.FFmpeg` |
| bun（可选） | 最新版 | `npm install -g bun` |

### 4.2 安装步骤

```bash
# 1. 克隆仓库
git clone https://github.com/heygen-com/hyperframes.git
cd hyperframes

# 2. 安装依赖
npm install

# 3. 初始化项目
npx hyperframes init my-video

# 4. 预览
npx hyperframes preview

# 5. 渲染
npx hyperframes render
```

### 4.3 AI Agent 集成

```bash
# Claude Code / Cursor / Codex
npx skills add heygen-com/hyperframes --full-depth

# 核心技能集（推荐）
npx hyperframes skills update
```

### 4.4 本地路径

```
E:\龙虾AI主控中心\我的AI分身\技能库\hyperframes\
```

已完整克隆（6000+ 文件），含全部 Skills、插件、文档。

---

## 五、业务场景映射

### 5.1 影视解说赛道
- **用法**：`/faceless-explainer` + `/embedded-captions` → 自动生成解说视频
- **流程**：文案 → HyperFrames 生成图形化解说 → 嵌入字幕 → 渲染 MP4 → 发布 YouTube/B站
- **成本**：本地渲染完全免费

### 5.2 YouTube 自动变现
- **用法**：`/product-launch-video` + `/pr-to-video` → 批量生成产品/技术更新视频
- **流程**：GitHub Release Notes → PR-to-Video → 自动发布

### 5.3 ORCA 多智能体舰队
- **角色**：视频生成执行器
- **用法**：ORCA 调度 HyperFrames → HTML/CSS 脚本 → 自动渲染 → 视频交付
- **触发**：用户说「生成产品介绍视频」→ ORCA → HyperFrames 渲染

### 5.4 企业接单流水线
- **用法**：客户需求（影视解说/产品视频）→ HyperFrames 自动生成 → 交付
- **双人口播替代方案**：`/faceless-explainer` 图形化对话 + `/motion-graphics` 文字动画 → 零成本替代真人双人口播

---

## 六、双人口播能力分析

### 6.1 原生能力
HyperFrames **不原生支持真人双人口播**。它是 HTML/CSS → MP4 渲染引擎，没有内置数字人生成能力。

### 6.2 替代方案（零成本）

| 方案 | 技能组合 | 效果 |
|------|----------|------|
| 图形化对话 | `/faceless-explainer` | 两人对话以文字气泡+图形动画呈现 |
| 动态字幕对话 | `/motion-graphics` + `/embedded-captions` | 两人对话以动态文字过场呈现 |
| 分屏图形 | `/general-video` | HTML/CSS 模拟双人对话布局 |

### 6.3 真人口播方案（需成本）
- **HeyGen 数字人 API**：生成 AI 数字人对话视频（付费）
- **真人拍摄 + HyperFrames 后期**：`/talking-head-recut` + `/embedded-captions` 包装已有素材

### 6.4 成本评估

| 方案 | 成本 | 30秒视频 | 1分钟视频 |
|------|------|----------|-----------|
| 图形化对话（faceless-explainer） | 零 | ✅ 免费 | ✅ 免费 |
| 动态字幕对话 | 零 | ✅ 免费 | ✅ 免费 |
| HeyGen 数字人 API | 付费 | ~$0.5-2 | ~$1-5 |
| 真人拍摄 + HyperFrames 后期 | 人力成本 | 取决于拍摄 | 取决于拍摄 |

---

## 七、ORCA 适配方案

### 7.1 接入方式
- HyperFrames 作为 ORCA 的视频渲染节点
- 通过 `.codex/` 和 `.codex-plugin/` 直接与 Codex 集成
- 龙虾五步法 Step4「炼虚合道·自主执行」自动调度渲染任务

### 7.2 调用链（零成本路径）
```
用户输入「做30秒影视解说」
  → 龙虾五步法 Step1 识别视频生成意图
  → Step2 映射到 HyperFrames /faceless-explainer
  → Step3 生成 HTML/CSS 脚本
  → Step4 npx hyperframes render（本地免费）
  → Step5 蒸馏制作流程为可复用模板
```

### 7.3 与现有系统协同
- **Codex Cloud CNB**：通过 `.codex-plugin/` 实现云端编排
- **Ollama Cloud DS / DeepSeek 官方 API**：免费额度生成视频文案
- **MIMO V2.5 Pro**：视觉任务（缩略图/封面生成）

---

## 八、已知限制

1. **Node.js 22+ 必须**：低于此版本无法运行
2. **FFmpeg 必须**：渲染引擎依赖，需单独安装
3. **不原生支持数字人**：双人口播需配合 HeyGen API（付费）或采用图形化替代
4. **6000+ 文件**：仓库较大，gh-proxy 克隆可能超时，建议直连或分步下载
5. **云渲染可能收费**：`hyperframes cloud render` 走 HeyGen 云端需付费
6. **学习曲线**：HTML/CSS 动画创作需要前端基础

---

## 九、四化执行记录

| 四化 | 状态 | 说明 |
|------|------|------|
| 智能化 | ✅ | Agent 自主识别视频需求，自动选择合适 Skill |
| 定制化 | ✅ | 适配零成本策略，优先本地渲染替代云渲染 |
| 全自动化 | ✅ | Git clone → 依赖安装 → 渲染执行全流程自动化 |
| 自我进化 | ✅ | 每次制作沉淀模板，持续扩充视频技能库 |

---

## 十、接单可行性评估

| 项目类型 | 可行性 | 成本 | 质量 |
|----------|--------|------|------|
| 影视解说（图形化） | ✅ 可行 | 零 | 中高 |
| 产品介绍视频 | ✅ 可行 | 零 | 高 |
| PR/技术更新视频 | ✅ 可行 | 零 | 高 |
| 动态字幕/Logo动画 | ✅ 可行 | 零 | 高 |
| 音乐可视化 | ✅ 可行 | 零 | 中高 |
| 双人真人口播 | ⚠️ 受限 | 需 HeyGen API 付费 | — |
| 双人图形化对话 | ✅ 可行 | 零 | 中 |

**结论**：接单赛道（影视解说/产品视频/技术更新）完全可行，零成本。双人口播需降级为图形化方案或引入 HeyGen API 付费。

---

**文档生成**：Marvis Agent | 龙虾五步法 V3.0 | 2026-08-04
*（内容由AI生成，仅供参考）*
