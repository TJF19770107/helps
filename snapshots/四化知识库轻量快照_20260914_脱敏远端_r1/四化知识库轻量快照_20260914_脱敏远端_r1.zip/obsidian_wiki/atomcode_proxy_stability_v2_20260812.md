# AtomCode代理持续稳定调用保障方案 V2.0 · 2026-08-12

> **来源**：企业微信群定制接单项目故障复盘 | **分类**：系统自愈 · 稳定性保障 | **状态**：ACTIVE
> **方法**：龙虾五步法 V3.0 · 全域模板 · 四化迭代

## 为什么"老出错"（三大根因）

| 根因 | 表现 | V2.0 修复 |
|------|------|-----------|
| **单线程服务器阻塞** | 端口 LISTENING 但连接超时（一个 300s 请求卡死整个 13460） | `HTTPServer` → `ThreadingHTTPServer` 多线程并发 |
| **进程死亡无人拉起** | `Connection error`（一次性计划任务不自动恢复） | 守护脚本 + 每10分钟计划任务自愈 |
| **无快照无法回滚** | 改坏配置只能手修 | 轻量快照 <20M 一键回滚 |

## 保障体系

```
调用方 → atomcode_proxy.py(ThreadingHTTPServer, 13460)
              ├── 守护: guard_atomcode_proxy.py (每10min健康检查+拉起)
              └── 快照: make_snapshot.py (<20M zip + RESTORE 说明)
```

## 实测验证

| 验证项 | 结果 |
|--------|------|
| 守护自愈 | ✅ `restart SUCCESS, port 13460 open` |
| `/health` | ✅ `{"status":"ok"}` |
| chat/completions | ✅ `"OK"` |
| responses 非流式/流式 | ✅ object:response / 9事件+[DONE] |
| 快照体积 | ✅ 0.03 MB < 20 MB |

## SOP 速记

1. `netstat -ano | findstr 13460` 无 LISTENING = 代理死 → `schtasks /run /tn "AtomCodeProxyGuard"`
2. 有 LISTENING 但 curl 超时 = 单线程阻塞（V2.0 已修复）
3. 回滚：`E:\龙虾AI主控中心\我的AI分身\AtomCode\snapshots\` 最新 zip + RESTORE 说明
4. 约束：守护任务不可删；用 hermes venv 完整 Python 启动；不用 Git Bash nohup

## 四化校准

| 维度 | 状态 | 说明 |
|------|------|------|
| 智能化 | ✅ | 守护脚本自主探测+拉起 |
| 定制化 | ✅ | 针对三大根因定制 |
| 全自动化 | ✅ | 10min自愈 + 快照一键生成 |
| 自我进化 | ✅ | SOP v2.0 沉淀至技能库+Obsidian+脚手架 |

## 关联

- [[codex_ccswitch_atomcode_404_fix_20260812]]
- [[codex_ccswitch_atomcode_fix|技能库完整SOP]]
- [[CNB-DeepSeek-V4-Flash-0731]]
