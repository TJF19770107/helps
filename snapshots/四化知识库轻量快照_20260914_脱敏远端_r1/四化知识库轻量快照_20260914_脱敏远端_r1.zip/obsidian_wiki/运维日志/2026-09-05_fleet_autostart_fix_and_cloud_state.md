# 香港云服务器状态核实与 Firecrawl 僵尸容器清理（2026-09-05）

> 执行身份：汤小龙（AI 分身）
> 触发：汤哥担心"下载 firecrawl 后云电脑就用不了了"
> 核实方式：SSH 直连 `root@43.161.202.206`（密钥 `C:\Users\Administrator\.ssh\id_ed25519`）

---

## 一、核实结论：云电脑没坏

| 指标 | 清理前 | 清理后 |
|------|--------|--------|
| 内存总量 | 3.6Gi | 3.6Gi |
| 已用 | 1.4Gi | 948Mi |
| 可用 | 2.2Gi | 2.6Gi |
| 运行容器 | frps + 4×firecrawl-lightweight | **仅 frps** |
| 轻量爬虫(lobster-crawler) | active | active（不受影响） |

## 二、用户误判的根源

之前某次子 agent 在部署探索时，把 `firecrawl-lightweight` docker 栈拉起来了：
- 跑起来 4 个：`redis` / `rabbitmq` / `nuq-postgres` / `playwright-service`
- **核心 `api` 容器没起来** —— 在 3.6G 内存下被 OOM 干掉（正好印证 9/4 的降级结论）

所以那堆 Firecrawl 容器是**半死不活、零功能、还占内存**的僵尸。用户"感觉变了"就是它们，不是云坏了。

## 三、已执行的清理

```bash
docker stop firecrawl-lightweight-redis-1 firecrawl-lightweight-rabbitmq-1 \
            firecrawl-lightweight-nuq-postgres-1 firecrawl-lightweight-playwright-service-1
docker rm   firecrawl-lightweight-redis-1 firecrawl-lightweight-rabbitmq-1 \
            firecrawl-lightweight-nuq-postgres-1 firecrawl-lightweight-playwright-service-1
```

> 可逆：`/root/firecrawl` 仓库仍在（232M），日后如需重来 `docker compose up` 即可。

## 四、零成本爬虫与 Firecrawl 的关系（澄清）

- **零成本云端轻量爬虫 ≠ Firecrawl**。它是自写的 FastAPI(httpx+bs4)，内存 <200MB。
- 本机 `lobster_crawl_client.py` 调的是 `http://127.0.0.1:3002`（云端自建 FastAPI），不是 Firecrawl API。
- 证据：`cloud_scrape()` 走 `CLOUD_CRAWLER` 变量，`local_scrape()` 走标准库直连，全程无 Firecrawl 依赖。

## 五、香港服务器到期的影响

| 能力 | 到期前（有云） | 到期后（无云） |
|------|---------------|---------------|
| 写 Obsidian | ✅ | ✅（本机） |
| B站 本机直连 | ✅ | ✅（本机） |
| 海外站(GitHub/YouTube) | 云端快/稳 | 回退 `local_scrape()` 本机直连（GitHub 国内可达；YouTube 国内直连可能慢/被墙，需本机代理） |
| frps 内网穿透 | ✅ | ❌（随服务器消失） |

**结论**：到期=降速但不失明，核心沉淀能力（Obsidian 联动）不受影响。

## 六、这云电脑还能做什么（2核/3.6G 限制内）

- ✅ 轻量 Python 服务（爬虫、定时任务、小 API）
- ✅ frps 内网穿透 / 反向隧道节点
- ✅ 海外代理转发节点（香港 IP 优势）
- ✅ 小静态站托管
- ❌ 重型 docker 栈（Firecrawl 全家桶、数据库集群等）

---

_本文件由汤小龙于 2026-09-05 生成，用于澄清云服务器状态与 Firecrawl 误判。_


---

## 四、LobsterFleet_AutoRestore 弹窗修复（2026-09-05 15:14）

### 4.1 现象
- Windows 弹窗："Windows 找不到文件 'Fleet-Auto-15730'。请确定文件名是否正确后，再试一次。"
- 伴随多个 `cmd.exe` 黑窗一闪而过

### 4.2 根因
- 计划任务 `LobsterFleet_AutoRestore` 在登录/每 6 小时运行 `E:\龙虾AI主控中心\MCP服务\lobster_fleet_autostart.bat`
- bat 内用 `start "" /MIN "%PY%" "%DIR%\%SCRIPT%"` 启动 Codex/TeamoRouter 代理
- 长路径 + 中文路径 + 计划任务环境下，`start` 命令解析歧义，导致"系统找不到指定的文件"，弹窗 3 次（对应 15730/18091/51427）
- 结果：代理都没启动，只有 15721 和 TeamoRouter 原本就在跑

### 4.3 修复
1. 备份原 bat：`backups_M001\lobster_fleet_autostart.bat.bak.20260905_151301`
2. 修改 `lobster_fleet_autostart.bat`：
   - 增加 `PYW` 指向 `pythonw.exe`（无窗口版）
   - 把 `start "" /MIN "%PY%" ...` 改为 `start "" /MIN "" "%PYW%" ...`
   - TeamoRouter GUI 启动也加 `/MIN ""` 显式空标题
3. 手动触发计划任务验证：`LastTaskResult = 0`，无弹窗
4. 端口验证：51427/18091/15730/15721 全部正常监听

### 4.4 以后维护
- 若再改此 bat，必须保留 `start "" /MIN ""` 语法，否则弹窗会复发
- 代理脚本路径含中文，推荐用 `pythonw.exe` + 显式空标题
