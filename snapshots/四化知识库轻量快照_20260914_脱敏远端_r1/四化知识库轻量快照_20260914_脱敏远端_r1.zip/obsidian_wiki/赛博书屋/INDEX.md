---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_5de7e6c590ea11f1a102525400826444
    ReservedCode1: 9Fcnl7vsnSQPrydeAg9YJe3zXZUzdJpufWSdgAdXgTxX9bd1sMvZuuajHFNHyrPkbVXSbfDu/tHefsqsWspcNCzKClMqT/F+KVtO8ck/b12WjvditAjg/4ig6Plx/XxVjmydnLDZc5ieRBwz8zl3G5FA7LUhXKHr+dxC2vv3HLBvCjaD5UGLYLqoGwA=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_5de7e6c590ea11f1a102525400826444
    ReservedCode2: 9Fcnl7vsnSQPrydeAg9YJe3zXZUzdJpufWSdgAdXgTxX9bd1sMvZuuajHFNHyrPkbVXSbfDu/tHefsqsWspcNCzKClMqT/F+KVtO8ck/b12WjvditAjg/4ig6Plx/XxVjmydnLDZc5ieRBwz8zl3G5FA7LUhXKHr+dxC2vv3HLBvCjaD5UGLYLqoGwA=
---



# 赛博书屋 知识库索引

> 更新：2026-08-05 | 赛博书屋 v1.5
> 知识库路径：E:\龙虾AI主控中心\Obsidian\wiki\赛博书屋\

---

## 学习笔记

### 视频号

| 序号 | 标题 | 作者 | 日期 |
|------|------|------|------|
| 1 | [[视频号-天锋教你玩Ai-Codex一键出剧智能体-2026-08-03]] | 天锋教你玩Ai | 2026-08-03 |
| 2 | [[视频号-雷厉AI观-赛博书屋Skill工作流-2026-08-05]] | 雷厉AI观 | 2026-08-05 |

### 公众号

（待收录）

### B站视频

（待收录）

### YouTube

（待收录）

### X/Twitter

（待收录）

---

## 统计

- 总笔记数：2
- 最后更新：2026-08-05
- 来源分布：视频号(2)

---

## 关联

- [[赛博书屋]] — 技能主页
- [[龙虾五步法V3.0]] — 所属框架
- [[仓颉Skill]] — 蒸馏引擎
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
