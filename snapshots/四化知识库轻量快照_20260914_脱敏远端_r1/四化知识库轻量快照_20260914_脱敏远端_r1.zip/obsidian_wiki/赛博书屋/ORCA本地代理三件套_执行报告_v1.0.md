---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_f89be337959d11f1b50c525400826444
    ReservedCode1: Y0kqEO9iTKaAFRsOspVUpV9HZqCLJ+EicArFg5Qxou8cnwMZKe6ITiymIjElW2iYAbulYd7CohyxCRbolLmbbRzMKroEmNk5AneJhM7thAbwsbebxfA/Wng7Ff25i2cqwGMwHoKIdX5LEZWTVGz9cyWApxeu6/GoO/WW+lpblFOLUoOMb8PlpTIPuPU=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_f89be337959d11f1b50c525400826444
    ReservedCode2: Y0kqEO9iTKaAFRsOspVUpV9HZqCLJ+EicArFg5Qxou8cnwMZKe6ITiymIjElW2iYAbulYd7CohyxCRbolLmbbRzMKroEmNk5AneJhM7thAbwsbebxfA/Wng7Ff25i2cqwGMwHoKIdX5LEZWTVGz9cyWApxeu6/GoO/WW+lpblFOLUoOMb8PlpTIPuPU=
---

# ORCA 本地代理三件套 · 执行报告

> 日期: 2026-08-11 | 版本: v1.0 | 五步法: 炼虚合道（Step4 执行完成）
> 标签: #ORCA #AtomCode #代理 #环境变量 #CNB

---

## 〇、任务总览

| 序号 | 任务 | 状态 | 关键产出 |
|------|------|------|----------|
| 1 | ORCA self_evolve.py → 本地代理 | ✅ 完成 | 系统环境变量 + ORCA配置 |
| 2 | CNB CloudDev 代理隧道 | ⛔ 阻塞 | CNB Token 过期，需重新登录 |
| 3 | 终端命令修正 + 四化迭代 | ✅ 完成 | PS脚本 + Obsidian沉淀 |

---

## 一、Task 1: ORCA → 本地代理（炼精化气 → 炼虚合道）

### 1.1 系统环境变量（User级，永久生效）

```powershell
DEEPSEEK_API_KEY  = atomcode-local
DEEPSEEK_BASE_URL = http://127.0.0.1:13460/v1
```

已通过 `[Environment]::SetEnvironmentVariable()` 写入注册表，所有新启动进程自动继承。

### 1.2 ORCA 配置文件更新

**文件**: `E:\龙虾AI主控中心\我的AI分身\ORCA\config\orca-config.json`

**变更**:
1. 新增 `atomcode-local` agent（优先级 0，指向本地代理 `http://127.0.0.1:13460/v1`）
2. `deepseek` agent 从 disabled→enabled，base_url 从 `api.deepseek.com` → 本地代理
3. `fallback_chain` 首位加入 `atomcode-local`

### 1.3 启动脚本更新

**文件**: `E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\launch_atomcode_v4.bat`

新增注入:
```batch
set "DEEPSEEK_BASE_URL=http://127.0.0.1:13460/v1"
set "DEEPSEEK_API_KEY=atomcode-local"
```

---

## 二、Task 2: CNB CloudDev 代理隧道（阻塞）

### 2.1 代理脚本已就绪

**文件**: `E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\cnb_proxy_clouddev.py`

- 监听 0.0.0.0:8080
- 读取容器内 `$CNB_TOKEN` 环境变量
- 透传请求到 `api.cnb.cool/{slug}/-/ai/chat/completions`
- 模型映射: deepseek-v4-flash / gpt-4o / claude 等 → deepseek-v4-flash

### 2.2 阻塞原因

| Token 来源 | 状态 |
|------------|------|
| `$env:CNB_TOKEN` (User) | 401 - 已过期 |
| `~/.cnb/token` (access_token) | 401 - 已过期 |
| `~/.cnb/token` (refresh_token) | 404 - 端点不存在 |
| AtomGit PAT | 401 - 未登录 |

### 2.3 解除阻塞

需要在终端执行 `cnb login` 重新认证，或提供有效的 `CNB_TOKEN`。

---

## 三、Task 3: 终端命令修正

### 3.1 问题诊断

截图中的命令 `set OPENAI_BASE_URL=... ; python atomcode_proxy.py 13460` 存在两个问题：

1. **语法错误**: `set` 是 CMD 语法，PowerShell 中无效。PowerShell 环境变量语法为 `$env:VAR = "value"`
2. **文件路径**: 未使用绝对路径，`python atomcode_proxy.py` 在非脚本目录下会报文件找不到

### 3.2 修正：PowerShell 一键启动脚本

**文件**: `E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\launch_atomcode_v4.ps1`

正确语法示例:
```powershell
$env:DEEPSEEK_BASE_URL = "http://127.0.0.1:13460/v1"
$env:DEEPSEEK_API_KEY = "atomcode-local"
python "E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\atomcode_proxy.py" 13460
```

### 3.3 CMD vs PowerShell 对照

| 操作 | CMD (.bat) | PowerShell (.ps1) |
|------|-----------|-------------------|
| 设置环境变量 | `set VAR=value` | `$env:VAR = "value"` |
| 调用 Python | `python script.py` | `python "script.py"` 或 `& python script.py` |
| 查找进程端口 | `netstat -ano \| findstr` | `Get-NetTCPConnection -LocalPort` |
| 结束进程 | `taskkill /PID` | `Stop-Process -Id` |

---

## 四、架构总览

```
┌─────────────────────────────────────────────┐
│              用户终端 (PowerShell)            │
│  launch_atomcode_v4.ps1                      │
│    ↓ 注入 $env:DEEPSEEK_* / OPENAI_* / ...   │
│    ↓ 启动 atomcode_proxy.py :13460           │
└──────────────┬──────────────────────────────┘
               │
    ┌──────────▼──────────┐
    │  AtomCode Proxy     │  127.0.0.1:13460
    │  atomcode_proxy.py  │
    │  → atomcode.exe     │  DeepSeek V4 Flash
    │  → CodingPlan Lite  │  免费额度
    └──────┬──────┬───────┘
           │      │
    ┌──────▼──┐ ┌─▼──────────┐
    │  ORCA   │ │ Hermes     │  Claude Code
    │ atomcode│ │ atomcode   │  CC-Switch
    │ -local  │ │ -v4-local  │
    │ agent   │ │ provider   │
    └─────────┘ └────────────┘
```

### CNB CloudDev 路径（待Token恢复）

```
本地客户端 → https://{sn}-8080.cnb.run/v1
              → cnb_proxy_clouddev.py (容器内 :8080)
              → api.cnb.cool/{slug}/-/ai/chat/completions
              → CNB 免费 DeepSeek V4
```

---

## 五、启动方式

### 方式 A: PowerShell 脚本（推荐）

```powershell
& "E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\launch_atomcode_v4.ps1"
```

若遇到执行策略限制，先执行:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### 方式 B: CMD 批处理（兼容旧版）

```cmd
E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\launch_atomcode_v4.bat
```

### 方式 C: 手动设置环境变量后启动

```powershell
$env:DEEPSEEK_API_KEY = "atomcode-local"
$env:DEEPSEEK_BASE_URL = "http://127.0.0.1:13460/v1"
python "E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\atomcode_proxy.py" 13460
```

---

## 六、成本复盘

| 项目 | 值 |
|------|-----|
| 工具调用 | ~15次（文件读写 + 系统命令 + API尝试） |
| 新创建文件 | launch_atomcode_v4.ps1, cnb_proxy_clouddev.py, 本文档 |
| 编辑文件 | orca-config.json, launch_atomcode_v4.bat |
| 阻塞项 | CNB_TOKEN 过期（需 `cnb login`） |
| 零积分消耗 | ✅ 全程本地操作，未消耗API积分 |

---

> 万法皆空，因果不空。代理已就位，Token 待续命。
*（内容由AI生成，仅供参考）*
