---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_8e10f1b4958f11f1b50c525400826444
    ReservedCode1: y/wkqLfLJ6WcTgGI17/1UE9qA65uV5wgndoD30mZ/BOIBGPplxXLKOI0ok01junYUGlbhZWZXl0Sy8H2vHGZaAj3zLb7gJ/PVuMyx6n/1tSXgHLSATzh4IU8vhv0sWjV4zQAuzVEh/8WbyvzBDre8m7SMeuHWclsNfnmBmpFkfpLEhKJJ89I4KLbOBg=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_8e10f1b4958f11f1b50c525400826444
    ReservedCode2: y/wkqLfLJ6WcTgGI17/1UE9qA65uV5wgndoD30mZ/BOIBGPplxXLKOI0ok01junYUGlbhZWZXl0Sy8H2vHGZaAj3zLb7gJ/PVuMyx6n/1tSXgHLSATzh4IU8vhv0sWjV4zQAuzVEh/8WbyvzBDre8m7SMeuHWclsNfnmBmpFkfpLEhKJJ89I4KLbOBg=
---

# Hermes Studio / CC-Switch / Claude Code 免费 DeepSeek-V4 使用指南

> 版本：v1.0 | 创建：2026-08-11 | 三元归一·四化迭代·MCP桥接
> 前提：AtomCode 已登录（账号 gcw_1D1KA17b），CodingPlan Lite 激活至 2026-09-10
> 零积分消耗 | 全本地闭环 | 断网可降级

---

## 〇、核心架构总览

```
┌─────────────────────────────────────────────────────────────┐
│                    AtomCode CLI (免费额度)                     │
│          E:\龙虾AI主控中心\我的AI分身\AtomCode\                │
│          base_url = https://llm-api.atomgit.com/v1            │
│          model = AtomGit-deepseek-v4-flash                    │
└──────────────────────┬──────────────────────────────────────┘
                       │ subprocess headless
                       ▼
┌─────────────────────────────────────────────────────────────┐
│           atomcode_proxy.py  (OpenAI 兼容代理)                 │
│              监听 127.0.0.1:13460/v1                          │
│              OpenAI API 标准格式 /chat/completions              │
└───────┬──────────────┬───────────────┬──────────────────────┘
        │              │               │
        ▼              ▼               ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐
│ Hermes Studio│ │CC-Switch │ │ Claude Code  │
│ 设置 endpoint│ │设置 base │ │ 设置 provider │
│   → 13460    │ │   → 13460│ │    → 13460   │
└──────────────┘ └──────────┘ └──────────────┘
```

---

## 一、终端一键启动（第一步·必做）

### 方式A：一键 BAT 脚本（推荐·双击即用）

```
E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\launch_atomcode_v4.bat
```

自动执行 5 步：注入环境变量 → 检查 atomcode.exe → 清理旧进程 → 领取免费额度 → 启动代理。终端窗口保持运行，按 Ctrl+C 停止。

### 方式B：终端命令行启动（适合集成到其他脚本）

```powershell
set "OPENAI_BASE_URL=http://127.0.0.1:13460/v1"
set "OPENAI_API_KEY=atomcode-local"
set "ATOMCODE_HOME=E:\龙虾AI主控中心\我的AI分身\AtomCode"
python "%ATOMCODE_HOME%\scripts\atomcode_proxy.py" 13460
```

### 方式C：PowerShell 后台作业（无窗口·静默运行）

```powershell
Start-Job -Name "atomcode-proxy" -ScriptBlock {
    python "E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\atomcode_proxy.py" 13460
}
# 停止：Stop-Job -Name "atomcode-proxy" ; Remove-Job -Name "atomcode-proxy"
```

### 验证代理就绪

```powershell
curl http://127.0.0.1:13460/v1/models
# 应返回：deepseek-v4-flash, Qwen/Qwen3-VL-8B-Instruct
```

返回含 `AtomGit-deepseek-v4-flash` 的 JSON 即为成功。

---

## 二、三客户端配置

### 2.1 Hermes Studio 配置

Hermes Studio 默认使用 Marvis 的模型配置。若要手动指定本地代理：

1. 打开 Hermes Studio 设置 → 模型配置
2. 添加自定义 Provider：
   - **Provider Name**：`AtomCode-V4-Local`
   - **Base URL**：`http://127.0.0.1:13460/v1`
   - **API Key**：填入任意非空字符串（如 `atomcode-local`）
   - **Model**：`AtomGit-deepseek-v4-flash`
3. 设为默认模型

**常见报错**：若 Hermes 报 "API call failure"，通常是因为代理未启动。确认 `python atomcode_proxy.py` 正在运行。

### 2.2 CC-Switch 配置

CC-Switch 读系统环境变量或 config.json。将环境变量指向本地代理：

```powershell
# 加载环境脚本
E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\activate_v4_env.ps1
```

或手动设置：

```powershell
$env:ANTHROPIC_BASE_URL = "http://127.0.0.1:13460/v1"
$env:OPENAI_BASE_URL = "http://127.0.0.1:13460/v1"
$env:OPENAI_API_KEY = "atomcode-local"
$env:DEFAULT_MODEL = "AtomGit-deepseek-v4-flash"
```

然后启动 CC-Switch，它会自动读取这些环境变量。

### 2.3 Claude Code 配置

Claude Code CLI 方式配置 provider：

**方法一：环境变量注入**

```powershell
$env:ANTHROPIC_BASE_URL = "http://127.0.0.1:13460/v1"
claude
```

**方法二：配置文件**

在 Claude Code 的 `config.json` 或 `.claude.json` 中添加：

```json
{
  "providers": {
    "atomcode-v4": {
      "base_url": "http://127.0.0.1:13460/v1",
      "api_key": "atomcode-local",
      "model": "AtomGit-deepseek-v4-flash"
    }
  }
}
```

**常见报错**："Missing programming agent credential" 表示 Claude Code 未找到 API Key。确认 `$env:OPENAI_API_KEY` 或 `$env:ANTHROPIC_API_KEY` 已设置为任意非空值。

---

## 三、加载龙虾五步法 V3.7

龙虾五步法不是系统内置 Skill，必须以本地文件方式加载。各个客户端加载方式不同：

### 3.1 核心文件清单

| 文件 | 路径 | 用途 |
|------|------|------|
| 龙虾五步法 V3.7 | `E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\SKILL.md` | 主框架：五步法 + 成本优先铁律 + 技能生态注册表 |
| 全域官方模板 | `E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\龙虾全域官方模板-最终版.md` | 26维协议矩阵 + 280项技术协议 |
| 赛博书屋 v1.5 | `E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\赛博书屋（Cyber Book House）v1.5SKILL.md` | 全网资料萃取与知识蒸馏引擎 |
| 仓颉Skill | `E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\仓颉Skill知识蒸馏技能.md` | RIA-TV++ 蒸馏流水线 |

### 3.2 在 Hermes Studio 中加载

在对话中发送：

```
加载以下技能文件并写入上下文：
1. E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\SKILL.md
2. E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\龙虾全域官方模板-最终版.md

然后按龙虾五步法执行：{你的任务}
```

### 3.3 在 CC-Switch / Claude Code 中加载

两种方式：

**方式一：@文件注入**

```
@E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\SKILL.md
@E:\龙虾AI主控中心\我的AI分身\技能库\lobster_task_standard_workflow_v3.0\龙虾全域官方模板-最终版.md

按龙虾五步法执行：{你的任务}
```

**方式二：Claude Code 自定义指令**

在 `.claude/skills/` 下放置 SKILL.md 的自定义指令文件，Claude Code 启动时自动加载。

---

## 四、五步法执行流程速查

### 执行四阶段（四化迭代）

```
Step1 炼精化气 → 意图识别，理解终极目标，自主拆解任务
Step2 炼气化神 → 能力映射，遍历技能注册表，匹配关键词触发软链接
Step3 炼神还虚 → 方案规划，自主决策，预判风险
Step4 炼虚合道 → 自主执行，多Agent协作，自动验证
Step5 反思进化 → 蒸馏技能/思维，更新 Obsidian 知识库
```

### 成本优先铁律（Step0 置顶）

执行任何任务前，先走成本评估：
- 能本地不联网 → 优先读取本地文件/复用已有脚本
- 能批量不单调 → 合并多次调用为一次
- 能复用不新建 → 优先用已有 Skill/MCP/脚本
- 不重复读取 → 同一文件只读一次，缓存中间结果

### 技能软链接触发

当用户说「调用龙虾五步法」时，Agent 自动遍历注册表匹配关键词：

| 用户说 | 触发技能 | 动作 |
|--------|----------|------|
| "萃取/学习/网盘/B站/Git" | 赛博书屋 | Marius解析 → Obsidian沉淀 |
| "蒸馏/提取知识/转化视频" | 仓颉Skill | RIA-TV++蒸馏流水线 |
| "接单/客户视频/批量生成" | 仓颉 + HyperFrames + 短剧剧本 | 蒸馏→脚本→渲染全链路 |
| "学习XX/提升生产力/自我进化" | 一键自我进化 | AgentReach采集→赛博洗练→仓颉蒸馏→技能注册 |
| "浏览器自动化/截图/填表" | Marvis浏览器插件 | CDP全自动操控 |
| "三端巡检/同步/备份" | 三端同步Playbook + CNB双向同步 | robocopy增量 + git push/pull |

---

## 五、迭代 Obsidian 知识库

### 5.1 知识库物理路径

```
E:\龙虾AI主控中心\Obsidian\wiki\
  ├── 赛博书屋\          ← 萃取的资料/笔记/指南
  ├── CNB-*              ← CNB 相关文档
  └── ...
```

### 5.2 沉淀产出物流程（Step5 反思进化）

每次任务完成后，Agent 自动执行：

1. **技能蒸馏**：从本次任务中提取可复用模式 → 写入对应 Skill 文件
2. **知识沉淀**：关键产出物（指南、笔记、配置）→ 写入 `Obsidian\wiki\赛博书屋\`
3. **技能注册**：新技能 → 登记到 SKILL.md 第十一章「技能生态系统·软链接注册表」
4. **触发词映射**：更新 11.3「触发关键词映射」表
5. **全域模板归档**：涉及协议/矩阵的更新 → 融入全域官方模板相应编号

### 5.3 三端同步（Obsidian ↔ CNB ↔ G盘）

```
CNB双向同步 v1.0:
  robocopy E:\龙虾AI主控中心\Obsidian\wiki\ → CNB远程仓库
  git pull → git add → git commit → git push
  定时触发：schtasks /tn "龙虾-CNB双向同步" (30分钟)
```

> **注意**：G盘为只读网络驱动器，所有写入操作自动改道至 `E:\龙虾AI主控中心\` 对应路径。

---

## 六、MCP 插件迭代方案

### 6.1 当前 MCP 体系

龙虾五步法的 MCP 插件通过「技能生态系统·软链接注册表」管理，本质上是本地 Python 脚本 + Shell 脚本 + SKILL.md 的组合，而非标准 MCP Server。

### 6.2 可用 MCP 类脚本清单

| 脚本 | 路径 | 功能 |
|------|------|------|
| AgentReach 桥接 | `cyber-book-house\agentreach_bridge.py` | 零成本全网抓取→入库 |
| 道层过滤器 | `cyber-book-house\cyber_filter.py` | 文殊心咒·五维评判过滤器 |
| ORCA 部署脚本 | `orca_deploy.py` | 一键推送至五大仓库 |
| CNB Pipeline | `cnb-pipeline.yml` | CI/CD 流水线：校验→索引→净化 |
| CNB 双向同步 | `cnb_sync.bat` | robocopy增量同步 |
| 一键自我进化 | `orca\self-evolve\self_evolve.py` | 采集→洗练→蒸馏→注册→融入 |
| 闲鱼自动化调度 | `orca\schedulers\auto_xianyu_scheduler.py` | 每日上架+客服+选品 |
| 量化双仓调度 | `orca\schedulers\quant_scheduler.py` | MT4/MT5+币安巡检 |
| 凭证链路自动巡检 | `docs\credential-automation\` | GH_TOKEN/XHS/DOUYIN Cookie校验 |

### 6.3 迭代 MCP 的标准流程

```
用户指令：迭代 MCP → 龙虾五步法自动执行：

Step0 成本评估 → 全部本地脚本，零积分，直接执行
Step1 炼精化气 → 识别迭代目标：更新哪个MCP脚本？
Step2 炼气化神 → 
  - 遍历注册表找到对应脚本
  - 读取脚本当前代码
  - 确定改动范围
Step3 炼神还虚 → 
  - 生成新版本代码
  - 写入中间产物目录 temp/
  - 验证语法
Step4 炼虚合道 → 
  - 替换原脚本文件
  - 更新注册表版本号
  - 更新触发关键词映射（如新增关键词）
Step5 反思进化 → 
  - 记录变更日志到 Obsidian\wiki\赛博书屋\
  - 同步更新全域模板相关协议编号
```

### 6.4 在 Hermes / CC-Switch / Claude Code 中触发 MCP 迭代

```
# 通用指令格式（在任何客户端中均可使用）：
加载龙虾五步法和全域模板，迭代 {MCP名称}，优化 {具体功能}
```

示例：

```
加载龙虾五步法和全域模板，迭代凭证链路自动巡检 v1.0，
增加微博Cookie校验和报警间隔可配置。
```

Agent 会自动：
1. 读取 SKILL.md 定位目标脚本路径
2. 读取源文件分析改动点
3. 生成新版本
4. 替换并注册
5. 沉淀到 Obsidian

---

## 七、故障排查速查表

| 现象 | 原因 | 解决 |
|------|------|------|
| Hermes "API call failure" | 代理未启动 | 执行 `launch_atomcode_v4.bat` |
| Claude Code "missing credential" | 未设置 API Key 环境变量 | `$env:OPENAI_API_KEY="atomcode-local"` |
| 代理返回 403 | AtomCode Token 过期 | 重新执行 `atomcode login` |
| 代理返回 429 | 免费额度耗尽 | 等待次日重置（08:30 自动领取） |
| 加载龙虾五步法失败 | use_skill 调用 | 龙虾五步法不是系统 Skill，须 read_text 本地文件加载 |
| Obsidian 写入失败 | 权限/G盘只读 | G盘自动改道至 E盘 |

---

## 八、每日自动维护任务

以下定时任务已通过 `schtasks` 注册：

| 任务 | 频率 | 说明 |
|------|------|------|
| 领取 AtomCode 免费额度 | 每日 08:30 | 自动续期 CodingPlan Lite |
| CNB 双向同步 | 每 30 分钟 | Obsidian ↔ CNB 仓库同步 |
| 凭证链路巡检 | 每 2 小时 | GH_TOKEN / XHS / DOUYIN 有效性检查 |
| 量化双仓巡检 | 每 30 分钟 | MT4/MT5 + 币安数据同步 |
| 三端一致性校验 | 每 4 小时 | E盘 ↔ CNB 远端 SHA256 校验 |

---

## 九、一句话速查（Cheat Sheet）

```
启动代理     → launch_atomcode_v4.bat
验证代理     → curl http://127.0.0.1:13460/v1/models
Hermes配置   → Provider: http://127.0.0.1:13460/v1, Model: AtomGit-deepseek-v4-flash
CC-Switch    → $env:OPENAI_BASE_URL="http://127.0.0.1:13460/v1"
Claude Code  → $env:ANTHROPIC_BASE_URL="http://127.0.0.1:13460/v1"
加载五步法   → read_text SKILL.md + 全域模板 → 发送给Agent
迭代MCP      → "加载龙虾五步法和全域模板，迭代 XX MCP"
知识库沉淀   → 自动写入 E:\龙虾AI主控中心\Obsidian\wiki\赛博书屋\
三端同步     → robocopy + git push (每30min自动)
```

---

> **万法皆空，因果不空。有道无术术可求，有术无道止于术。**
>
> 本指南自身也走赛博书屋入库流程，已沉淀至 Obsidian 知识库，后续可通过「调用龙虾五步法」+「搜索使用指南」自动发现。
*（内容由AI生成，仅供参考）*
