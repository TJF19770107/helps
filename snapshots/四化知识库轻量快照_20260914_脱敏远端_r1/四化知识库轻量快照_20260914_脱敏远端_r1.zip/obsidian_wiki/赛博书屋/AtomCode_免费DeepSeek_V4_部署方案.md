---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_ffb964d8958411f195a2525400e6dd8f
    ReservedCode1: Q7KG7M8GWItXxYcEUAR6ASFyccZkmniRta5sBwWleF3hNtCrOzy/5//lJarWjEjqHF8nkxlmV09sFkP2IYkdqthoi/QjzQxKA/A1BxYX7lc0q1Ncn9NEU1kn2XsOQ5GxIPkJ4sc+erVe5GOWyN7vU82IhlJOH4oWn0k14vhbNxv+fwHXOQIwA/BDVCY=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_ffb964d8958411f195a2525400e6dd8f
    ReservedCode2: Q7KG7M8GWItXxYcEUAR6ASFyccZkmniRta5sBwWleF3hNtCrOzy/5//lJarWjEjqHF8nkxlmV09sFkP2IYkdqthoi/QjzQxKA/A1BxYX7lc0q1Ncn9NEU1kn2XsOQ5GxIPkJ4sc+erVe5GOWyN7vU82IhlJOH4oWn0k14vhbNxv+fwHXOQIwA/BDVCY=
---



# AtomCode + 免费 DeepSeek V4 本地部署方案

## 概述

通过 AtomCode CodingPlan Lite 获取免费 DeepSeek V4 Flash 额度，构建本地 OpenAI 兼容 API 代理，使 Orca / Claude Code / Hermes Codex 等工具均可使用免费 V4。

## 架构

```
Orca / Claude Code / Hermes Codex
         │
         │ OpenAI-compatible API
         ▼
  atomcode_proxy.py (127.0.0.1:13460)
         │
         │ subprocess call
         ▼
  atomcode.exe (headless mode)
         │
         │ OAuth session
         ▼
  llm-api.atomgit.com (AtomGit 网关)
         │
         ▼
  DeepSeek V4 Flash (免费额度)
```

## 环境变量

| 变量 | 值 | 说明 |
|------|-----|------|
| `ATOMCODE_HOME` | `E:\龙虾AI主控中心\我的AI分身\AtomCode\.atomcode` | AtomCode 配置目录 |
| `ATOMCODE_AUTH_TOKEN` | `tDyR6D8NZacYdWApUeoRpyS8` | AtomGit PAT 令牌 |
| `ATOMCODE_BIN` | `E:\龙虾AI主控中心\我的AI分身\AtomCode\bin\atomcode.exe` | AtomCode 可执行文件 |

## 可用模型

| 模型 ID | 类型 | 上下文窗口 | 费用 |
|---------|------|-----------|------|
| `deepseek-v4-flash` | 文本 | 1M tokens | 免费 |
| `Qwen/Qwen3-VL-8B-Instruct` | 多模态 | 128K tokens | 免费 |

## 一键启动

```batch
E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\launch_atomcode_v4.bat
```

或从任意位置运行:
```powershell
powershell -File "E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\activate_v4_env.ps1"
python "E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\atomcode_proxy.py" 13460
```

## 工具配置

### Orca

- 模型供应商: OpenAI Compatible
- Base URL: `http://127.0.0.1:13460/v1`
- API Key: 任意值（如 `atomcode-free`）
- 模型: `deepseek-v4-flash`

### Claude Code

```powershell
$env:ANTHROPIC_BASE_URL = "http://127.0.0.1:13460"
$env:ANTHROPIC_API_KEY = "atomcode-free"
claude --model deepseek-v4-flash
```

### Hermes Codex

- Provider: OpenAI Compatible
- Base URL: `http://127.0.0.1:13460/v1`
- API Key: `atomcode-free`
- Model: `deepseek-v4-flash`

## 定时任务

每日 08:30 自动领取 CodingPlan Lite 免费额度（30天有效期）。

## 与云原生 DeepSeek V4 的区别

| 特性 | AtomCode 本地代理 | CNB 云原生网关 |
|------|-------------------|----------------|
| 端点 | `127.0.0.1:13460` | CNB 网关地址 |
| 鉴权 | AtomGit OAuth + PAT | CNB Token |
| 模型 | deepseek-v4-flash | DeepSeek V4 |
| 费用 | CodingPlan Lite (免费) | 按量计费 |
| 延迟 | 3-30s (冷启动) | <1s |
| 适用场景 | 免费轻量开发 | 生产级调用 |

## 文件清单

| 文件 | 路径 | 用途 |
|------|------|------|
| 一键启动 | `E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\launch_atomcode_v4.bat` | 全自动启动代理 |
| 代理脚本 | `E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\atomcode_proxy.py` | Python API 代理 |
| 环境脚本 | `E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\activate_v4_env.ps1` | 环境变量注入 |
| AtomCode | `E:\龙虾AI主控中心\我的AI分身\AtomCode\bin\atomcode.exe` | AtomCode v5.0.5 |

## 状态

- 登录账号: `gcw_1D1KA17b`
- 计划: CodingPlan Lite (2026-09-10 到期)
- 代理状态: 就绪
- 定时任务: 每日 08:30 自动领取
*（内容由AI生成，仅供参考）*
