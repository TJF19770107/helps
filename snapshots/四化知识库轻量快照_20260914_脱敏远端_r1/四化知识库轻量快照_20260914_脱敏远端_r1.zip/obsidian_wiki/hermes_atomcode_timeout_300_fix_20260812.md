# Hermes调用AtomCode超时500修复 · HTTP 500 timed out after 300s · 2026-08-12

> **来源**：企业微信群定制接单项目故障复盘 | **分类**：系统自愈 · 稳定性保障 | **状态**：ACTIVE
> **方法**：龙虾五步法 V3.0 · 全域模板 · 四化迭代

## 问题现象

企业微信群里 hermes 报错：`HTTP 500: AtomCode timed out after 300s`

## 根因（两层，缺一不可）

| 层 | 问题 | 修复 |
|----|------|------|
| **代理侧** | `atomcode_proxy.py` 原 `TIMEOUT=300`，长请求（hermes 上下文大）超时即返回 500 | 已放宽到 `TIMEOUT=900`（与 `.atomcode/config.toml` 的 `subagent.timeout_secs=900` 对齐） |
| **hermes 客户端侧** | `custom_providers.atomcode-v4-local` 未配 `stale_timeout_seconds`，走默认 **300s stale 检测**，长请求被掐断（日志：WinError 10053 连接中止） | **本次核心修复**：加 `request_timeout_seconds: 1800` + `stale_timeout_seconds: 3600` |

## 修复落点

文件：`C:\Users\Administrator\AppData\Local\hermes\config.yaml`

```yaml
custom_providers:
  - name: atomcode-v4-local
    base_url: http://127.0.0.1:13460/v1
    api_key: atomcode-local
    model: deepseek-v4-flash
    api_mode: chat_completions
    request_timeout_seconds: 1800   # 请求超时 30 分钟 > 代理 900s
    stale_timeout_seconds: 3600     # 关闭默认 300s stale 掐断
```

备份：`config.yaml.bak_20260812_timeoutfix`

## 验证结果

| 验证项 | 结果 |
|--------|------|
| YAML 语法解析 | ✅ 1800/3600 已生效 |
| 代理 `/health` | ✅ `{"status":"ok"}` |
| 实测 `13460/v1/chat/completions` | ✅ 正常返回 |
| hermes 读取链路 | ✅ `_KNOWN_KEYS`（config.py:3783）认可字段；`get_provider_request_timeout/stale_timeout` 读取；`load_config()` 按 mtime 自动重载，**无需重启 hermes** |
| 守护日志 | ✅ 代理持续 ALIVE |

## SOP 速记

1. 报 `timed out after 300s` 时先分两层查：代理 `TIMEOUT`（`atomcode_proxy.py` 顶部）与 hermes `custom_providers` 的 `stale_timeout_seconds`
2. 铁律：**客户端超时 > 代理超时**（hermes 1800s > 代理 900s），否则长请求先被客户端掐断
3. 修改 hermes 配置无需重启（mtime 自动重载），代理改 `TIMEOUT` 需重启代理进程
4. 快照回滚：`E:\...\AtomCode\snapshots\atomcode_proxy_snapshot_*.zip` + RESTORE 说明

## 四化校准

| 维度 | 状态 | 说明 |
|------|------|------|
| 智能化 | ✅ | 自主定位两层根因并修复 |
| 定制化 | ✅ | 针对"客户端掐断长请求"这一特定机制定制 |
| 全自动化 | ✅ | mtime 热加载 + 守护自愈，零人工 |
| 自我进化 | ✅ | 本经验沉淀至 Obsidian + 脚手架 |

## 关联

- [[atomcode_proxy_stability_v2_20260812]]
- [[codex_ccswitch_atomcode_404_fix_20260812]]
