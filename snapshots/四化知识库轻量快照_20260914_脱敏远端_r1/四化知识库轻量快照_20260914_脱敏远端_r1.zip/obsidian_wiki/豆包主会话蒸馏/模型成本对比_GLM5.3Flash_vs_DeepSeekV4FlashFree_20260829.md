---
title: 模型成本对比：GLM-5.3-Flash(0.01折) vs DeepSeek-V4-Flash-Free
date: 2026-08-29
tags: [模型成本, 零成本铁律, TeamoRouter, CNB免费池, 汤小龙]
distilled_by: 汤小龙 + Codex 四化迭代
---

# 模型成本对比（2026-08-29）

## 结论

**宗旨：零积分、零成本，不花钱把事儿办了。免费池优先，付费折扣仅作测试备选。**

## 对比

| 项目 | glm-5.3-flash-free（TeamoRouter 0.01折福利） | deepseek-v4-flash-free（CNB 免费池） |
|---|---|---|
| 输入单价 | $0.0001/M tokens（限时） | 0 元 |
| 输出单价 | $0.0004/M tokens（限时） | 0 元 |
| 现金消耗 | 需余额，配额耗尽/到期后静默切正常计费 | 零现金，免费至 2026-12-31 |
| 协议 | 仅 Chat Completions（Codex 需转换桥 51428） | 原生 Responses，Codex 直连 |
| 风险 | 活动到期涨价、配额静默扣费 | 频次限流 429，无账单风险 |
| 定位 | 对照测试 / 多模态备选，禁入定时任务 | 四化迭代 / 定时任务 / 眼根主力 |

## 经验规则（self-evolve 入库）

> 限时折扣付费模型不配置为 Agent 定时任务默认大脑，防止活动结束后静默扣费；优先启用免费兜底大脑。

## 落点

- 铁律写入：AI分身实体 `SOUL.md` 第十四节 + `AGENTS.md` 第十一节（同源）。
- 运维细节：`AI分身实体\技能\分身运维与大脑切换\SKILL.md`（含 5折/0.01折判别：账单模型名带 `-free` 后缀才命中福利档）。
- Codex 桌面端接入（2026-08-29）：客户端模型下拉框由供应商目录筛选，`-free` 被过滤无法直接显示；已在 `~/.codex/config.toml` 与 Orca runtime config 新增自定义 provider `teamorouter_glm`（chat_completions，直连 teamorouter.cn/v1，密钥走 `TEAMOROUTER_API_KEY` 环境变量）。手动切换命令：`codex -c model_provider=teamorouter_glm -c model=glm-5.3-flash-free`。默认 provider 未改动。
