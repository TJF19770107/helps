---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_cdbfc853910c11f1bcfc525400e6dd8f
    ReservedCode1: VLRyk8DtaGaXc9Pdf+OLnDh39I/kZwmV/qodGzZBRSxi/Tdn1bM6m60J1vgBc/B+w/Drtsg0HAyrgmkZ+xFd3q8A+Diu3OapqqEh9aIYqRYV5c7Dap7U40kJP5dG4c+z8Oww1o/nJllZ1Hfsnyc31KDWSpr94X8Px0XuDX1Stz3qeXLPCBSV5NZBr4Q=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_cdbfc853910c11f1bcfc525400e6dd8f
    ReservedCode2: VLRyk8DtaGaXc9Pdf+OLnDh39I/kZwmV/qodGzZBRSxi/Tdn1bM6m60J1vgBc/B+w/Drtsg0HAyrgmkZ+xFd3q8A+Diu3OapqqEh9aIYqRYV5c7Dap7U40kJP5dG4c+z8Oww1o/nJllZ1Hfsnyc31KDWSpr94X8Px0XuDX1Stz3qeXLPCBSV5NZBr4Q=
---

# CNB CodeBuddy DeepSeek-V4-Flash 0731 正式版

## 模型参数

- **模型名**：DeepSeek-V4-Flash（0731正式版）
- **架构**：MoE（Mixture of Experts）
- **总参数**：284B
- **激活参数**：13B
- **免费期限**：2026年12月31日
- **费用**：0元

## 性能对标

| 指标 | 数值 | 说明 |
|------|------|------|
| DeepSWE | 54.4 | 较旧版提升7倍 |
| Terminal Bench | 82.7 | 终端操作能力 |

## 使用方式

### 单NPC调用
在cnb.cool任意仓库Issue/PR评论中：
```
@CodeBuddy 帮我写一个Python脚本
```

### 多NPC链式调用
```
@npc/codex 编写代码实现XX功能
@npc/claude-code 审计上面的代码
@CodeBuddy 最终审查并提交PR
```

### 角色分工

| NPC | 角色 | 职责 |
|-----|------|------|
| @npc/codex | 执行层 | 代码编写、功能实现 |
| @npc/claude-code | 审核层 | 代码审查、质量把关 |
| @CodeBuddy | 终审层 | 最终审查、提交PR、部署 |

## 五大自有仓库

| 仓库 | CNB路径 | 本地路径 |
|------|---------|----------|
| 企业接单 | TJF19770107/orca-jiedan | E:\龙虾AI主控中心\我的AI分身\企业微信群定制接单项目 |
| 网盘萃取 | TJF19770107/orca-wangpan | E:\龙虾AI主控中心\我的AI分身\网盘萃取项目 |
| 闲鱼自动化 | TJF19770107/orca-xianyu | E:\龙虾AI主控中心\我的AI分身\闲鱼自动化项目 |
| 量化嘉盛 | TJF19770107/orca-quant-jiasheng | E:\龙虾AI主控中心\我的AI分身\量化嘉盛策略项目 |
| 量化币安 | TJF19770107/orca-quant-binance | E:\龙虾AI主控中心\我的AI分身\量化币安策略项目 |

## 记录时间
2026-08-06

---
*来源：CNB平台DeepSeek-V4-Flash 0731正式版发布公告*
*（内容由AI生成，仅供参考）*
