---
title: TeamoRouter低成本三Agent共用链路
category: AI工具运维
tags: [TeamoRouter, Hermes, Codex, Claude-Code, 四化迭代, 成本优先]
created: 2026-09-05
---

# TeamoRouter低成本三Agent共用链路

## 结论

Hermes Studio、Codex、Claude Code 三端统一走 TeamoRouter，默认成本顺序为：

1. `deepseek-v4-flash-free`（免费）
2. `glm-5.3-flash-free`（0.01折）
3. `deepseek-v4-pro-free`（免费）
4. `deepseek-v4-flash`（低折兜底）
5. `glm-5.3-flash`（5折兜底）

本机共用入口为 `http://127.0.0.1:18091/v1`，由 `MCP服务/teamorouter_failover_proxy.py` 提供模型列表、Responses/Chat 透传和故障转移。

## 配置落点

- Hermes：`%LOCALAPPDATA%\hermes\config.yaml`，默认模型 `deepseek-v4-flash-free`，provider 指向 18091。
- Codex：`~/.codex/config.toml`，默认模型改为 `deepseek-v4-flash-free`；`CODEX_BASE_URL=http://127.0.0.1:18091/v1` 不动。
- Claude Code：`~/.claude/settings.json`，主模型 `glm-5.3-flash`，小模型 `glm-5.3-flash-free`，Anthropic 兼容端点为 `https://teamorouter.cn`。

## 关键经验

- TeamoRouter 的 `/v1/messages` 是 Anthropic 兼容端点，Claude Code 可直连。
- 免费模型当日额度耗尽会返回 402，故障转移代理必须继续处理，否则三端会被卡死。
- 免费额度到每日 0 点刷新；当天如需立即工作，可按低折兜底继续执行。
- `glm-5.3-flash` 在 Claude Code 中会被提示为未识别模型，但实际调用成功；用 `CLAUDE_CODE_MAX_CONTEXT_TOKENS=1000000` 控制上下文假设。

## 备份

- `hermes/config.yaml.bak_teamorouter_20260905`
- `~/.claude/settings.json.bak_teamorouter_20260905`
- `MCP服务/teamorouter_failover_proxy.py.bak_20260905`

## 验证记录

- `hermes doctor`：配置文件、Python 环境、外部工具均通过。
- `claude -p "只回复OK" --model glm-5.3-flash`：返回 `OK`。
- 18091 最小请求：免费额度耗尽后自动切换到低折模型并成功返回。
