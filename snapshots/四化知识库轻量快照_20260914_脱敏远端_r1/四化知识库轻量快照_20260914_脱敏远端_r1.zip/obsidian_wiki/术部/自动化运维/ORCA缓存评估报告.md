# ORCA 缓存评估报告

> 评估日期：2026-08-01
> 评估目标：ORCA 是否需要 5~10G 独立缓存分区

---

## 一、当前各进程缓存分布

| 组件 | 路径 | 大小 | 所在磁盘 |
|------|------|------|----------|
| Codex | `C:\Users\Administrator\.codex` | **1.5GB** | C盘 |
| npm (global) | `C:\Users\Administrator\AppData\Roaming\npm` | **391MB** | C盘 |
| ORCA Local | `C:\Users\Administrator\AppData\Local\orca` | **306MB** | C盘 |
| uv | `C:\Users\Administrator\AppData\Local\uv` | **250MB** | C盘 |
| Hermes | `C:\Users\Administrator\.hermes` | **4.6MB** | C盘 |
| pagefile.sys | `C:\pagefile.sys` | **35GB** | C盘 |
| **C盘缓存合计** | — | **~2.5GB** | C盘 |

## 二、磁盘空间现状

| 磁盘 | 容量 | 已用 | 可用 | 使用率 | 风险等级 |
|------|------|------|------|--------|----------|
| **C盘** | 155GB | 152GB | **2.8GB** | **99%** | 🔴 危险 |
| E盘 | 141GB | 134GB | 6.8GB | 96% | 🟠 偏高 |
| F盘 | 43GB | 41GB | 2.5GB | 95% | 🟠 偏高 |
| **G盘** | 932GB | 549GB | **383GB** | **59%** | 🟢 充裕 |
| H盘 | 31GB | 29GB | 2.1GB | 94% | 🟠 偏高 |
| I盘 | 96GB | 84GB | 12GB | 88% | 🟡 中等 |
| J盘 | 96GB | 92GB | 3.7GB | 97% | 🟠 偏高 |
| K盘 | 69GB | 67GB | 2.4GB | 97% | 🟠 偏高 |

## 三、磁盘 I/O 瓶颈分析

### 核心问题：C 盘 99% 满，仅剩 2.8GB

**直接后果：**
1. **pagefile.sys 占 35GB** — 虚拟内存文件锁死 C 盘大量空间，且不可迁移（Windows 系统分区要求）
2. **所有用户级缓存（.codex、npm、orca、uv）均在 C 盘**，合计 2.5GB
3. C 盘剩余 2.8GB 意味着：
   - 系统更新/临时文件随时可能写满 C 盘
   - npm install、codex session 等高频写操作可能因磁盘满失败
   - 页面文件扩展空间不足，系统可能蓝屏或 OOM

**I/O 性能影响：**
- C 盘接近满载时，NTFS 文件系统碎片化加剧，写入性能下降 30~50%
- Codex 高频读写缓存（1.5GB）加剧 C 盘 I/O 竞争
- 系统 + 应用 + 缓存同盘争抢 I/O 带宽

## 四、方案评估

### 方案 A：在 G 盘创建 `G:\ORCA-Cache` 专属缓存分区 ✅ 推荐

**思路：** 将 C 盘上的缓存目录通过 junction（符号链接）迁移到 G 盘。

**迁移清单：**

| 组件 | 原路径 | Junction 目标 | 释放空间 |
|------|--------|---------------|----------|
| Codex | `C:\Users\Administrator\.codex` | `G:\ORCA-Cache\codex` | 1.5GB |
| npm | `C:\Users\Administrator\AppData\Roaming\npm` | `G:\ORCA-Cache\npm` | 391MB |
| ORCA Local | `C:\Users\Administrator\AppData\Local\orca` | `G:\ORCA-Cache\orca` | 306MB |
| uv | `C:\Users\Administrator\AppData\Local\uv` | `G:\ORCA-Cache\uv` | 250MB |
| **合计** | — | — | **~2.4GB** |

**迁移后 C 盘预期：** 2.8GB + 2.4GB = **~5.2GB 可用**（从危险提升到安全线）

**优点：**
- 释放 C 盘 ~2.4GB，缓解 99% 满的燃眉之急
- G 盘 383GB 可用，空间充裕，支持 5~10GB 缓存无压力
- Junction 对应用程序完全透明，无需修改任何配置
- 缓存 I/O 分散到独立物理盘（如果 G 盘是独立磁盘则 I/O 性能更优）

**风险与注意事项：**
- G 盘如果是同一物理磁盘的分区，I/O 分离效果有限
- Junction 操作需要管理员权限
- 需确保 G 盘在 ORCA 启动前已挂载

**实施步骤：**
```powershell
# 1. 创建缓存根目录
mkdir G:\ORCA-Cache

# 2. 关闭相关进程后，迁移并创建 junction
robocopy "C:\Users\Administrator\.codex" "G:\ORCA-Cache\codex" /E /MOVE
mklink /J "C:\Users\Administrator\.codex" "G:\ORCA-Cache\codex"

robocopy "C:\Users\Administrator\AppData\Roaming\npm" "G:\ORCA-Cache\npm" /E /MOVE
mklink /J "C:\Users\Administrator\AppData\Roaming\npm" "G:\ORCA-Cache\npm"

robocopy "C:\Users\Administrator\AppData\Local\orca" "G:\ORCA-Cache\orca" /E /MOVE
mklink /J "C:\Users\Administrator\AppData\Local\orca" "G:\ORCA-Cache\orca"

robocopy "C:\Users\Administrator\AppData\Local\uv" "G:\ORCA-Cache\uv" /E /MOVE
mklink /J "C:\Users\Administrator\AppData\Local\uv" "G:\ORCA-Cache\uv"
```

### 方案 B：维持现有结构，依靠 cache_cleanup.sh 自动轮转清理 ❌ 不推荐

**思路：** 不迁移，用定时清理脚本控制缓存大小。

**缺点：**
- **无法解决 C 盘 99% 满的根本问题** — 缓存清空也只能回收 2.4GB，pagefile.sys 的 35GB 不可动
- Codex 缓存清理会导致会话历史丢失，需要重新下载模型/索引
- 高频清理增加 C 盘 I/O 写入（清理本身也是写操作）
- 随着使用增长，缓存膨胀将再次触发磁盘满告警

## 五、结论

| 维度 | 评估 |
|------|------|
| 是否需要独立缓存分区？ | **是，强烈需要** |
| 建议容量 | **5GB 起步**，G 盘充裕可预留至 10GB |
| 推荐方案 | **方案 A — G:\ORCA-Cache + Junction 映射** |
| 紧急程度 | 🔴 **高** — C 盘 2.8GB 随时可能触发系统异常 |

### 建议优先级

1. **立即执行**：方案 A 迁移 .codex（1.5GB）— 最大单项缓存，释放最多空间
2. **同批次执行**：迁移 npm + orca + uv — 释放剩余 ~950MB
3. **后续优化**：考虑将 pagefile.sys 缩小或分盘，但需评估物理内存是否足够

---

*本报告基于 2026-08-01 实测磁盘数据生成*
