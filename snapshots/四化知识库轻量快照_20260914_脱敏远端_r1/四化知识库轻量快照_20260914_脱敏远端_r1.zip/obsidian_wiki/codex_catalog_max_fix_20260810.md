# Codex Catalog "max" 变体修复 · 2026-08-10

> **来源**：HERMES 群聊协作修复 | **分类**：系统自愈 · 代理修复 | **状态**：ACTIVE

## 问题

Codex CLI 启动时 exit code 1：
```
Error: failed to parse model_catalog_json path .../codex-model-catalog.json as JSON:
unknown variant `max`, expected one of `none`, `minimal`, `low`, `medium`, `high`, `xhigh`
```

## 根因

Hermes Studio `index.js` 硬编码了 `{effort:"max", description:"Maximum reasoning depth..."}`，但 Codex CLI 的枚举只接受 6 个值，`max` 不在其中。

**双层根因**：
1. **JS 源码层**：`Hermes Studio/resources/webui/dist/server/index.js` → `Hte()` 函数硬编码 `max`
2. **JSON 生成层**：每次会话启动时 Hermes Studio 重新生成 `codex-model-catalog.json`，会把 `max` 带入

## 修复方案

1. ✅ **JS 源码修补**：删除 `{effort:"max",...}` 条目（根因修复）
2. ✅ **当前 catalog JSON 修补**：5 个模型的 `max` 条目已删除
3. ⚠️ **需重启 Hermes Studio**：JS 补丁需重启生效

## 快照

```
E:\龙虾AI主控中心\MCP服务\snapshots\codex_catalog_max_fix_20260810.tar.gz
```
含 restore.sh 一键恢复。

## 四化校准

| 维度 | 状态 | 说明 |
|------|------|------|
| 智能化 | ✅ | Agent 自主发现根因并修复 |
| 定制化 | ✅ | 针对 Codex CLI 枚举约束定制 |
| 全自动化 | ✅ | restore.sh 一键恢复 |
| 自我进化 | ✅ | 快照机制防止回退 |

## 关联

- [[codex_model_catalog|Codex 模型目录]]
- [[fleet_guardian|龙虾舰队守护进程]]
- [[cnb_deepseek_v4_flash|CNB DeepSeek V4 Flash]]
