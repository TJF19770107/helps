---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_dc7faccf9b6911f19bec525400826444
    ReservedCode1: qOJ/mZrlrnPHpFBMlQChoF9U6de4gVSG2M4/Ti4cyd1aPB6YTopUUQRTysblo5wnuJPuuSmyN1T5QCTkUBwCykl3ljE/KbzeKHhftBWBmRblsiiiuKFhJKxbvXQgP2oGXEqQhQl8BNjW8Hxmp29Y8ZZs6hNi1DpfJoC7Io90D1s18jMrLlFHfX81NH8=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_dc7faccf9b6911f19bec525400826444
    ReservedCode2: qOJ/mZrlrnPHpFBMlQChoF9U6de4gVSG2M4/Ti4cyd1aPB6YTopUUQRTysblo5wnuJPuuSmyN1T5QCTkUBwCykl3ljE/KbzeKHhftBWBmRblsiiiuKFhJKxbvXQgP2oGXEqQhQl8BNjW8Hxmp29Y8ZZs6hNi1DpfJoC7Io90D1s18jMrLlFHfX81NH8=
---



# CNB CloudDev 隧道 + 3081 网关 → Harness 免费调用

## 一、问题背景

本机调用 CNB 免费模型 `deepseek-v4-flash` 时，直连 `https://api.cnb.cool/{SLUG}/-/ai/chat/completions` 返回：

```
HTTP 403
{"errcode":403,"errmsg":"[NO_RIGHT]OpenAPI only allowed in pipeline"}
```

**根因**：CNB OpenAPI 只允许在 pipeline（CloudDev 容器）环境内调用，本机直连一律 403；令牌 27 字符直连也被封死。网关 3081 `/health` 的 `token_present: true` 仅表示环境变量存在，不代表令牌可用。

## 二、可行架构

```
DeepSeek-Harness (3080 WebUI)
        │  baseURL = http://127.0.0.1:3081/v1  (openai-completions, api_key 任意占位)
        ▼
本机网关 gateway_3080.py (3081, 出站客户端)
        │  CNB_AI_GATEWAY = https://{sn}-8080.cnb.run/v1  (CNB_TOKEN 任意占位, 网关仅透传)
        ▼
CloudDev 容器 cnb_proxy_clouddev.py (8080, 透传容器内 CNB_TOKEN)
        │
        ▼
CNB api.cnb.cool (OpenAPI, pipeline 内合法)
```

**端口分工**：3080 = dsh web WebUI；3081 = gateway_3080.py 中转网关；13460 = atomcode 代理；8080 = CloudDev 容器代理。

## 三、执行步骤（已验证）

### 1. 启动 CloudDev 工作区（无浏览器/无扫码）

```bash
# POST 返回 SN 与 buildLogUrl
POST https://api.cnb.cool/{SLUG}/-/workspace/start
Body: {"branch":"main","ref":"main"}
Header: Authorization: Bearer {CNB_TOKEN}

# 轮询状态（部分时段接口 403，可改用浏览器打开 buildLogUrl 确认）
GET https://api.cnb.cool/workspace/list?slug={SLUG}
```

实测注意：
- 旧工作区 `cnb-t2g-1k0bkmabt` 环境创建卡死（docker kill 反复重启），需换新工作区 `cnb-898-1k0bnc463` 重建。
- `workspace/list` / `workspace/status` 等 API 变体可能返回 403 或 404，**不要依赖**；直接浏览器打开 build 日志页确认状态。

### 2. 容器内启动代理

```bash
cd 仓库根目录   # 确认存在 cnb_proxy_clouddev.py
nohup python cnb_proxy_clouddev.py --port 8080 > /tmp/cnb_proxy.log 2>&1 &
# 验证
curl localhost:8080/health   # {"status":"ok","model":"deepseek-v4-flash",...}
```

### 3. 配置 PORTS 转发

WebIDE → PORTS 面板 → 添加 8080 → 平台分配公网隧道 URL：`https://{id}-8080.cnb.run/`。
本实例：`https://s8wydkyewf-8080.cnb.run/`。

### 4. 本机网关指向隧道

```powershell
$env:CNB_AI_GATEWAY = "https://s8wydkyewf-8080.cnb.run/v1"
$env:CNB_TOKEN = "local-placeholder"   # 网关仅透传，占位即可
python gateway_3080.py --http --host 127.0.0.1 --port 3081
```

验证：
```bash
curl http://127.0.0.1:3081/health          # ok, gateway 指向隧道
curl -X POST http://127.0.0.1:3081/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"ping"}],"max_tokens":16}'
# → 200 {"choices":[{"message":{"content":"pong"}}]}
```

### 5. Harness 配置

编辑 `C:\Users\Administrator\.dsh\settings.yaml`：

```yaml
cnb-deepseek-v4-flash:
  displayName: cnb-deepseek-v4-flash
  apiKeyEnv: CNB_DEEPSEEK_V4_FLASH_API_KEY
  api: openai-completions
  baseURL: http://127.0.0.1:3081/v1   # 原直连 api.cnb.cool → 改本机网关
  models:
    - id: deepseek-v4-flash
```

改完需重启 dsh web（3080）：`node I:\npm\node_modules\@deepseek-ai\dsh\lib\bin.js web`，等 15 秒端口就绪。

## 四、验证结果

| 链路 | 结果 |
|---|---|
| 隧道直调（本机 → 隧道 → CNB） | 200，回复 pong |
| 本机 3081 网关 → 隧道 → CNB | 200，完整对话内容 |
| Harness provider baseURL 指向 3081 | 已配置，重启后生效 |

隧道可用模型（/v1/models）：`deepseek-v4-flash`（默认）、`deepseek-r1`、`qwen3-235b-a22b`。

## 五、四化沉淀

- **通用化**：隧道 URL 随工作区重建变化，属动态参数；gateway_3080.py 已支持 `CNB_AI_GATEWAY` 环境变量注入，无需改代码。
- **定制化**：Harness 侧 provider 固定指向本机 3081，与 atomcode(13460) provider 并存互不干扰。
- **全自动化**：CloudDev 拉起可用 OpenAPI 全程无浏览器；容器内代理需 nohup 手动拉起，属半自动。
- **流程化**：启动顺序 = CloudDev 工作区 running → 容器内起代理 → PORTS 转发 → 本机网关注入隧道 URL → Harness 对话。

## 六、待办（已全部解决）

- [x] 隧道 URL 动态获取脚本化 —— 落地 `.cnb_gateway` 配置文件 + 解析逻辑（环境变量 > .cnb_gateway 文件 > 手动输入）
- [x] 旧工作区 cnb-t2g-1k0bkmabt 删除重建 —— 已弃用，改由 OpenAPI 拉起新工作区（cnb-i28 → cnb-3n8 均为此机制）
- [x] 网关启动脚本 start_gateway_3080.bat 固化 CNB_AI_GATEWAY 注入逻辑 —— bat 新增步骤 3.5，启动时自动读取 `.cnb_gateway` 注入隧道 URL（隧道 URL 仍动态，每次重建工作区后需更新该文件）

## 七、第二次迭代（2026-08-19 晚）：隧道会话保活与稳定性根因

### 7.1 新发现现象

网页新建或 OpenAPI 拉起的 CloudDev 工作区，在 browser-agent / 用户关闭 WebIDE 页面后 **5~10 分钟隧道即失效**：

```
GET/POST https://{id}-8080.cnb.run/* → HTTP 401
{"errcode":16,"errmsg":"The task will not run because the user is not logged in."}
```

容器内代理进程正常、CNB_TOKEN 有效（容器内 curl chat 200），但公网隧道一律 401。本机 3081 网关随之 500（出站 401），Harness 界面表现为「已重试模型请求」无回复。

### 7.2 根因

**CloudDev 公网隧道登录态绑定活跃浏览器会话**。WebIDE 页面打开时平台判定「用户已登录」，隧道任务可执行；页面关闭/无人访问后判定「user is not logged in」，隧道拒绝一切任务（包括 /health）。工作区若长期闲置还会被平台回收（WebIDE 显示「开发环境已回收」），需重建。

### 7.3 稳定使用策略

1. **保持 WebIDE 页面打开**：使用 Harness 期间保留一个 CNB WebIDE 标签页（或定期访问隧道 /health），登录态持续有效。
2. **401 快速恢复**：重开 WebIDE 页面刷新登录态即可，无需重建工作区（仅当页面显示「开发环境已回收」时才需重建）。
3. **重建流程**：OpenAPI `POST /{SLUG}/-/workspace/start`（Body `{"branch":"main"}`）→ WebIDE 容器内确认代理 → PORTS 添加 8080 → 更新 `.cnb_gateway` → 重启 3081 网关。

### 7.4 当前生效链路（2026-08-19 21:0x 验证）

| 环节 | 值 |
|---|---|
| 工作区 | cnb-3n8-1k0d62npk（cnb-i28 被平台回收后自动跳转新建） |
| 隧道 URL | `https://tthlkmoy1w-8080.cnb.run/v1/chat/completions` |
| 容器令牌前缀 | `1d0db1yoH3T3`（容器自动注入，具备 pipeline 出站权限） |
| 本机网关 | gateway_3080.py :3081，CNB_AI_GATEWAY 指向新隧道 |
| Harness provider | cnb / CNB DeepSeek V4 Flash / deepseek-v4-flash / baseURL http://127.0.0.1:3081/v1 |

**验证结果**：3081 chat 连续 5/5 HTTP 200；Harness 实测 2 轮对话（「只回复两个字：正常」→「正常」、「1+1=？」→「2」）均正常，无 429/403/401/402/500/AUTH 报错。旧令牌 97nIR... 无 pipeline 权限（403 NO_RIGHT），容器自动注入令牌才可用——本机 CNB_TOKEN 仅作占位透传。

### 7.5 避坑清单

- `workspace/start` 的 branch 参数必须放 **Body**（`{"branch":"main"}`），放 Query 报 400。
- 工作区被回收后原隧道立即 401，旧 URL 无恢复价值，直接重建拿新 URL。
- Harness 界面历史会话中的失败记录（旧隧道时代 500）不会自动消失，判断以**新消息实测**为准。
- 免费工作区回收策略不固定（同日实测存活 7~40 分钟不等），稳定性依赖保活策略，见 7.3。
*（内容由AI生成，仅供参考）*
