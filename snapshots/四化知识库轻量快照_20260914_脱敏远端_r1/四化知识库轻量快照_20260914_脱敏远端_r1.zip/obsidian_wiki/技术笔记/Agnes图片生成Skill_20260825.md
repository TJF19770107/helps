---
title: Agnes Image 2.1 Flash 生成 Skill
tags: [Agnes, 文生图, 图生图, 图片生成, imagegen]
date: 2026-08-25
---

# Agnes Image 2.1 Flash 生成 Skill

给纯文本 Agent 补齐文生图/图生图能力，模型 agnes-image-2.1-flash（0.003 美元/张）。

## 技能
- `.codex/skills/agnes-imagegen/`：SKILL.md + openai.yaml + scripts/generate.py
- 入口：python .codex/skills/agnes-imagegen/scripts/generate.py --prompt "..." [--image-url ...] [--output ...]

## 2.1 关键点
1. 图生图用 extra_body.image，不用 tags:["img2img"]
2. 移除 seed / tags 参数
3. 密钥读 AGNES_API_KEY，零硬编码；AGNES_BASE_URL 可切国际/中国站

## 关联
- [[Codex Agent]] · [[Codex看图能力]] · 五步法 §11 · 1234 定义卡 #320
