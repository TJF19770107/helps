# CNB 自定义 NPC 免费方案

## 核心发现

CNB 平台 NPC 镜像分为两类：

| 镜像 | 是否含模型 | 费用 | 适用场景 |
|------|-----------|------|----------|
| `cnbcool/default-npc:latest` | ❌ 不含 | 免费但需外接API | 需自己配模型后端 |
| `cnbcool/default-codebuddy-npc:latest` | ✅ 内置DeepSeek-V4-Flash | 完全免费 | 开箱即用 |

## 关键区别

`default-npc:latest` 只提供 Docker 运行时容器，不含模型推理能力。需要额外配置：
- `settings.ai_model`
- `settings.api_key`
- `settings.base_url`

而 `default-codebuddy-npc:latest` 就是 @CodeBuddy 使用的镜像，内置 DeepSeek-V4-Flash（MoE 284B/13B），零配置、零费用。

## 最小配置方案

### .cnb/settings.yml
```yaml
npc:
  roles:
    - name: codex
      prompt: |
        你是代码执行专家...
    - name: claude-code
      prompt: |
        你是代码审查专家...
```

### .cnb.yml
```yaml
.npc_task: &npc_task
  docker:
    image: cnbcool/default-codebuddy-npc:latest
  stages:
    - name: npc go
      type: npc:go

codex:
  issue.comment@npc: *npc_task
  pull_request.comment@npc: *npc_task

claude-code:
  issue.comment@npc: *npc_task
  pull_request.comment@npc: *npc_task
```

## 调用格式

自定义 NPC 的 @ 格式为 `@仓库路径(角色名)`：
- `@TJF19770107/orca-jiedan(codex)`
- `@TJF19770107/orca-jiedan(claude-code)`

## 三级链式流程

```
@仓库路径(codex) 编写代码
  → @仓库路径(claude-code) 审计代码
    → @CodeBuddy 最终审查提交PR
```

## 学习来源

- [CNB NPC Playground](https://cnb.cool/set/npc-playground)
- [default-codebuddy-npc 镜像说明](https://cnb.cool/wawow/default-codebuddy-npc)
- [腾讯云 NPC「替我上班」](https://cloud.tencent.com/developer/article/2636974)
- [AQtoolsStudio NPC 配置 DeepSeek 方案](https://cnb.cool/AQtoolsStudio/npc)

## 记录时间
2026-08-06

---
*来源：赛博书屋从 CNB 官方文档/B站/公众号/社区仓库深度学习聚合*
