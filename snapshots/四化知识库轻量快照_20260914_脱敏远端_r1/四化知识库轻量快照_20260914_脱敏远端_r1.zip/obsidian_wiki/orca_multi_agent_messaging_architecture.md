---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: cf54d54c59baa0ada35a5ecb7c73a584_a811a3af8ffb11f1bcfc525400e6dd8f
    ReservedCode1: lDmqo3Zl4Ac6UiIh262tbuTlfsmeQElxmIWqkU7u1jn5wXFx9QQnhDlsli+NYX15xy5LckSQuJWslA1cz168nMIA4feC2smjqAPc+5HjNaRckEd0boPcfSqOxzkGPfigyJKPECdpXrjNn7vCS8LNLwiTyaypGuo2eWFiGTl/9uak+7qpCHWMRKJ+jLI=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: cf54d54c59baa0ada35a5ecb7c73a584_a811a3af8ffb11f1bcfc525400e6dd8f
    ReservedCode2: lDmqo3Zl4Ac6UiIh262tbuTlfsmeQElxmIWqkU7u1jn5wXFx9QQnhDlsli+NYX15xy5LckSQuJWslA1cz168nMIA4feC2smjqAPc+5HjNaRckEd0boPcfSqOxzkGPfigyJKPECdpXrjNn7vCS8LNLwiTyaypGuo2eWFiGTl/9uak+7qpCHWMRKJ+jLI=
---

# ORCA 多智能体编排 · 消息互通架构

> 调度者：Marvis（原 WorkBuddy 替代） | 框架：龙虾五步法 V3.0
> 四化：智能化·定制化·全自动化·自我净化
> 日期：2026-08-04

---

## 一、全局架构：物理层 + 逻辑层

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         用户（老板）                                       │
│                        "接这个单，搞定它"                                   │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     Marvis（调度层 · 替代 WorkBuddy）                       │
│                                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ 意图识别     │→│ 能力映射     │→│ 方案规划     │→│ Agent派发    │ │
│  │ (炼精化气)   │  │ (炼气化神)   │  │ (炼神还虚)   │  │ (炼虚合道)   │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────┬───────┘ │
│                                                                │         │
│                   dispatch_task (异步并行)                      │         │
│          ┌────────────┬────────────┬────────────┐              │         │
│          ▼            ▼            ▼            ▼              │         │
│   file-agent   computer-agent  app-agent   browser-agent       │         │
│   (文件/Git)   (系统/端口)    (桌面启动)   (网页操作)           │         │
└─────────────────────────────────────────────────────────────────┘
                                 │
          ┌──────────────────────┼──────────────────────┐
          ▼                      ▼                      ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│   Hermes（大脑）  │  │   Codex（执行）   │  │ Claude Code（审核）│
│   规划·拆解·决策  │→│   编码·构建·测试  │→│   审查·反馈·优化   │
│                  │  │                  │  │                  │
│ Desktop: 8642 GW │  │ CLI: 15730代理   │  │ CLI: v2.1.211    │
│ CLI: opencode    │  │ Desktop: 原生GUI │  │ Desktop: v1.8555 │
└──────┬───────────┘  └────────┬─────────┘  └────────┬─────────┘
       │                       │                      │
       └───────────────────────┼──────────────────────┘
                               │
                               ▼
                    ┌──────────────────┐
                    │  MIMO V2.5 Pro   │
                    │  端口 15721       │
                    │  /v1/messages    │
                    │  (至 2026-08-14) │
                    └──────────────────┘
```

---

## 二、物理连接层（谁连谁、什么端口、什么协议）

```
┌─────────────────────────────────────────────────────────────────────┐
│                         物理连接拓扑                                   │
│                                                                      │
│  Marvis                                                              │
│    │                                                                 │
│    │ dispatch_task (内部RPC, Marvis框架协议)                          │
│    ├──────────────► file-agent        (内部消息)                      │
│    ├──────────────► computer-agent    (内部消息)                      │
│    ├──────────────► app-agent         (内部消息)                      │
│    └──────────────► browser-agent     (内部消息)                      │
│                                                                      │
│  Marvis → shell_executor / python_executor                           │
│    │                                                                 │
│    ├─ 启动 anthropic_proxy_15721.py                                  │
│    │    └─ 监听 localhost:15721 (HTTP)                                │
│    │       └─ 转发 → token-plan-cn.xiaomimimo.com:443 (HTTPS)        │
│    │          └─ Anthropic Messages API /v1/messages                 │
│    │                                                                 │
│    ├─ 启动 codex_tool_proxy.py                                       │
│    │    └─ 监听 localhost:15730 (HTTP)                                │
│    │       └─ Codex CLI → tool_execution → 本地工具链                │
│    │                                                                 │
│    ├─ 启动 hermes.exe gateway                                        │
│    │    └─ 监听 localhost:8642 (WebSocket)                           │
│    │       └─ Hermes Desktop GUI ↔ Gateway ↔ MIMO/DeepSeek           │
│    │                                                                 │
│    └─ 启动 hermes.exe desktop                                        │
│         └─ 无独立端口（通过Gateway 8642通信）                         │
│            └─ TUI层本地渲染                                           │
│                                                                      │
│  Claude Code Desktop (claude.exe v1.8555.0)                          │
│    └─ 内置HTTP客户端 → MIMO 15721 / DeepSeek API                     │
│                                                                      │
│  Codex Desktop (codex.exe)                                           │
│    └─ 内置HTTP客户端 → 15730 Tool Proxy → 本地工具执行               │
│                                                                      │
│  CCGUI (com.zhukunpenglinyutong.ccgui)                               │
│    ├─ opencodeEnabled → Hermes (opencode) → model "mimo-v2.5-free"   │
│    ├─ codexBin="I:\npm\codex.cmd" → Codex → model "mimo-v2.5-pro"    │
│    └─ claudeBin="I:\npm\claude.cmd" → Claude Code → MIMO 15721       │
└─────────────────────────────────────────────────────────────────────┘
```

### 端口协议速查

| 端口 | 组件 | 协议 | 上游 | 用途 |
|------|------|------|------|------|
| 15721 | MIMO Proxy | HTTP REST | token-plan-cn.xiaomimimo.com:443 | 模型推理（Anthropic协议→MIMO转换） |
| 15730 | Codex Proxy | HTTP REST | 本地工具链 | Codex CLI工具执行代理 |
| 8642 | Hermes GW | WebSocket | MIMO/DeepSeek | Hermes GUI实时通信 |
| - | Claude Desktop | HTTP直连 | 15721 MIMO | Claude→MIMO推理 |
| - | Codex Desktop | HTTP直连 | 15730 Proxy | Codex工具调用 |

---

## 三、逻辑连接层（消息怎么流动、信息怎么共享）

### 3.1 三层工作流中的消息传递

```
用户说"接这个单"
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│  第一轮：Marvis → Hermes（规划请求）                               │
│                                                                  │
│  Marvis 发出的消息：                                              │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ {                                                         │  │
│  │   "role": "orchestrator",                                 │  │
│  │   "from": "Marvis",                                       │  │
│  │   "to": "Hermes",                                         │  │
│  │   "goal": "客户需求：闲鱼虚拟资料自动发货系统",              │  │
│  │   "context": {                                            │  │
│  │     "skills": ["cangjie-skill","hyperframes"],            │  │
│  │     "repos": ["G:\\Orca\\projects\\gstack"],              │  │
│  │     "model": "mimo-v2.5-pro",                             │  │
│  │     "cost_limit": "0"                                     │  │
│  │   },                                                      │  │
│  │   "expected_output": "任务拆解方案 + 执行步骤"               │  │
│  │ }                                                         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  Hermes 返回：                                                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ {                                                         │  │
│  │   "plan": [                                               │  │
│  │     "1. 分析接单平台API（闲鱼/转转）",                       │  │
│  │     "2. 设计自动发货流程：监听→匹配→发送",                   │  │
│  │     "3. 技术栈：Python + FastAPI + SQLite",               │  │
│  │     "4. 风险点：闲鱼反爬、卡密库存管理"                      │  │
│  │   ],                                                      │  │
│  │   "handoff_to": "Codex",                                  │  │
│  │   "files_to_create": ["main.py","config.yaml","db.py"]    │  │
│  │ }                                                         │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│  第二轮：Hermes → Codex（执行交给）                                │
│                                                                  │
│  Hermes 把拆解好的方案交给 Codex：                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ {                                                         │  │
│  │   "from": "Hermes (大脑)",                                 │  │
│  │   "to": "Codex (执行)",                                    │  │
│  │   "plan": "已拆解为4个子任务",                               │  │
│  │   "specs": {                                              │  │
│  │     "task_1": "FastAPI主服务 + WebSocket监听",              │  │
│  │     "task_2": "SQLite订单数据库 + CRUD接口",               │  │
│  │     "task_3": "Playwright自动化发货脚本",                   │  │
│  │     "task_4": "Docker打包 + 部署文档"                       │  │
│  │   },                                                      │  │
│  │   "constraints": ["零成本","MIMO模型","端口不冲突"]          │  │
│  │ }                                                         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  Codex 写代码 → 提交到 G:\Orca\projects\ 对应分支                  │
└─────────────────────────────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│  第三轮：Codex → Claude Code（审核交给）                            │
│                                                                  │
│  Codex 把代码产出交给 Claude Code 审核：                           │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ {                                                         │  │
│  │   "from": "Codex (执行)",                                  │  │
│  │   "to": "Claude Code (审核)",                              │  │
│  │   "deliverables": [                                       │  │
│  │     "G:\\Orca\\projects\\xianyu-auto\\main.py",            │  │
│  │     "G:\\Orca\\projects\\xianyu-auto\\db.py",              │  │
│  │     "G:\\Orca\\projects\\xianyu-auto\\deploy.sh"           │  │
│  │   ],                                                      │  │
│  │   "review_criteria": ["安全性","性能","错误处理","代码规范"]   │  │
│  │ }                                                         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  Claude Code 审查 → 反馈修改意见 → 回到 Hermes 决策是否通过        │
└─────────────────────────────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│  闭环：Claude Code → Hermes（反馈给大脑）                          │
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ {                                                         │  │
│  │   "verdict": "PASS / REVISE",                             │  │
│  │   "issues": ["db.py L42: SQL注入风险","main.py L156: 异常吞没"],│
│  │   "score": "7.5/10",                                      │  │
│  │   "recommendation": "修复安全问题后通过"                     │  │
│  │ }                                                         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  REVISE → 回到 Codex 修改 → 再次 Claude Code 审核                 │
│  PASS → Hermes 通知 Marvis 任务完成                               │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 信息全局共享机制

```
┌─────────────────────────────────────────────────────────────────────┐
│                       信息共享三层架构                                 │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  第一层：技能注册表（全局可见）                                 │   │
│  │                                                              │   │
│  │  E:\龙虾AI主控中心\我的AI分身\技能库\                           │   │
│  │  ├── lobster_task_standard_workflow_v3.0\SKILL.md             │   │
│  │  ├── cangjie-skill\           ← 知识蒸馏                      │   │
│  │  ├── hyperframes\             ← 视频渲染                      │   │
│  │  ├── vision_router_mcp\       ← 视觉路由                      │   │
│  │  ├── auto_fallback_mcp\       ← 自动降级                      │   │
│  │  └── 龙虾全域官方模板-最终版.md  ← 26维协议矩阵                 │   │
│  │                                                              │   │
│  │  所有Agent（Hermes/Codex/Claude Code/Marvis）均通过            │   │
│  │  SKILL.md §11 软链接注册表 共享技能清单                        │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  第二层：Git 工作区（代码全局共享）                             │   │
│  │                                                              │   │
│  │  G:\Orca\projects\                                           │   │
│  │  ├── config/              ← 配置仓库（所有Agent可读写）         │   │
│  │  ├── gstack/              ← 通用技术栈                        │   │
│  │  ├── cangjie-skill/       ← 知识蒸馏引擎                      │   │
│  │  └── [新项目]/            ← 接单项目即时创建                   │   │
│  │                                                              │   │
│  │  Hermes   → 开分支 hermes-plan/    → 写规划文档               │   │
│  │  Codex    → 开分支 codex-impl/    → 写代码                    │   │
│  │  Claude   → 开分支 claude-review/ → 写审查报告                │   │
│  │  合并回 main ← Hermes 决策                                     │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  第三层：Obsidian 知识库（经验全局沉淀）                        │   │
│  │                                                              │   │
│  │  E:\龙虾AI主控中心\Obsidian\wiki\                             │   │
│  │  ├── orca_fleet_orchestration_v1.md    ← 编排架构             │   │
│  │  ├── orca_diagnosis_20260804.md        ← 诊断记录             │   │
│  │  ├── 龙虾五步法V3.0·四化升级版.md       ← 核心框架             │   │
│  │  └── [新知识]/                         ← 每次任务自动沉淀     │   │
│  │                                                              │   │
│  │  双向链接 → 知识网络 → 所有人可查                              │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 四、Marvis 替代 WorkBuddy 的调度逻辑

### 4.1 对比

| 维度 | WorkBuddy（原） | Marvis（现） |
|------|----------------|-------------|
| 调度方式 | 用户手动指挥 | 自动意图识别 + dispatch_task |
| Agent选择 | 用户指定 | Marvis自动匹配 Sub Agent |
| 信息传递 | 用户复制粘贴 | memory_ids 自动注入上下文 |
| 结果汇总 | 用户自行整合 | Marvis 自动合并 + yyb-product |
| 端口管理 | 无感知 | Marvis 主动诊断 + 修复 |
| 四化沉淀 | 无 | 每轮自动写入 Obsidian |

### 4.2 Marvis 的调度决策树

```
用户输入
  │
  ├─ "接单/做项目/写代码"
  │   └─ Marvis 判断：需要多Agent编排
  │       ├─ Step1: 派 Hermes 做规划
  │       ├─ Step2: 派 Codex 执行编码
  │       ├─ Step3: 派 Claude Code 审核
  │       └─ Step4: 汇总结果 → yyb-product
  │
  ├─ "查文件/搜文档"
  │   └─ 直接派 file-agent
  │
  ├─ "改设置/修端口/查系统"
  │   └─ 直接派 computer-agent
  │
  └─ "开软件/装应用"
      └─ 直接派 app-agent
```

### 4.3 接单全流程（一条完整的消息链路）

```
老板："接那个闲鱼自动发货的单子"
  │
  ▼
Marvis（炼精化气）：识别为"多Agent编排任务"
  │
  ├─► dispatch_task → file-agent
  │     "在 G:\Orca\projects\ 下创建 xianyu-auto 项目骨架"
  │     ← 返回：项目已创建，main.py/db.py/config.yaml 就绪
  │
  ├─► dispatch_task → computer-agent
  │     "检查 15721/15730/8642 端口是否都在线"
  │     ← 返回：全部在线
  │
  ├─► dispatch_task → app-agent
  │     "启动 Hermes Desktop 和 Claude Desktop"
  │     ← 返回：已启动
  │
  ▼
Marvis（炼神还虚）：整合结果，形成执行上下文
  │
  ▼
Marvis → 用户：
  "项目骨架已就绪，MIMO模型在线，Hermes/Claude已启动。
   现在派 Hermes 做方案规划 → Codex 写代码 → Claude Code 审核。
   全程零成本，完成后自动沉淀到 Obsidian。"
  │
  ▼
  [Hermes→Codex→Claude Code 三层循环执行]
  │
  ▼
Marvis（炼虚合道）：最终结果汇总
  ├─ yyb-product 卡片展示交付物
  ├─ Obsidian 四化沉淀
  └─ 端口状态自检
```

---

## 五、命令全局布署（一条命令拉起全军）

### 舰队全量状态速查

| 命令 | 作用 | 端口 |
|------|------|------|
| `python anthropic_proxy_15721.py` | MIMO 模型代理 | 15721 |
| `python codex_tool_proxy.py` | Codex 工具代理 | 15730 |
| `hermes.exe gateway` | Hermes 网关 | 8642 |
| `hermes.exe desktop` | Hermes 桌面 | GUI |
| `I:\npm\codex.cmd` | Codex CLI | - |
| `I:\npm\claude.cmd` | Claude Code CLI | - |

---

## 六、四化落实

| 四化 | 落地方式 |
|------|----------|
| **智能化** | Marvis 自主识别意图、自动选Agent、自动诊断端口 |
| **定制化** | 蒸馏用户心理画像，对齐龙虾AI主控中心路径体系 |
| **全自动化** | 端口自启、Agent自选、结果自汇、知识自沉 |
| **自我净化** | 每轮任务后 Obsidian 知识库增量更新，废信息不残留 |

---

**文档生成**：Marvis 调度编排 | 龙虾五步法 V3.0 四化版
**版本**：v1.0 | 2026-08-04
*（内容由AI生成，仅供参考）*
