# NVIDIA API 免费 GLM-5.2 接入修复闭环（2026-08-14）

> 归档：舰队运维 | 来源：接单项目 docs/NVIDIA_GLM-5.2接入分析_20260814.md 修复落地
> 触发：用户"我要用 NVIDIA API 控制台的 GLM-5.2 免费模型，已设置，为什么不能用，必须解决，0成本接单"

## 一、三层断链定位（实测）

| 层 | 状态 | 实测 |
|---|---|---|
| L1 NVIDIA 端点 | ✅ 健康 | `https://integrate.api.nvidia.com/v1/models` → HTTP 200，`z-ai/glm-5.2` 在册；无 key → 401 |
| L2 13460 代理池 | ✅ 已接线 | `/v1/models` 含 `z-ai/glm-5.2`（0 价），实测转发对话 HTTP 200 |
| L3 launch.ps1 注入 | ❌ 曾断 | 硬编码 deepseek-v4-flash ×5；根因 = `gc_room_agents` 表 claude/codex 仍绑 deepseek 配置集 |

## 二、根因一句话

**界面配置(provider) ≠ 房间绑定(gc_room_agents) ≠ launch.ps1 注入，三层各自为政**——config.json 早就配好 GLM provider，hermes 也切了，但 claude/codex 的房间绑定没切，新会话 launch.ps1 仍生成 deepseek。

## 三、修复动作（DeepSeek 零改动）

1. 备份 `hermes-web-ui.db.bak_glmswitch_*`
2. `UPDATE gc_room_agents SET provider='custom:nvidia-glm5.2', model='z-ai/glm-5.2' WHERE roomId='msormerbrbfg44' AND agent IN ('claude','codex')`
3. 三 Agent 绑定统一：hermes/claude/codex = custom:nvidia-glm5.2 / z-ai/glm-5.2

## 四、终验（双通过）

- GLM-5.2 经 13460 → HTTP 200，内容"OK"
- deepseek-v4-flash 回归 → HTTP 200（未破坏，可随时切回）

## 五、后续约定

- 切换模型必须三层对齐：config.json provider → DB 房间绑定 → 新会话 launch.ps1
- NVIDIA 免费层约 40 req/min 限速；GLM-5.2 文本/编程主力，看图用 Qwen3-VL-8B（Pro 解锁）
- 关联：[[codex_max防生成根防线_终验_20260813_1804]]（同类"配置脱节"教训）
