# codex guardianv2 config 解析报错修复 · 终验（2026-09-01）

> 归属：舰队运维 / 自我进化闭环
> 执行：汤小龙（Codex 分身，调用 1234）
> 关联：[[2026-08-31 Codex新版覆盖config守卫自愈复盘]]

## 一、报错与根因

- 报错：`ChatGPT can't load config.toml ... data did not match any variant of untagged enum FeatureToml in features.guardianv2`
- 根因：`config.toml` 的 `[features].guardianv2` 值不是合法枚举（常见为字符串/数字被误写入，应为布尔或直接删除）。
- 影响：Codex 解析配置失败，线程无法 resume。

## 二、处置结果

- 生效配置路径：`C:\Users\Administrator\.codex-orch\config.toml`
- 当前 `[features]` 段仅保留合法项：
  - `js_repl = false`
  - `image_generation = true`
  - `multi_agent = true`
- `guardianv2` 字段已不存在（无残留）。
- TOML 解析校验：`.codex-orch`、`.codex`、Orca 运行时 home 三份配置全部通过 `tomllib` 解析，无 `guardianv2`。

## 三、防复发红线

- `teamorouter_glm_proxy.py` 及现有脚本均不写入 `guardianv2`，外部脚本禁止触碰 Codex 内部特性字段。
- 再次出现该报错时，直接删除 `guardianv2` 行或写 `guardianv2 = false`，保存后完全退出 Codex 再重开线程。

## 四、验证

- 配置解析通过；桌面 Codex 进程已正常运行，各项目下线程可恢复。
