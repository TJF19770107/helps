---
title: VNPY Python 缺 _ssl 导致 Codex 代理崩
date: 2026-08-13
tags: [故障库, 运维, Python环境, Codex代理, _ssl, VNPY]
category: 舰队运维
故障等级: P0（阻断 Codex 全链路）
根因类型: Python 环境错乱（缺二进制绑定）
---

# VNPY Python 缺 _ssl 导致 Codex 代理崩

## 一、故障现象

- 桌面版 Codex 客户端持续 `Reconnecting...`，无法建连
- `lobster-cmd 状态` 显示：
  - ✅ 端口 15721: LISTENING
  - ❌ 端口 15730: 未监听
  - ❌ Anthropic 代理（15721）不通
  - ❌ Codex 代理 v8（15730）不通
- 手动 `python codex_tool_proxy.py` 报错：
  ```
  File "E:\VNPY\Lib\ssl.py", line 100, in <module>
      import _ssl             # if we can't import it, let the error propagate
  ModuleNotFoundError: No module named '_ssl'
  ```

## 二、根因定位

### 1. Python 环境错乱（真根因）

系统默认 `python` → `E:\VNPY\python.exe`（vnpy 量化环境）

`E:\VNPY\Lib\ssl.py` 是纯 Python 文件，但**缺少对应的 `_ssl.pyd` 二进制绑定** → `import ssl` 即崩 → Codex 代理（`codex_tool_proxy.py` 第 20 行 `import ssl`）启动即崩 → 15730 端口空转 → 桌面客户端 Reconnecting。

### 2. 两个 Python 的差异

| 维度 | `E:\VNPY\python.exe`（错） | `C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe`（对） |
|---|---|---|
| 用途 | vnpy 量化交易 | AGENTS.md 协议指定 |
| `_ssl.pyd` | ❌ 缺失 | ✅ OpenSSL 3.5.7 |
| `import ssl` | ❌ ModuleNotFoundError | ✅ OK |
| 启动 Codex 代理 | ❌ 即崩 | ✅ 5 秒内 LISTENING |

### 3. 链路图

```
schtasks "FleetGuardian_AutoStart"
   └─ schtasks 命令行用 "python"（系统默认 PATH）
      └─ E:\VNPY\python.exe（缺 _ssl）
         └─ codex_tool_proxy.py import ssl 崩
            └─ 15730 空转 → 桌面 Codex Reconnecting
```

## 三、修复过程（龙虾五步法）

| 步骤 | 内容 | 结果 |
|---|---|---|
| Step1 识别 | `lobster-cmd 状态` → 15730 未监听、双不通 | ✅ 定位 |
| Step2 映射 | 对照 AGENTS.md 自动恢复协议 + `## Codex max 防线` | ✅ 方案明确 |
| Step3 规划 | 用 workbuddy Python（ssl OK）拉起两代理，避开 VNPY 破 Python | ✅ 策略明确 |
| Step4 执行 | 拉起 15721 + 15730，curl health 双 ok | ✅ 修复完成 |
| Step5 沉淀 | 本文 + fleet_guardian.py 硬编码 + AGENTS.md 追加禁用条目 | ⏳ 进行中 |

### 修复验证

```
✅ 15721 LISTENING (PID 10844)  → health ok
✅ 15730 LISTENING (PID 172604) → health ok, upstream xiaomimimo
```

## 四、防复发（三道防线）

| # | 防线 | 落点 |
|---|---|---|
| 1 | `fleet_guardian.py` 硬编码 workbuddy Python 路径，禁止走系统默认 `python` | `fleet_guardian.py` 第 34 行 `PYTHON_EXE` |
| 2 | schtasks 任务命令行也必须指向 workbuddy Python（不能裸 `python`） | `schtasks /create` 注册命令 |
| 3 | AGENTS.md「自动恢复协议」追加明文禁用条目：禁止用 `E:\VNPY` 的 Python 启动 MCP 代理 | AGENTS.md 第 3-24 行段后 |

## 五、关键排查命令（复用）

```bash
# 1. 检查 15730 端口
netstat -ano | grep 15730

# 2. 验证当前默认 Python 是否缺 _ssl
python -c "import ssl; print(ssl.OPENSSL_VERSION)"
# 若报 ModuleNotFoundError: No module named '_ssl' → 命中本故障

# 3. 用 workbuddy Python 拉起 Codex 代理
"C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe" \
  "E:/龙虾AI主控中心/MCP服务/codex_tool_proxy.py"

# 4. 验证 health
curl -s http://127.0.0.1:15730/health
```

## 六、关联文档

- [[codex_max_防生成拦截根治_20260813]] — 同期另一根因（catalog max 档位）
- [[codex_max档位防复发根治_20260813]] — max 防复发三道防线
- [[龙虾舰队守护进程_系统性自愈方案]] — fleet_guardian.py 设计
- [[orca_fleet_orchestration_v1]] — 舰队编排 v1

## 七、四化校准

- **智能化**：守护进程自动检测 + 自动重启，无需人工干预
- **定制化**：本故障根因（VNPY Python 缺 _ssl）从订单运维逆向工程而来，蒸馏到此处
- **全自动化**：schtasks 开机自启 + guardian 30 秒巡检，全链路零人工
- **自我净化**：本次修复发现「fleet_guardian.py 已硬编码 Python 但 schtasks 任务可能裸调 python」的漏洞，已在防复发 #2 中落实
