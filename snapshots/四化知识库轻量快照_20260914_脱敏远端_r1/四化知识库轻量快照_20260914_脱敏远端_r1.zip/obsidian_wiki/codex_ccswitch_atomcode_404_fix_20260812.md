# Codex桌面版接入ATOM-Code DeepSeek-V4-Flash 404故障修复 · 2026-08-12

> **来源**：AtomCode 故障处置（企业微信群定制接单项目） | **分类**：系统自愈 · 协议兼容修复 | **状态**：ACTIVE
> **处置方法**：龙虾五步法 V3.0 · 全域模板

## 问题

- CC-Switch 检测：`ATOMCODE DEEPSEEK V4 20260812 检查失败: Not found (404)`
- Codex++ 调用上游 404；Hermes 群内此前还报过 `Connection error` / `timed out after 300s`

## 根因（双层）

1. **协议不兼容（本次主因）**：Codex 桌面版默认调用 OpenAI **Responses API `/v1/responses`**；本地代理 `atomcode_proxy.py` 仅实现 `/v1/chat/completions`，无 `/v1/responses` 端点 → 直接 404
2. **配置层放大**：CC-Switch「完整URL」模式只透传地址、**不做协议翻译**，Codex 的 `/responses` 请求原样打到代理即 404

## 修复方案（三层，均已实施或给出）

| 层 | 方案 | 状态 |
|----|------|------|
| 服务端 | `atomcode_proxy.py` 新增 `/v1/responses` 端点（`_do_responses()`：instructions+input 翻译→复用 call_atomcode→Responses 兼容响应，含 SSE 流式事件） | ✅ 已实施 |
| 配置层 | CC-Switch 关闭「完整URL」，开启 `Chat-Completions → Responses 转换` 协议翻译开关 | 📋 备用方案 |
| 兜底层 | 直连 AtomGit 云端 `https://llm-api.atomgit.com/v1`（PAT `r_rKi_zcMaxjN7L8sEywRVYo`） | 📋 兜底 |

## 验证快照（2026-08-12 实测）

| 端点 | 结果 |
|------|------|
| `GET /v1/models` | ✅ 返回 deepseek-v4-flash + Qwen3-VL-8B |
| `POST /v1/chat/completions` | ✅ `"content": "OK"` |
| `POST /v1/responses` 非流式 | ✅ `"object":"response"` + `output_text="OK"` |
| `POST /v1/responses` 流式 SSE | ✅ 9 事件 + `[DONE]` |

代理当前由计划任务 `AtomCodeProxy` 托管（每日 23:59 运行，hermes venv 完整 Python），PID 124364 监听 13460。

## 四化校准

| 维度 | 状态 | 说明 |
|------|------|------|
| 智能化 | ✅ | Agent 自主定位协议不兼容根因并实施服务端修复 |
| 定制化 | ✅ | 针对 Codex Responses API 形态定制 `_do_responses()`（input 字符串/数组两种形态） |
| 全自动化 | ✅ | 计划任务每日自愈 + 文档化 SOP 供 Marvis 自动读取 |
| 自我进化 | ✅ | SOP 写入技能库 + Obsidian，同类故障免重复排查 |

## 关联

- [[codex_ccswitch_atomcode_fix|技能库完整SOP]]（`E:\龙虾AI主控中心\技能库\codex_ccswitch_atomcode_fix.md`）
- [[CNB-DeepSeek-V4-Flash-0731]]
- [[codex_catalog_max_fix_20260810]]
- 代理脚本：`E:\龙虾AI主控中心\我的AI分身\AtomCode\scripts\atomcode_proxy.py`

## 待办

- [ ] Codex++ 启动 Codex 桌面选中新供应商，人工确认对话返回（GUI 层验证）

## 追加修正记录（2026-08-12 21:40）

**Codex 桌面版指向修正**：`.codex/config.toml` 的 `base_url` 原指向 `http://127.0.0.1:15721/v1`（CC-Switch 管理工具端口，实测 `/v1/responses`、`/v1/chat/completions` 均返回 `not found`，**不是 OpenAI 兼容网关**），已改为 `http://127.0.0.1:13460/v1`（ATOM-Code 代理），provider 名 `xiaomi_mimo` → `atomcode-v4-local`。备份：`config.toml.bak_20260812_13460fix`。实测 Codex CLI v0.133.0 `exec` 调用返回 `OK` ✅。

> 🔑 **避坑**：CC-Switch（cc-switch.exe，端口 15721）只是配置管理工具，不做 API 转发；Codex 桌面版 config.toml 必须直连真实代理 13460。
