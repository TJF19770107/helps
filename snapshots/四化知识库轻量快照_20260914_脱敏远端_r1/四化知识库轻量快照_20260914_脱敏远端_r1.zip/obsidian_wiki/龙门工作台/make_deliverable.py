# -*- coding: utf-8 -*-
"""
龙门 · 客户交付单生成器（S2）
输入：一份案例 JSON（脱敏输入，禁止姓名/考生号/联系方式）
输出：单文件 HTML 交付单，可直接发给家长；含诊断卡 / 三层路线 / 双周计划 / 真实梯度清单 / 合规与免责

用法：
  python make_deliverable.py case_demo.json --out .
"""
import argparse, datetime, json, os, sys

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from longmen_engine import gradient   # noqa: E402

FORBIDDEN = ["姓名", "考生号", "准考证", "电话", "手机", "身份证", "微信", "住址", "学校", "班级"]

TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>龙门 · 学业规划与志愿决策交付单（{code}）</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#f5f7fa;color:#111827;font:15px/1.75 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}}
.wrap{{max-width:940px;margin:0 auto;padding:24px 18px 60px}}
header{{background:linear-gradient(135deg,#1e3a8a,#0f766e);color:#fff;border-radius:14px;padding:26px 26px 20px}}
header h1{{margin:0 0 6px;font-size:24px;letter-spacing:.5px}}
header p{{margin:0;opacity:.9;font-size:13.5px}}
.tags{{margin-top:12px;display:flex;gap:8px;flex-wrap:wrap}}
.tag{{background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.28);padding:3px 10px;border-radius:999px;font-size:12px}}
section{{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px 22px;margin-top:16px}}
h2{{font-size:16.5px;margin:0 0 12px;padding-left:10px;border-left:4px solid #0f766e}}
h3{{font-size:14.5px;margin:16px 0 8px;color:#1e3a8a}}
table{{width:100%;border-collapse:collapse;font-size:13.5px}}
th,td{{border:1px solid #e5e7eb;padding:7px 9px;text-align:left}}
th{{background:#f3f4f6;font-weight:600}}
td.num,th.num{{text-align:right;font-variant-numeric:tabular-nums}}
.pill{{display:inline-block;padding:1px 9px;border-radius:999px;font-size:12px;font-weight:600}}
.p-chong{{background:#ede9fe;color:#5b21b6}} .p-wen{{background:#dbeafe;color:#1e40af}} .p-bao{{background:#dcfce7;color:#166534}}
.kv{{display:grid;grid-template-columns:120px 1fr;gap:6px 12px;font-size:14px}}
.kv b{{color:#374151;font-weight:600}}
.warn{{background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:12px 14px;font-size:13.5px;color:#7f1d1d}}
.info{{background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:12px 14px;font-size:13.5px;color:#0c4a6e}}
.ok{{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:12px 14px;font-size:13.5px;color:#14532d}}
.mono{{font-family:ui-monospace,Consolas,monospace;font-size:12.5px}}
ol,ul{{margin:6px 0 6px 20px;padding:0}} li{{margin:3px 0}}
footer{{margin-top:22px;font-size:12.5px;color:#6b7280;text-align:center;line-height:1.9}}
</style></head><body><div class="wrap">
<header>
  <h1>龙门 · 高三学业规划与志愿决策交付单</h1>
  <p>案号 {code}　·　交付日期 {date}　·　适用范围：{province} {track}（{exam_year} 届）</p>
  <div class="tags">
    <span class="tag">三层归因诊断</span><span class="tag">知识依赖断点回溯</span>
    <span class="tag">双轨并行</span><span class="tag">间隔复现</span>
    <span class="tag">位次梯度法</span><span class="tag">官方公开底库</span>
  </div>
</header>

<section>
  <h2>一、考生基本情况（已脱敏）</h2>
  <div class="kv">
    <b>届别 / 省份</b><span>{exam_year} 届　·　{province}　·　{track}</span>
    <b>选考科目</b><span>{subjects}</span>
    <b>当前位次</b><span>{exam_rank}　（对应当年约 {exam_score} 分）</span>
    <b>服务内容</b><span>{service}</span>
  </div>
</section>

<section>
  <h2>二、学情诊断卡（三层归因）</h2>
  <h3>① 表征层 · 具体错误现象</h3><p>{symptom}</p>
  <h3>② 归因层 · 四类根源判断</h3><p>{cause}</p>
  <h3>③ 溯源层 · 知识依赖链断点</h3><p>{root}</p>
  <div class="ok"><b>诊断结论：补差起点 = {start}</b><br>{start_why}</div>
</section>

<section>
  <h2>三、补差路线（地基 → 专项 → 拓展）</h2>
  <table><thead><tr><th style="width:90px">层级</th><th>内容</th><th style="width:150px">验证标准</th></tr></thead><tbody>
    <tr><td><b>地基层</b></td><td>{foundation}</td><td>单独测试正确率 <b>≥90%</b> 才进入下一层</td></tr>
    <tr><td><b>专项层</b></td><td>{special}</td><td>变式题正确率 <b>≥80%</b></td></tr>
    <tr><td><b>拓展层</b></td><td>{expand}</td><td>综合题 <b>≥70%</b> 且能口述解题路径</td></tr>
  </tbody></table>
  <div class="info" style="margin-top:12px">
    <b>间隔复现纪律</b>：第 <b>1 / 3 / 7 / 21</b> 天各复现一次，每次 3 题、≤10 分钟。<br>
    第 7 天复现正确率 <b>&lt;80%</b> ⇒ 判定"只是讲懂了"，回退一层重练。
  </div>
</section>

<section>
  <h2>四、双轨并行周计划（补差不让位新课）</h2>
  <table><thead><tr><th style="width:70px">周次</th><th>补差任务（每天 20~25 分钟）</th><th>新课同步任务</th><th style="width:130px">本周末验证</th></tr></thead><tbody>
{plan_rows}
  </tbody></table>
  <p class="mono" style="color:#6b7280;margin-top:8px">纪律：补差固定时长，不占用新课作业时间；每个节点用 3~5 题验证——"讲完了"≠"补完了"。</p>
</section>

<section>
  <h2>五、志愿梯度清单（真实官方底库 · 位次法）</h2>
  <div class="warn">
    <b>★ 请先读这段再使用清单</b><br>
    ① 本清单基于 <b>官方公开数据</b>（省教育考试院一分一段表 + 本科普通批投档线），<b>不是录取预测</b>；<br>
    ② 官方数据实测：同一院校专业组两年投档线变动<b>绝对值均值 11.11 分</b>、最大达 <b>171 分</b>；任何方法都无法把误差压进 ±3 分（命中率约 29%）——所以本清单按 <b>位次区间与档位</b> 给出，不承诺具体分数；<br>
    ③ 标注「⚠高波动」的专业组，务必另查 <b>招生计划数</b> 与 <b>专业组构成</b> 是否变化；<br>
    ④ 最终填报以官方《招生专业目录》《招生章程》与省级填报系统为准。
  </div>
  <p style="margin:12px 0 8px"><b>考生位次 {grad_rank}</b>　·　百分位 {grad_pct}%　·　参考年 {grad_ref}　目标年 {grad_cur}　·　系数：冲 R/N&lt;0.95 ｜ 稳 0.95~1.20 ｜ 保 R/N&gt;1.20</p>
  <table><thead><tr><th style="width:60px">档位</th><th>院校</th><th style="width:46px">组</th><th>选考要求</th><th class="num">参考年分</th><th class="num">当量位次</th><th class="num">R/N</th><th class="num">次年实际</th><th class="num">两年变动</th></tr></thead><tbody>
{grad_rows}
  </tbody></table>
  <div class="info" style="margin-top:12px">
    <b>配比建议</b>：冲 20~30% ／ 稳 40~50% ／ 保 30%（本科普通批共 30 个院校专业组志愿）。<br>
    <b>保底纪律</b>：保底档必须"专业可接受"才算真保底；出现<b>梯度断档</b>或<b>无保底</b>是最高危情形。
  </div>
</section>

<section>
  <h2>六、家庭约束（填报前必须确认的三件事）</h2>
  <div class="kv">
    <b>地域可接受</b><span>{c_area}</span>
    <b>费用上限</b><span>{c_fee}</span>
    <b>专业可接受</b><span>{c_major}</span>
  </div>
</section>

<section>
  <h2>七、合规与免责声明</h2>
  <ul>
    <li>本交付物属 <b>学业规划咨询与志愿决策信息整理</b>，<b>不提供</b>学科类培训、不授课、不承诺录取结果。</li>
    <li>本服务<b>不代替</b>考生操作官方志愿填报系统，<b>不索取</b>考生号、密码及任何证件信息。</li>
    <li>数据仅使用 <b>省级招生考试机构与高校官网公开发布</b>的信息；不声称拥有内部数据或独家数据。</li>
    <li>本服务<b>不声称</b>"高考志愿规划师"等职业资格；<b>不使用</b>"阳光高考""阳光志愿"等官方名称。</li>
    <li>所有结论为 <b>启发式参考区间</b>，最终录取结果由省级招生考试机构与高校按官方规则确定。</li>
    <li>案例以代号记录，不含姓名与个人信息。</li>
  </ul>
</section>

<footer>
  龙门 · 高三陪跑工作台　|　案号 {code}　|　生成于 {now}<br>
  底库来源：{source}<br>
  本文件为单文件离线交付物，数据不出本机。
</footer>
</div></body></html>
"""


def _check_privacy(obj, path=""):
    hits = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if any(f in str(k) for f in FORBIDDEN):
                hits.append(f"{path}.{k}")
            hits += _check_privacy(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            hits += _check_privacy(v, f"{path}[{i}]")
    return hits


def build(case, out_dir):
    hits = _check_privacy(case)
    if hits:
        raise SystemExit(f"❌ 隐私校验未通过，检测到敏感字段：{hits}（禁止姓名/考生号/联系方式）")

    g = case.get("gradient", {})
    grad = gradient(int(g.get("rank", case["exam_rank"])), subject_filter=g.get("subject"),
                    top_n=int(g.get("top", 12)), y_ref=int(g.get("ref_year", 2025)),
                    y_cur=int(g.get("cur_year", 2026)))
    rows = []
    for k, cls in (("冲", "p-chong"), ("稳", "p-wen"), ("保", "p-bao")):
        for r in grad["buckets"][k]:
            dv = (r["s_cur"] - r["s_ref"]) if r["s_cur"] else None
            warn = ' <b style="color:#b91c1c">⚠高波动</b>' if (dv is not None and abs(dv) >= 20) else ""
            rows.append(
                f'<tr><td><span class="pill {cls}">{k}</span></td><td>{r["school"]}{warn}</td>'
                f'<td>{r["group"]}</td><td>{r["subject_req"]}</td>'
                f'<td class="num">{r["s_ref"]}</td><td class="num">{r["r_eq"]:,}</td>'
                f'<td class="num">{r["ratio"]:.3f}</td>'
                f'<td class="num">{r["s_cur"] if r["s_cur"] else "—"}</td>'
                f'<td class="num">{"—" if dv is None else (("+" if dv > 0 else "") + str(dv))}</td></tr>')

    plan = case.get("plan_weeks", [])
    plan_rows = "\n".join(
        f'    <tr><td>第 {p.get("week")} 周</td><td>{p.get("makeup", "")}</td>'
        f'<td>{p.get("school", "")}</td><td>{p.get("verify", "")}</td></tr>' for p in plan)
    if not plan_rows:
        plan_rows = '    <tr><td colspan="4" style="color:#9ca3af">（未填写周计划）</td></tr>'

    c = case.get("family_constraints", {})
    html = TEMPLATE.format(
        code=case.get("case_code", "LM-XXXX"), date=case.get("date", ""),
        province=case.get("province", ""), track=case.get("track", ""),
        exam_year=case.get("exam_year", ""),
        subjects="、".join(case.get("subject_choice", [])) or "（未填）",
        exam_rank=f'{case.get("exam_rank", 0):,}', exam_score=case.get("exam_score", "—"),
        service=case.get("service", ""),
        symptom=case.get("diagnosis", {}).get("症状", "（未填）"),
        cause=case.get("diagnosis", {}).get("归因", "（未填）"),
        root=case.get("diagnosis", {}).get("溯源", "（未填）"),
        start=case.get("diagnosis", {}).get("起点", "（未填）"),
        start_why=case.get("diagnosis", {}).get("起点理由", ""),
        foundation=case.get("route", {}).get("地基", ""),
        special=case.get("route", {}).get("专项", ""),
        expand=case.get("route", {}).get("拓展", ""),
        plan_rows=plan_rows,
        grad_rank=f'{grad["考生位次"]:,}', grad_pct=grad["百分位"],
        grad_ref=grad["参考年"], grad_cur=grad["目标年"],
        grad_rows="\n".join(rows),
        c_area=c.get("地域", "（待确认）"), c_fee=c.get("费用", "（待确认）"),
        c_major=c.get("专业", "（待确认）"),
        now=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        source="省级招生考试机构官方公开文件（一分一段表 + 本科普通批投档线），已记录 sha256",
    )
    os.makedirs(out_dir, exist_ok=True)
    p = os.path.join(out_dir, f'龙门_交付单_{case.get("case_code", "LM-XXXX")}.html')
    open(p, "w", encoding="utf-8").write(html)
    return p, len(rows), grad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case")
    ap.add_argument("--out", default=".")
    a = ap.parse_args()
    case = json.load(open(a.case, encoding="utf-8"))
    p, n, grad = build(case, a.out)
    print(f"OK 交付单 -> {p}")
    print(f"   梯度行数 {n}（冲 {len(grad['buckets']['冲'])} / 稳 {len(grad['buckets']['稳'])} / 保 {len(grad['buckets']['保'])}）")
    print(f"   考生位次 {grad['考生位次']:,}　百分位 {grad['百分位']}%")
    print(f"   隐私校验：通过（无姓名/考生号/联系方式字段）")


if __name__ == "__main__":
    main()
