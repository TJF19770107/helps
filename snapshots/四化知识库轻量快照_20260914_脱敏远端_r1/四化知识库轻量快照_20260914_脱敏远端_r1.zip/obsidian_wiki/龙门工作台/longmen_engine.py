# -*- coding: utf-8 -*-
"""
龙门 · 志愿梯度引擎（S0.5 核心）
==================================================
输入：省考试院官方「一分一段表」+「本科普通批投档线」两份原件（已解析为 JSON）
输出：
  1) backtest  回测：用往年数据预测次年投档线，四方法对照（含最大误差样本排查）
  2) gradient  对给定考生位次，输出冲/稳/保三档真实梯度清单
  3) webtable  导出可内嵌进单文件工作台的精简数据段（真实底库）

免责：输出为**启发式参考区间，不是录取预测模型**；最终以官方政策与填报系统为准。
"""
import argparse, csv, json, os, sys

sys.stdout.reconfigure(encoding="utf-8")
DATA = os.path.dirname(os.path.abspath(__file__))
CONTROL = {2025: 430, 2026: 429}   # 本科普通批录取控制分数线（官方公布）


# ---------- 数据层 ----------
def _lbl_range(label):
    """'100-109' -> (100,109)；'697' -> (697,697)；'698分以上' -> (698,750)"""
    label = label.replace("分以上", "").strip()
    if "-" in label:
        a, b = label.split("-")
        return int(a), int(b)
    return int(label), int(label)


class RankTable:
    """分数 ↔ 位次 双向换算（位次口径 = 该分数对应的累计人数）"""

    def __init__(self, path):
        d = json.load(open(path, encoding="utf-8"))
        self.meta = d["meta"]
        self.year = int(self.meta["year"])
        self.total = self.meta["validation"]["stats"]["total_published"]
        self.rows = sorted(((*_lbl_range(r["score_label"]), r["cumulative"]) for r in d["rows"]),
                           key=lambda x: x[0])

    def score_to_rank(self, score):
        for lo, hi, cum in self.rows:
            if lo <= score <= hi:
                return cum
        return self.rows[0][2] if score < self.rows[0][0] else self.rows[-1][2]

    def rank_to_score(self, rank):
        for lo, hi, cum in self.rows:
            if cum <= rank:
                return lo
        return self.rows[-1][0]

    def equivalent_rank(self, rank_other, total_other=None):
        return (rank_other / (total_other or self.total)) * self.total


def load_lines(year, batch="本科普通批"):
    d = json.load(open(os.path.join(DATA, f"北京_{year}_{batch}_lines.json"), encoding="utf-8"))
    return d["meta"], d["rows"]


def school_min(rows):
    out = {}
    for r in rows:
        c = r["school_code"]
        if c not in out or r["admit_score"] < out[c]["admit_score"]:
            out[c] = r
    return out


# ---------- 回测层 ----------
def backtest(y_prev=2025, y_cur=2026, batch="本科普通批"):
    t_prev = RankTable(os.path.join(DATA, f"北京_{y_prev}_综合_本科_rank_db.json"))
    t_cur = RankTable(os.path.join(DATA, f"北京_{y_cur}_综合_本科_rank_db.json"))
    _, rows_prev = load_lines(y_prev, batch)
    _, rows_cur = load_lines(y_cur, batch)
    cur_by_key = {(r["school_code"], r["group"]): r for r in rows_cur}
    cur_by_code = school_min(rows_cur)
    line_prev, line_cur = CONTROL[y_prev], CONTROL[y_cur]

    def _pairs(level):
        if level == "group":
            return [(r, cur_by_key[(r["school_code"], r["group"])]) for r in rows_prev
                    if (r["school_code"], r["group"]) in cur_by_key]
        return [(r, cur_by_code[c]) for c, r in school_min(rows_prev).items() if c in cur_by_code]

    def _eval(level):
        errs = {k: [] for k in "ABCD"}
        rank_errs = {k: [] for k in "ABCD"}
        detail = []
        for rp, rc in _pairs(level):
            s_prev, actual = rp["admit_score"], rc["admit_score"]
            r_prev = t_prev.score_to_rank(s_prev)
            r_eq = t_cur.equivalent_rank(r_prev, t_prev.total)
            s_d = line_cur + (s_prev - line_prev)
            preds = {                                  # 方法 -> (预测分, 预测位次)
                "A": (s_prev, t_cur.score_to_rank(s_prev)),
                "B": (t_cur.rank_to_score(r_eq), r_eq),
                "C": (t_cur.rank_to_score(r_prev), r_prev),
                "D": (round(s_d), t_cur.score_to_rank(s_d)),
            }
            r_actual = t_cur.score_to_rank(actual)
            for k, (ps, prk) in preds.items():
                errs[k].append(abs(ps - actual))
                rank_errs[k].append(abs(prk - r_actual))
            detail.append({
                "school": rp["school"], "group": rp["group"], "subject": rp["subject_req"],
                "s_prev": s_prev, "r_prev": r_prev, "actual": actual, "r_actual": r_actual,
                "err_A": abs(s_prev - actual), "err_B": abs(preds["B"][0] - actual),
                "err_C": abs(preds["C"][0] - actual), "err_D": abs(preds["D"][0] - actual),
            })
        n = len(errs["A"]) or 1
        names = {"A": "分数直搬", "B": "位次当量", "C": "位次直搬", "D": "线差法"}
        out = {"level": level, "n": len(errs["A"])}
        for k in "ABCD":
            e, re_ = errs[k], rank_errs[k]
            out[k] = {"name": names[k],
                      "mae": round(sum(e) / n, 2),
                      "median": round(sorted(e)[len(e) // 2], 1),
                      "max": max(e),
                      "hit3": round(sum(1 for x in e if x <= 3) / n * 100, 1),
                      "hit5": round(sum(1 for x in e if x <= 5) / n * 100, 1),
                      "hit10": round(sum(1 for x in e if x <= 10) / n * 100, 1),
                      "rank_mae": int(sum(re_) / n),
                      "rank_hit2000": round(sum(1 for x in re_ if x <= 2000) / n * 100, 1)}
        out["best"] = min("ABCD", key=lambda k: out[k]["mae"])
        out["best_by_rank"] = min("ABCD", key=lambda k: out[k]["rank_mae"])
        return out, detail

    gl, gdet = _eval("group")
    sl, _ = _eval("school")
    gdet.sort(key=lambda d: -d["err_A"])
    return {
        "meta": {"province": "北京", "prev_year": y_prev, "cur_year": y_cur, "batch": batch,
                 "total_prev": t_prev.total, "total_cur": t_cur.total,
                 "growth_pct": round((t_cur.total - t_prev.total) / t_prev.total * 100, 2),
                 "control_line": {"prev": line_prev, "cur": line_cur},
                 "sources": [t_prev.meta.get("source_url", ""), t_cur.meta.get("source_url", "")],
                 "note": "回测仅检验换算方法稳定性，不代表对个体的录取预测；院校专业组构成逐年变化，组级匹配存在口径漂移。"},
        "group_level": gl, "school_level": sl, "worst_group_cases": gdet[:10],
    }


# ---------- 梯度层 ----------
def gradient(rank, y_ref=2025, y_cur=2026, batch="本科普通批",
             f_chong=0.95, f_bao=1.20, subject_filter=None, top_n=25):
    t_ref = RankTable(os.path.join(DATA, f"北京_{y_ref}_综合_本科_rank_db.json"))
    t_cur = RankTable(os.path.join(DATA, f"北京_{y_cur}_综合_本科_rank_db.json"))
    _, rows_ref = load_lines(y_ref, batch)
    _, rows_cur = load_lines(y_cur, batch)
    cur_by_key = {(r["school_code"], r["group"]): r for r in rows_cur}

    buckets = {"冲": [], "稳": [], "保": []}
    for r in rows_ref:
        if subject_filter and subject_filter not in r["subject_req"]:
            continue
        rk = t_ref.score_to_rank(r["admit_score"])
        rk_eq = t_cur.equivalent_rank(rk, t_ref.total)
        ratio = rk_eq / rank
        cur = cur_by_key.get((r["school_code"], r["group"]))
        rec = {"school_code": r["school_code"], "school": r["school"],
               "group": r["group"], "subject_req": r["subject_req"],
               "s_ref": r["admit_score"], "r_ref": rk,
               "r_eq": int(rk_eq), "ratio": round(ratio, 3),
               "s_cur": cur["admit_score"] if cur else None}
        (buckets["冲"] if ratio < f_chong else buckets["稳"] if ratio <= f_bao else buckets["保"]).append(rec)

    buckets["冲"].sort(key=lambda x: -x["ratio"])
    buckets["稳"].sort(key=lambda x: x["ratio"])
    buckets["保"].sort(key=lambda x: x["ratio"])
    for k in buckets:
        buckets[k] = buckets[k][:top_n]
    return {"考生位次": rank, "百分位": round(rank / t_cur.total * 100, 2),
            "当年总人数": t_cur.total, "参考年": y_ref, "目标年": y_cur,
            "系数": {"冲": f"R/N<{f_chong}", "稳": f"{f_chong}~{f_bao}", "保": f"R/N>{f_bao}"},
            "配比建议": "冲 20~30% / 稳 40~50% / 保 30%",
            "buckets": buckets,
            "免责": "启发式参考区间，非录取预测；须结合《招生专业目录》《招生章程》与官方填报系统最终确认。"}


# ---------- 工作台内嵌数据段 ----------
def webtable(y_ref=2025, y_cur=2026, batch="本科普通批", out="."):
    """产出精简数据段：位次表（两年）+ 投档线（两年，含各位次）"""
    tts, lines = {}, {}
    for y in (y_ref, y_cur):
        t = RankTable(os.path.join(DATA, f"北京_{y}_综合_本科_rank_db.json"))
        tts[y] = {"total": t.total, "pairs": [[lo if lo == hi else lo, cum] for lo, hi, cum in t.rows]}
        _, rows = load_lines(y, batch)
        lines[y] = [[r["school_code"], r["school"], r["group"], r["subject_req"],
                     r["admit_score"], t.score_to_rank(r["admit_score"])] for r in rows]
    payload = {"province": "北京", "batch": batch, "ref": y_ref, "cur": y_cur,
               "ranktable": tts, "lines": lines,
               "control": {str(y_ref): CONTROL[y_ref], str(y_cur): CONTROL[y_cur]},
               "source": "北京教育考试院 官方公开数据（一分一段表 + 本科普通批投档线）"}
    js = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    p = os.path.join(out, "龙门_真实底库_内嵌数据段.js")
    open(p, "w", encoding="utf-8").write("const LM_DATA=" + js + ";\n")
    print(f"  webtable 输出 -> {p}")
    print(f"  位次表点位数 {sum(len(v['pairs']) for v in tts.values())}；投档线行数 "
          f"{sum(len(v) for v in lines.values())}；体积 {round(len(js)/1024,1)} KB")


# ---------- CLI ----------
def _print_backtest(b):
    m = b["meta"]
    print("=" * 78)
    print(f"  龙门 S0.5 · 四方法回测  用 {m['prev_year']} 官方数据预测 {m['cur_year']} 投档线")
    print("=" * 78)
    print(f"  考生总量 {m['total_prev']:,} → {m['total_cur']:,} ({m['growth_pct']:+}%)"
          f"　控制线 {m['control_line']['prev']} → {m['control_line']['cur']}")
    for key, label in (("group_level", "院校专业组级"), ("school_level", "院校级(取最低组)")):
        lv = b[key]
        print(f"\n  ── {label}　可比对 {lv['n']} 条")
        print(f"     {'方法':<9}{'MAE分':>7}{'中位':>6}{'≤3分':>7}{'≤5分':>7}{'≤10分':>7}{'位次MAE':>10}{'位次≤2000':>10}")
        for k in "ABCD":
            d = lv[k]
            star = " ★" if k == lv["best"] else (" ☆" if k == lv["best_by_rank"] else "  ")
            print(f"     {d['name']:<9}{d['mae']:>7}{d['median']:>6}{d['hit3']:>6}%{d['hit5']:>6}%"
                  f"{d['hit10']:>6}%{d['rank_mae']:>10,}{d['rank_hit2000']:>9}%{star}")
        print(f"     → 分数口径最优 {lv[lv['best']]['name']}；位次口径最优 {lv[lv['best_by_rank']]['name']}")
    print("\n  ── 组级最大误差样本（前 6，用于判断是数据问题还是真实波动）")
    for d in b["worst_group_cases"][:6]:
        print(f"     {d['school'][:16]:<17}组{d['group']} {d['subject'][:10]:<11}"
              f"25年{d['s_prev']:>4} → 26实际{d['actual']:>4}　A误差{d['err_A']:>4} B误差{d['err_B']:>4}")
    print(f"\n  {m['note']}")


def _print_gradient(r, y_ref, y_cur):
    print("=" * 78)
    print(f"  龙门 · 志愿梯度清单（考生位次 {r['考生位次']:,}，百分位 {r['百分位']}%）")
    print("=" * 78)
    for k in ("冲", "稳", "保"):
        lst = r["buckets"][k]
        print(f"\n  【{k}】{r['系数'][k]}　共 {len(lst)} 条（清单已截断显示）")
        print(f"  {'院校':<19}{'组':<4}{'选考':<13}{f'{y_ref}分':>6}{'当量位次':>10}{'R/N':>7}{f'{y_cur}实际':>8}")
        for rec in lst[:8]:
            print(f"  {rec['school'][:18]:<19}{rec['group']:<4}{rec['subject_req'][:12]:<13}"
                  f"{rec['s_ref']:>6}{rec['r_eq']:>10,}{rec['ratio']:>7}"
                  f"{(rec['s_cur'] if rec['s_cur'] else '-'):>8}")
    print(f"\n  配比建议：{r['配比建议']}")
    print(f"  {r['免责']}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("backtest").add_argument("--out", default=".")
    g = sub.add_parser("gradient")
    g.add_argument("--rank", type=int, required=True)
    g.add_argument("--subject", default=None)
    g.add_argument("--top", type=int, default=25)
    g.add_argument("--out", default=".")
    sub.add_parser("webtable").add_argument("--out", default=".")
    a = ap.parse_args()

    if a.cmd == "backtest":
        r = backtest()
        jp = os.path.join(a.out, "龙门_回测报告.json")
        json.dump(r, open(jp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        _print_backtest(r)
        print(f"  JSON -> {jp}")
    elif a.cmd == "gradient":
        r = gradient(a.rank, subject_filter=a.subject, top_n=a.top)
        cp = os.path.join(a.out, f"龙门_梯度清单_位次{a.rank}.csv")
        with open(cp, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["档位", "院校代码", "院校名称", "专业组", "选考要求",
                        "参考年分", "参考年位次", "当量位次", "R/N", "目标年实际分"])
            for k in ("冲", "稳", "保"):
                for rec in r["buckets"][k]:
                    w.writerow([k, rec["school_code"], rec["school"], rec["group"],
                                rec["subject_req"], rec["s_ref"], rec["r_ref"],
                                rec["r_eq"], rec["ratio"], rec["s_cur"]])
        _print_gradient(r, r["参考年"], r["目标年"])
        print(f"  CSV -> {cp}")
    else:
        webtable(out=a.out)


if __name__ == "__main__":
    main()
