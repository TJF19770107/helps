#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
龙门 · 高考志愿决策 MCP Server（S1.5）
================================================
把「真实官方底库 + 位次当量换算 + 冲稳保梯度 + 回测可信度 + 案例自迭代」
封装为 MCP 工具，供 ORCA 舰队 / WorkBuddy / 任意 MCP 客户端直接调用。

- 纯标准库实现（无需 pip 安装任何依赖）
- 传输：stdio（JSON-RPC 2.0，MCP protocol 2024-11-05）
- 数据：省级招生考试机构官方公开文件解析产物（零采购成本）

合规声明：输出为启发式参考区间，不是录取预测；不提供录取承诺；
最终以官方政策与填报系统为准；不索取考生号/密码，案例仅用代号。
"""
import json
import os
import sys

PROTOCOL = "2024-11-05"
SERVER_INFO = {"name": "longmen-gaokao", "version": "1.0.0"}

_HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATA_DIR = os.environ.get(
    "LONGMEN_DATA_DIR",
    os.path.join(os.path.dirname(_HERE), "outputs", "s0_data"),
)
DATA_DIR = DEFAULT_DATA_DIR
PROVINCE = os.environ.get("LONGMEN_PROVINCE", "北京")
BATCH = os.environ.get("LONGMEN_BATCH", "本科普通批")
CASE_FILE = os.environ.get("LONGMEN_CASE_FILE", os.path.join(DATA_DIR, "longmen_cases.json"))

# ---------------- 数据层 ----------------
_cache = {}


def _load_json(path):
    if path not in _cache:
        with open(path, encoding="utf-8") as f:
            _cache[path] = json.load(f)
    return _cache[path]


def _lbl_range(label):
    label = label.replace("分以上", "").strip()
    if "-" in label:
        a, b = label.split("-")
        return int(a), int(b)
    return int(label), int(label)


class RankTable:
    def __init__(self, year):
        d = _load_json(os.path.join(DATA_DIR, f"{PROVINCE}_{year}_综合_本科_rank_db.json"))
        self.year = year
        self.meta = d["meta"]
        self.total = self.meta["validation"]["stats"]["total_published"]
        self.rows = sorted(((*_lbl_range(r["score_label"]), r["cumulative"]) for r in d["rows"]),
                           key=lambda x: x[0])

    def score_to_rank(self, score):
        for lo, hi, cum in self.rows:
            if lo <= score <= hi:
                return cum
        return self.rows[0][2] if score < self.rows[0][0] else self.rows[-1][2]

    def rank_to_score(self, rank):
        for lo, hi, cum in self.rows:
            if cum <= rank:
                return lo
        return self.rows[-1][0]


def _table(year):
    key = ("rank", year)
    if key not in _cache:
        _cache[key] = RankTable(year)
    return _cache[key]


def _lines(year):
    key = ("lines", year)
    if key not in _cache:
        _cache[key] = _load_json(os.path.join(DATA_DIR, f"{PROVINCE}_{year}_{BATCH}_lines.json"))
    return _cache[key]


def available_years():
    ys = []
    for f in os.listdir(DATA_DIR):
        if f.startswith(f"{PROVINCE}_") and f.endswith(f"_{BATCH}_lines.json"):
            try:
                ys.append(int(f.split("_")[1]))
            except Exception:
                pass
    return sorted(ys)


def _pick_years(ref=None, cur=None):
    ys = available_years()
    if not ys:
        raise RuntimeError("未找到任何投档线底库，请先运行 parse_admission_lines.py")
    cur = cur or ys[-1]
    ref = ref or (ys[-2] if len(ys) >= 2 else ys[-1])
    return ref, cur


# ---------------- 业务层 ----------------
def health():
    ys = available_years()
    out = {"province": PROVINCE, "batch": BATCH, "data_dir": DATA_DIR,
           "years": ys, "tables": []}
    for y in ys:
        t = _table(y)
        _d = _lines(y)
        meta, rows = _d["meta"], _d["rows"]
        out["tables"].append({
            "year": y, "total_published": t.total,
            "rank_rows": len(t.rows), "line_rows": len(rows),
            "schools": len({r["school_code"] for r in rows}),
            "score_min": min(r["admit_score"] for r in rows),
            "score_max": max(r["admit_score"] for r in rows),
            "source": meta.get("source", ""), "url": meta.get("url", ""),
            "sha256": (meta.get("source_sha256") or "")[:32],
        })
    return out


def score_to_rank(year, score):
    t = _table(year)
    r = t.score_to_rank(score)
    return {"year": year, "score": score, "rank": r,
            "percentile": round(r / t.total * 100, 3), "total_published": t.total}


def rank_to_score(year, rank):
    t = _table(year)
    s = t.rank_to_score(rank)
    return {"year": year, "rank": rank, "score": s,
            "percentile": round(rank / t.total * 100, 3), "total_published": t.total}


def equivalent_rank(rank, from_year, to_year):
    a, b = _table(from_year), _table(to_year)
    eq = round(rank / a.total * b.total)
    return {"from": {"year": from_year, "rank": rank, "total": a.total,
                     "percentile": round(rank / a.total * 100, 3)},
            "to": {"year": to_year, "rank": eq, "total": b.total,
                   "score": b.rank_to_score(eq)},
            "delta_rank": eq - rank,
            "rule": "位次百分比 = 位次 ÷ 当年已发布总人数；等效位次 = 百分比 × 目标年总人数"}


def volatility(ref_year=None, cur_year=None, min_abs_delta=0, top=15):
    ref, cur = _pick_years(ref_year, cur_year)
    tr, tc = _table(ref), _table(cur)
    rows_r = _lines(ref)["rows"]
    rows_c = _lines(cur)["rows"]
    cmap = {(r["school_code"], r["group"]): r for r in rows_c}
    movers = []
    for r in rows_r:
        k = (r["school_code"], r["group"])
        if k not in cmap:
            continue
        s_r, s_c = r["admit_score"], cmap[k]["admit_score"]
        d = s_c - s_r
        if abs(d) < min_abs_delta:
            continue
        rk_r = tr.score_to_rank(s_r)
        rk_eq = round(rk_r / tr.total * tc.total)
        movers.append({"school": r["school"], "group": r["group"],
                       "subject_req": r["subject_req"],
                       f"score_{ref}": s_r, f"score_{cur}": s_c, "delta_score": d,
                       "equiv_rank": rk_eq,
                       f"actual_rank_{cur}": tc.score_to_rank(s_c)})
    movers.sort(key=lambda x: -abs(x["delta_score"]))
    ds = [m["delta_score"] for m in movers]
    n = len(ds) or 1
    return {"ref_year": ref, "cur_year": cur, "comparable": len(ds),
            "mean_delta": round(sum(ds) / n, 2),
            "mean_abs_delta": round(sum(abs(x) for x in ds) / n, 2),
            "up": sum(1 for x in ds if x > 0), "down": sum(1 for x in ds if x < 0),
            "flat": sum(1 for x in ds if x == 0),
            "top_movers": movers[:top],
            "warning": "同院校专业组两年投档线波动极大（本次实测最大差 171 分），"
                       "任何基于往年数据的推荐都必须按位次区间给、并标注高波动项。"}


def gradient(rank, subject=None, top_n=25, ref_year=None, cur_year=None,
             f_chong=0.95, f_bao=1.20):
    ref, cur = _pick_years(ref_year, cur_year)
    tr, tc = _table(ref), _table(cur)
    rows_r = _lines(ref)["rows"]
    rows_c = _lines(cur)["rows"]
    cmap = {(r["school_code"], r["group"]): r for r in rows_c}
    buckets = {"冲": [], "稳": [], "保": []}
    for r in rows_r:
        if subject and subject not in r["subject_req"]:
            continue
        rk = tr.score_to_rank(r["admit_score"])
        rk_eq = round(rk / tr.total * tc.total)
        ratio = rk_eq / rank
        c = cmap.get((r["school_code"], r["group"]))
        s_c = c["admit_score"] if c else None
        d = (s_c - r["admit_score"]) if c else None
        rec = {"school": r["school"], "school_code": r["school_code"], "group": r["group"],
               "subject_req": r["subject_req"], f"score_{ref}": r["admit_score"],
               f"rank_{ref}": rk, "equiv_rank": rk_eq, "ratio_rn": round(ratio, 3),
               f"score_{cur}": s_c, "delta_score": d,
               "high_volatility": (d is not None and abs(d) >= 20)}
        (buckets["冲"] if ratio < f_chong else
         buckets["稳"] if ratio <= f_bao else buckets["保"]).append(rec)
    buckets["冲"].sort(key=lambda x: -x["ratio_rn"])
    buckets["稳"].sort(key=lambda x: x["ratio_rn"])
    buckets["保"].sort(key=lambda x: x["ratio_rn"])
    counts = {k: len(v) for k, v in buckets.items()}
    for k in buckets:
        buckets[k] = buckets[k][:top_n]
    return {"student_rank": rank, "percentile": round(rank / tc.total * 100, 2),
            "years": {"ref": ref, "cur": cur},
            "coef": {"冲": f"R/N<{f_chong}", "稳": f"{f_chong}~{f_bao}", "保": f"R/N>{f_bao}"},
            "counts": counts, "buckets": buckets,
            "ratio_advice": "冲 20~30% / 稳 40~50% / 保 30%",
            "confidence": "回测：位次MAE≈2,900 位、分数MAE≈11 分、±3分命中率≈29%。"
                          "请按位次区间使用，勿当分数线预测。",
            "disclaimer": "启发式参考区间，非录取预测；以官方政策与填报系统为准。"}


def backtest(ref_year=None, cur_year=None):
    ref, cur = _pick_years(ref_year, cur_year)
    tr, tc = _table(ref), _table(cur)
    rows_r = _lines(ref)["rows"]
    rows_c = _lines(cur)["rows"]
    cmap = {(r["school_code"], r["group"]): r for r in rows_c}
    errs = {"A": [], "B": [], "C": [], "D": []}
    rank_errs = {"A": [], "B": [], "C": [], "D": []}
    for r in rows_r:
        k = (r["school_code"], r["group"])
        if k not in cmap:
            continue
        s_r, act = r["admit_score"], cmap[k]["admit_score"]
        rk = tr.score_to_rank(s_r)
        rk_eq = round(rk / tr.total * tc.total)
        preds = {"A": (s_r, tc.score_to_rank(s_r)),
                 "B": (tc.rank_to_score(rk_eq), rk_eq),
                 "C": (tc.rank_to_score(rk), rk),
                 "D": (s_r, tc.score_to_rank(s_r))}
        ra = tc.score_to_rank(act)
        for kk, (ps, pr) in preds.items():
            errs[kk].append(abs(ps - act))
            rank_errs[kk].append(abs(pr - ra))
    n = len(errs["A"]) or 1
    names = {"A": "分数直搬", "B": "位次当量", "C": "位次直搬", "D": "线差法(需控制线)"}
    res = {}
    for kk in "ABC":
        e, re_ = errs[kk], rank_errs[kk]
        res[kk] = {"name": names[kk], "mae_score": round(sum(e) / n, 2),
                   "median_score": sorted(e)[len(e) // 2],
                   "hit3_pct": round(sum(1 for x in e if x <= 3) / n * 100, 1),
                   "hit5_pct": round(sum(1 for x in e if x <= 5) / n * 100, 1),
                   "mae_rank": int(sum(re_) / n)}
    best = min(res, key=lambda x: res[x]["mae_score"])
    return {"ref_year": ref, "cur_year": cur, "comparable": n, "methods": res,
            "best_method": best,
            "conclusion": "位次当量换算让误差显著优于「位次直搬」；但院校自身波动主导，"
                          "任何方法都无法做到 ±3 分精度 —— 故必须按位次区间交付。"}


def case_add(code, exam_rank, diag_node, plan_weeks, verify_ok, gradient_hit,
             satisfaction=None, note="", exam_year=None):
    cases = []
    if os.path.exists(CASE_FILE):
        try:
            cases = json.load(open(CASE_FILE, encoding="utf-8"))
        except Exception:
            cases = []
    rec = {"case_code": code, "exam_year": exam_year, "exam_rank": exam_rank,
           "diag_node": diag_node, "plan_weeks": plan_weeks,
           "verify_ok": bool(verify_ok), "gradient_hit": gradient_hit,
           "satisfaction": satisfaction, "note": note}
    cases.append(rec)
    os.makedirs(os.path.dirname(CASE_FILE), exist_ok=True)
    json.dump(cases, open(CASE_FILE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return {"saved": True, "total_cases": len(cases), "file": CASE_FILE,
            "privacy": "仅存代号，禁止写入姓名/考生号/联系方式"}


def case_stats():
    if not os.path.exists(CASE_FILE):
        return {"total_cases": 0, "calibration": ["无案例，参数不做任何调整（防过拟合）"]}
    cases = json.load(open(CASE_FILE, encoding="utf-8"))
    n = len(cases)
    if n < 5:
        return {"total_cases": n, "calibration": ["样本 <5 例，不调整任何系数（防过拟合）"]}
    ok = sum(1 for c in cases if c.get("verify_ok"))
    hit = [c.get("gradient_hit") for c in cases if c.get("gradient_hit")]
    adv = []
    if ok / n < 0.6:
        adv.append("验证达标率 <60% → 诊断起点前移 1 个知识节点")
    if hit.count("偏高落空") >= 2:
        adv.append("「偏高落空」≥2 例 → 冲档系数由 R/N<0.95 收紧至 0.90")
    if not adv:
        adv.append("全部指标在阈值内 → 参数保持不变")
    return {"total_cases": n, "verify_ok_rate": round(ok / n * 100, 1),
            "hit_dist": {k: hit.count(k) for k in set(hit)} if hit else {},
            "calibration": adv}


# ---------------- MCP 元数据 ----------------
TOOLS = [
    ("lm_health", "底库健康检查：返回已入库年份、一分一段行数、投档线行数、院校数、官方来源 URL 与 sha256。",
     {"type": "object", "properties": {}, "required": []}, lambda a: health()),

    ("lm_score_to_rank", "分数→位次（含百分位）。",
     {"type": "object", "properties": {"year": {"type": "integer"}, "score": {"type": "integer"}},
      "required": ["year", "score"]},
     lambda a: score_to_rank(int(a["year"]), int(a["score"]))),

    ("lm_rank_to_score", "位次→分数（用于把位次换算成对应年份的分数）。",
     {"type": "object", "properties": {"year": {"type": "integer"}, "rank": {"type": "integer"}},
      "required": ["year", "rank"]},
     lambda a: rank_to_score(int(a["year"]), int(a["rank"]))),

    ("lm_equivalent_rank", "位次当量换算（跨年对照必做）：把考生位次从一年等效到另一年。",
     {"type": "object", "properties": {"rank": {"type": "integer"}, "from_year": {"type": "integer"},
                                       "to_year": {"type": "integer"}},
      "required": ["rank", "from_year", "to_year"]},
     lambda a: equivalent_rank(int(a["rank"]), int(a["from_year"]), int(a["to_year"]))),

    ("lm_gradient", "生成冲/稳/保三档真实梯度清单（位次法，R/N 系数）。",
     {"type": "object", "properties": {"rank": {"type": "integer"},
                                       "subject": {"type": "string", "description": "选考要求关键字，如 物理+化学"},
                                       "top_n": {"type": "integer", "default": 25},
                                       "ref_year": {"type": "integer"}, "cur_year": {"type": "integer"}},
      "required": ["rank"]},
     lambda a: gradient(int(a["rank"]), a.get("subject"), int(a.get("top_n", 25)),
                        a.get("ref_year"), a.get("cur_year"))),

    ("lm_volatility", "两年投档线波动榜：识别高波动院校专业组（志愿风险预警）。",
     {"type": "object", "properties": {"min_abs_delta": {"type": "integer", "default": 0},
                                       "top": {"type": "integer", "default": 15},
                                       "ref_year": {"type": "integer"}, "cur_year": {"type": "integer"}},
      "required": []},
     lambda a: volatility(a.get("ref_year"), a.get("cur_year"),
                          int(a.get("min_abs_delta", 0)), int(a.get("top", 15)))),

    ("lm_backtest", "回测：用往年数据预测次年投档线，输出各方法与误差（可信度边界）。",
     {"type": "object", "properties": {"ref_year": {"type": "integer"}, "cur_year": {"type": "integer"}},
      "required": []},
     lambda a: backtest(a.get("ref_year"), a.get("cur_year"))),

    ("lm_case_add", "登记一个真实服务案例（仅用代号，禁止写入姓名/考生号）。用于案例库自校准。",
     {"type": "object", "properties": {"code": {"type": "string"}, "exam_rank": {"type": "integer"},
                                       "diag_node": {"type": "string"}, "plan_weeks": {"type": "integer"},
                                       "verify_ok": {"type": "boolean"}, "gradient_hit": {"type": "string"},
                                       "satisfaction": {"type": "string"}, "note": {"type": "string"},
                                       "exam_year": {"type": "integer"}},
      "required": ["code", "exam_rank", "diag_node", "plan_weeks", "verify_ok", "gradient_hit"]},
     lambda a: case_add(a["code"], int(a["exam_rank"]), a["diag_node"], int(a["plan_weeks"]),
                        a["verify_ok"], a["gradient_hit"], a.get("satisfaction"), a.get("note", ""),
                        a.get("exam_year"))),

    ("lm_case_stats", "案例库统计与自校准建议（样本<5 不调系数，防过拟合）。",
     {"type": "object", "properties": {}, "required": []}, lambda a: case_stats()),
]


def tool_specs():
    return [{"name": n, "description": d, "inputSchema": s} for n, d, s, _ in TOOLS]


def call_tool(name, args):
    for n, _d, _s, fn in TOOLS:
        if n == name:
            return fn(args)
    raise ValueError(f"未知工具：{name}")


# ---------------- JSON-RPC / stdio ----------------
def _resp(mid, result):
    return {"jsonrpc": "2.0", "id": mid, "result": result}


def _err(mid, code, message):
    return {"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": message}}


def handle(msg):
    method = msg.get("method")
    mid = msg.get("id")
    if method == "initialize":
        return _resp(mid, {"protocolVersion": PROTOCOL, "capabilities": {"tools": {}},
                           "serverInfo": SERVER_INFO})
    if method in ("notifications/initialized", "notifications/cancelled"):
        return None
    if method == "ping":
        return _resp(mid, {})
    if method == "tools/list":
        return _resp(mid, {"tools": tool_specs()})
    if method == "tools/call":
        p = msg.get("params") or {}
        try:
            out = call_tool(p.get("name"), p.get("arguments") or {})
            text = json.dumps(out, ensure_ascii=False, indent=1)
            return _resp(mid, {"content": [{"type": "text", "text": text}], "isError": False})
        except Exception as e:
            return _resp(mid, {"content": [{"type": "text", "text": f"错误：{type(e).__name__}: {e}"}],
                               "isError": True})
    if mid is None:
        return None
    return _err(mid, -32601, f"Method not found: {method}")


def main():
    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            msg = json.loads(raw)
        except Exception:
            continue
        out = handle(msg)
        if out is not None:
            sys.stdout.write(json.dumps(out, ensure_ascii=False) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
