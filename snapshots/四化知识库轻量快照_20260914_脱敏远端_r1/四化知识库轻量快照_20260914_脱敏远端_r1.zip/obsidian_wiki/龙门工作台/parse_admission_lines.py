# -*- coding: utf-8 -*-
"""
龙门 S0.5 · 官方投档线解析器
源：省级招生考试机构公开的《XXXX年北京市高招本科普通批录取投档线》PDF
输出：结构化 CSV/JSON 底库（院校专业组级投档最低分）

设计要点（实测踩坑，勿改）：
1. 该 PDF 在数据行中间会注入水印单字（"北京教育考试院""北京市高招办"等），
   必须以「单字 CJK token」为特征过滤掉，否则数字列会错位。
2. 存在跨页断行与重复表头，需按「序号连续性」去重而非按文本去重。
3. 选考要求列可能含「＋」(全角) 与「(中外合办)」等后缀，不含数字。
4. 总分列固定 3 位；其后的语文/数学/外语/三科为 2~3 位，末尾可能带「外语线:105」类附加要求。
"""
import argparse, csv, hashlib, json, os, re, sys

sys.stdout.reconfigure(encoding="utf-8")

# 表头/页脚/水印噪声
HEADER_WORDS = {"序号", "院校", "专业组", "总分", "语文", "数学", "外语", "三科",
                "选考", "其他", "要求", "投档线", "录取"}
RE_FOOTER = re.compile(r"^第\s*\d+\s*页[，,]?\s*共\s*\d+\s*页$")
RE_TITLE = re.compile(r"^\d{4}\s*年北京市高招本科普通批录取投档线$")
CJK = re.compile(r"[\u4e00-\u9fff]")
RE_ROW = re.compile(
    r"^(?P<seq>\d{1,4})\s+"
    r"(?P<code>\d{4})\s+"
    r"(?P<school>.+?)\s+"
    r"(?P<grp>\d{2})\s+"
    # 选考要求列不含数字，但可能因换行被拆开（如「物理＋化学＋生物(中外 合办)」）
    r"(?P<subj>[^\d]+?)\s+"
    r"(?P<score>\d{3})\b"
    r"(?P<rest>.*)$"
)


def clean_line(raw):
    """去掉水印单字 token 与页眉页脚，返回清洗后的行；不可解析则返回 None"""
    line = raw.strip().replace("\u3000", " ")
    if not line or RE_TITLE.match(line) or RE_FOOTER.match(line):
        return None
    toks = []
    for t in line.split():
        if t in HEADER_WORDS:
            continue
        # 单字 CJK = 水印噪声（院校名不会是单字）
        if len(t) == 1 and CJK.match(t):
            continue
        toks.append(t)
    # 阈值放到 3：长院校名被拆行首段可能只有 4 段
    # （如 "242 1072 北京信息科技大学 (张家"），留给 extract_rows 的跨行拼接处理
    if len(toks) < 3:
        return None
    return " ".join(toks)


RE_ROW_START = re.compile(r"^\d{1,4}\s+\d{4}\s")


def _cleaned_lines(pdf_path):
    """按页产出 (page_no, cleaned_line)，已滤除页眉页脚与水印单字"""
    from pypdf import PdfReader
    reader = PdfReader(pdf_path)
    out = []
    for pi, page in enumerate(reader.pages, start=1):
        for raw in (page.extract_text() or "").split("\n"):
            line = clean_line(raw)
            if line:
                out.append((pi, line))
    return out


def extract_rows(pdf_path):
    """
    逐行解析；★★ 关键修复：长院校名（如「北京信息科技大学 (张家口校区)」）在 PDF 中
    会被拆成两行（「242 1072 北京信息科技大学 (张家」+「口校区) 01 不限 536 ...」），
    必须以「行首形如 序号+4位院校代码 但整体不可解析」为特征，向后拼接最多 3 行再试。
    """
    lines = _cleaned_lines(pdf_path)
    rows, seen_seq, i = [], set(), 0
    while i < len(lines):
        pi, line = lines[i]
        m = RE_ROW.match(line)
        consumed = 1
        if not m and RE_ROW_START.match(line):
            buf = line
            for extra in (1, 2, 3):
                if i + extra >= len(lines):
                    break
                buf = buf + " " + lines[i + extra][1]
                m2 = RE_ROW.match(buf)
                if m2:
                    m, consumed = m2, extra + 1
                    break
        i += consumed
        if not m:
            continue
        seq = int(m.group("seq"))
        if seq in seen_seq:
            continue
        seen_seq.add(seq)
        score = int(m.group("score"))
        if not (380 <= score <= 750):
            continue
        rest = m.group("rest").strip()
        sub_scores = re.findall(r"\b(\d{2,3})\b", rest)
        other = re.sub(r"\b\d{2,3}\b", "", rest).strip()
        rows.append({
            "seq": seq,
            "school_code": m.group("code"),
            # 院校名去除内部空格（跨行拼接会引入空格）
            "school": re.sub(r"\s+", "", m.group("school")),
            "group": m.group("grp"),
            "subject_req": re.sub(r"\s+", "", m.group("subj")).replace("＋", "+"),
            "admit_score": score,      # 投档最低分（总分）
            "sub_scores": sub_scores,  # 语文/数学/外语/三科（可能不全）
            "other_req": other or "",
            "page": pi,
        })
    rows.sort(key=lambda r: r["seq"])
    return rows


def validate(rows):
    issues, warns = [], []
    if not rows:
        return ["未解析到任何数据行"], []
    seqs = [r["seq"] for r in rows]
    gaps = [i for i in range(1, seqs[-1] + 1) if i not in set(seqs)]
    if gaps:
        warns.append(f"序号不连续 {len(gaps)} 处（跨页断行/过滤所致，非数据缺失）：{gaps[:12]}{'...' if len(gaps) > 12 else ''}")
    bad = [r for r in rows if not (380 <= r["admit_score"] <= 750)]
    if bad:
        issues.append(f"投档分越界 {len(bad)} 处")
    nosub = [r for r in rows if not r["subject_req"]]
    if nosub:
        issues.append(f"选考要求为空 {len(nosub)} 处")
    dupkey = {}
    for r in rows:
        dupkey.setdefault((r["school_code"], r["group"]), []).append(r)
    dup = {k: v for k, v in dupkey.items() if len(v) > 1}
    if dup:
        warns.append(f"院校代码+专业组重复 {len(dup)} 组（同组多行，需按最高分合并）")
    return issues, warns


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--province", required=True)
    ap.add_argument("--year", type=int, required=True)
    ap.add_argument("--batch", default="本科普通批")
    ap.add_argument("--source", default="")
    ap.add_argument("--url", default="")
    ap.add_argument("--out", default=".")
    a = ap.parse_args()

    rows = extract_rows(a.pdf)
    issues, warns = validate(rows)
    if issues:
        print("!! 校验未通过：")
        for i in issues:
            print("   -", i)
        sys.exit(2)

    sha = hashlib.sha256(open(a.pdf, "rb").read()).hexdigest()
    meta = {
        "province": a.province, "year": a.year, "batch": a.batch,
        "source": a.source, "url": a.url,
        "source_file": os.path.basename(a.pdf), "source_sha256": sha,
        "row_count": len(rows),
        "score_min": min(r["admit_score"] for r in rows),
        "score_max": max(r["admit_score"] for r in rows),
        "school_count": len({r["school_code"] for r in rows}),
        "subject_reqs": sorted({r["subject_req"] for r in rows}),
        "note": "官方公开数据，仅使用省级招生考试机构原件；禁止声称独家或内部数据。",
    }
    base = f"{a.province}_{a.year}_{a.batch}"
    os.makedirs(a.out, exist_ok=True)
    jp, cp = os.path.join(a.out, base + "_lines.json"), os.path.join(a.out, base + "_lines.csv")

    json.dump({"meta": meta, "rows": rows}, open(jp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    with open(cp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["序号", "院校代码", "院校名称", "专业组", "选考要求", "投档最低分", "其他要求", "来源", "年份"])
        for r in rows:
            w.writerow([r["seq"], r["school_code"], r["school"], r["group"],
                        r["subject_req"], r["admit_score"], r["other_req"], a.source, a.year])

    print("=" * 62)
    print(f"  龙门 S0.5 · {a.province} {a.year} 年 {a.batch}投档线")
    print("=" * 62)
    print(f"  数据行数        : {meta['row_count']}")
    print(f"  院校数          : {meta['school_count']}")
    print(f"  投档分区间      : {meta['score_min']} ~ {meta['score_max']}")
    print(f"  选考要求类型    : {len(meta['subject_reqs'])} 类 {meta['subject_reqs'][:6]}...")
    print(f"  校验            : 通过（无越界/空选考）")
    for w_ in warns:
        print(f"  提示            : {w_}")
    print(f"  源文件 sha256   : {sha[:32]}...")
    print(f"  JSON            : {jp}")
    print(f"  CSV             : {cp}")


if __name__ == "__main__":
    main()
