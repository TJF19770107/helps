---
title: "Kakeya猜想证明 — 王虹（Hong Wang）"
tags:
  - L8-菲尔兹
  - 数学
  - 谐波分析
  - 几何测度论
  - 菲尔兹奖2026
source: "论文+B站解读"
difficulty: "菲尔兹奖级别"
extracted_date: "2026-08-02"
related_fields:
  - 信号处理
  - PDE理论
  - 数据分析中的Fourier方法
---

# Kakeya猜想证明 — 王虹（Hong Wang）

## 📚 基本信息

| 字段 | 值 |
|------|-----|
| **研究者** | 王虹（Hong Wang）🇨🇳 |
| **出生** | 1991年，广西桂林 |
| **学历** | 北京大学本科 → 法国综合理工/巴黎南大 → MIT博士（导师：Larry Guth） |
| **现任** | NYU Courant研究所教授、IHES永久教授 |
| **获奖** | 2026年菲尔兹奖（第一位中国女性获奖者） |

---

## 🎯 核心贡献

### Kakeya猜想（Kakeya Conjecture）

**问题描述**：
- Kakeya集：在ℝⁿ中包含每个方向上单位线段的紧集
- 猜想：ℝ³中Kakeya集的Hausdorff维数必须为3

**历史背景**：
- 1917年：日本数学家挂谷宗一（Sōichi Kakeya）提出问题
- 1971年：Besicovitch证明Kakeya集的Lebesgue测度可以任意小
- 1999年：Wolff提出Kakeya猜想
- **2025年：王虹与Joshua Zahl证明三维Kakeya猜想** ← 菲尔兹奖贡献

**证明意义**：
- "百年一遇"的谐波分析突破
- 证明ℝ³中Kakeya集的Hausdorff维数为3
- 解决了调和分析领域最重要的开放问题之一

---

## 🔗 与编程/量化的关联

### 1. 信号处理
- Kakeya集与Fourier分析密切相关
- 应用于信号采样、压缩感知
- 数据分析中的频域处理

### 2. PDE理论
- Kakeya猜想的证明推进了PDE理论
- 应用于流体力学、量子力学
- 量化策略中的随机PDE

### 3. 几何测度论
- Hausdorff维数理论
- 分形几何应用
- 数据分析中的维度估计

---

## 📖 学习资源

### B站搜索
- "挂谷猜想 王虹"
- "Kakeya conjecture"
- "谐波分析 研究生"

### 核心论文
- Wang, H., & Zahl, J. (2025). *Kakeya sets in ℝ³*
- Guth, L. (2016). *Restriction estimates using polynomial partitioning*

### 相关课程
- 调和分析研究生课程
- 几何测度论
- Fourier分析

---

## 💡 关键概念

1. **Kakeya集**：包含每个方向单位线段的集合
2. **Hausdorff维数**：集合的"分数维数"
3. **谐波分析**：Fourier变换的推广
4. **几何测度论**：高维几何的测度理论

---

## 📊 学习深度评估

**当前等级**: `[L8-菲尔兹]`
**学习状态**: 概念了解（需深入学习证明）
**下一步**: 学习调和分析基础 → 几何测度论 → Kakeya猜想证明

---

## 🔗 关联笔记

- [[Hilbert第六问题]] — 邓煜的贡献
- [[调和分析基础]]
- [[几何测度论入门]]
- [[Fourier分析应用]]

---

**标签**: #L8-菲尔兹 #数学 #谐波分析 #几何测度论 #菲尔兹奖2026
